<?php
session_start();
include 'includes/db.php';
require 'includes/csrf.php';

if (!isset($_SESSION['user_id'])) { header('Location: login.php'); exit(); }

$user_id = (int) $_SESSION['user_id'];
$error   = '';
$success = '';

$uStmt = $conn->prepare("SELECT * FROM users WHERE id=:id");
$uStmt->execute([':id' => $user_id]);
$user = $uStmt->fetch();
if (!$user) { session_destroy(); header('Location: login.php'); exit(); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    $full_name = trim($_POST['full_name'] ?? '');
    $phone     = trim($_POST['phone']     ?? '');
    $email     = trim($_POST['email']     ?? '');
    $new_pass  = $_POST['new_password']      ?? '';
    $cur_pass  = $_POST['current_password']  ?? '';

    if ($full_name === '' || $phone === '' || $email === '') {
        $error = 'Заполните все обязательные поля.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Введите корректный email.';
    } else {
        // Уникальность email среди других аккаунтов
        $chk = $conn->prepare("SELECT id FROM users WHERE email = :email AND id != :id LIMIT 1");
        $chk->execute([':email' => $email, ':id' => $user_id]);
        if ($chk->fetch()) {
            $error = 'Этот email уже используется другим аккаунтом.';
        } else {
            if ($new_pass !== '') {
                if (!password_verify($cur_pass, $user['password'])) {
                    $error = 'Текущий пароль указан неверно.';
                } elseif (mb_strlen($new_pass) < 8) {
                    $error = 'Новый пароль должен содержать не менее 8 символов.';
                } else {
                    $hashed = password_hash($new_pass, PASSWORD_BCRYPT);
                    $conn->prepare("UPDATE users SET full_name=:fn, phone=:ph, email=:em, password=:pw WHERE id=:id")
                         ->execute([':fn'=>$full_name,':ph'=>$phone,':em'=>$email,':pw'=>$hashed,':id'=>$user_id]);
                    $_SESSION['user_name'] = $full_name;
                    $success = 'Данные успешно сохранены.';
                    $user = array_merge($user, ['full_name'=>$full_name,'phone'=>$phone,'email'=>$email]);
                }
            } else {
                $conn->prepare("UPDATE users SET full_name=:fn, phone=:ph, email=:em WHERE id=:id")
                     ->execute([':fn'=>$full_name,':ph'=>$phone,':em'=>$email,':id'=>$user_id]);
                $_SESSION['user_name'] = $full_name;
                $success = 'Данные успешно сохранены.';
                $user = array_merge($user, ['full_name'=>$full_name,'phone'=>$phone,'email'=>$email]);
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>Профиль — Horizons</title>
  <link rel="stylesheet" href="main.css">
  <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,300;1,400&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500&display=swap" rel="stylesheet">
  <style>
    .auth-success{background:rgba(22,163,74,.12);border:1px solid rgba(22,163,74,.3);color:#166534;padding:12px 16px;border-radius:8px;font-size:.85rem;margin-bottom:20px}
    .profile-info-block{background:#f4f7fb;border:1px solid #e0e8f0;border-radius:12px;padding:24px;margin-bottom:28px}
    .profile-info-row{display:flex;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid #e8eff6}
    .profile-info-row:last-child{border-bottom:none}
    .profile-info-label{font-size:.78rem;font-weight:600;color:#5a85a8;text-transform:uppercase;letter-spacing:.04em;width:120px;flex-shrink:0}
    .profile-info-value{font-size:.92rem;color:#1e3a5f;font-weight:500}
    .profile-avatar-lg{width:72px;height:72px;background:#0d2144;border-radius:50%;display:flex;align-items:center;justify-content:center;font-family:'Cormorant Garamond',serif;font-size:2rem;color:#c9a860;font-weight:600;margin:0 auto 20px}
    .section-divider{font-size:.82rem;font-weight:600;color:#5a85a8;text-transform:uppercase;letter-spacing:.06em;margin-bottom:16px;padding-bottom:8px;border-bottom:1px solid #e0e8f0}
  </style>
</head>
<body class="dash-page">
  <header class="dash-header">
    <div class="container">
      <div class="header-inner">
        <a href="index.html" class="logo" style="text-decoration:none">
          <span class="logo-anchor">⚓</span>
          <span class="logo-text">Horizons</span>
        </a>
        <nav class="dash-nav">
          <a href="dashboard.php">Мои бронирования</a>
          <a href="create_order.php">Новый круиз</a>
          <a href="profile.php" class="active">Профиль</a>
          <a href="logout.php" style="color:rgba(232,240,247,.4)">Выйти</a>
        </nav>
      </div>
    </div>
  </header>

  <main class="dash-body">
    <div class="container" style="max-width:600px">
      <div class="dash-welcome">
        <h1>Профиль</h1>
        <p>Ваши данные и управление паролем</p>
      </div>

      <div style="background:#fff;border:1px solid #dde7f0;border-radius:16px;padding:40px;box-shadow:0 2px 10px rgba(6,14,28,.08)">

        <div style="text-align:center;margin-bottom:28px">
          <div class="profile-avatar-lg"><?= mb_substr($user['full_name'], 0, 1, 'UTF-8') ?></div>
          <h2 style="font-family:'Cormorant Garamond',serif;font-size:1.5rem;color:#0d2144;margin-bottom:4px"><?= htmlspecialchars($user['full_name']) ?></h2>
          <p style="font-size:.82rem;color:#5a85a8">Клиент круизного центра Horizons</p>
        </div>

        <?php if ($success): ?><div class="auth-success">✓ <?= htmlspecialchars($success) ?></div><?php endif ?>
        <?php if ($error):   ?><div class="auth-error"><?= htmlspecialchars($error) ?></div><?php endif ?>

        <form method="POST" novalidate>
          <?= csrf_field() ?>

          <div class="form-group">
            <label for="full_name">Полное имя</label>
            <input type="text" id="full_name" name="full_name" required
                   value="<?= htmlspecialchars($user['full_name']) ?>">
          </div>
          <div class="form-group">
            <label for="phone">Телефон</label>
            <input type="tel" id="phone" name="phone" required
                   value="<?= htmlspecialchars($user['phone']) ?>">
          </div>
          <div class="form-group">
            <label for="email">Email</label>
            <input type="email" id="email" name="email" required
                   value="<?= htmlspecialchars($user['email']) ?>">
          </div>

          <hr style="border:none;border-top:1px solid #e0e8f0;margin:24px 0">
          <p class="section-divider">Смена пароля</p>
          <p style="font-size:.82rem;color:#5a85a8;margin-bottom:16px">Оставьте поля пароля пустыми, если не хотите его менять.</p>

          <div class="form-group">
            <label for="current_password">Текущий пароль</label>
            <input type="password" id="current_password" name="current_password"
                   placeholder="Введите текущий пароль" autocomplete="current-password">
          </div>
          <div class="form-group">
            <label for="new_password">Новый пароль</label>
            <input type="password" id="new_password" name="new_password"
                   placeholder="Минимум 8 символов" minlength="8" autocomplete="new-password">
          </div>

          <button type="submit" class="auth-submit" style="margin-top:8px">Сохранить изменения</button>
        </form>

        <div class="auth-link" style="margin-top:20px"><a href="dashboard.php">← Вернуться в кабинет</a></div>
      </div>
    </div>
  </main>
</body>
</html>
