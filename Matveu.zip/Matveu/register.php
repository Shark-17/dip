<?php
session_start();
include 'includes/db.php';
require 'includes/csrf.php';

// Уже авторизован
if (isset($_SESSION['user_id'])) { header('Location: dashboard.php'); exit(); }

$error  = '';
$fields = ['full_name' => '', 'phone' => '', 'email' => '', 'login' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    $full_name = trim($_POST['full_name'] ?? '');
    $phone     = trim($_POST['phone']     ?? '');
    $email     = trim($_POST['email']     ?? '');
    $login     = trim($_POST['login']     ?? '');
    $password  = $_POST['password']       ?? '';

    $fields = compact('full_name', 'phone', 'email', 'login');

    if ($full_name === '' || $phone === '' || $email === '' || $login === '' || $password === '') {
        $error = 'Пожалуйста, заполните все поля.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Введите корректный email.';
    } elseif (mb_strlen($password) < 8) {
        $error = 'Пароль должен содержать не менее 8 символов.';
    } else {
        // Проверка уникальности логина
        $chkLogin = $conn->prepare("SELECT id FROM users WHERE login = :login LIMIT 1");
        $chkLogin->execute([':login' => $login]);
        if ($chkLogin->fetch()) {
            $error = 'Этот логин уже занят. Выберите другой.';
        } else {
            // Проверка уникальности email
            $chkEmail = $conn->prepare("SELECT id FROM users WHERE email = :email LIMIT 1");
            $chkEmail->execute([':email' => $email]);
            if ($chkEmail->fetch()) {
                $error = 'Аккаунт с таким email уже существует.';
            } else {
                $hashed = password_hash($password, PASSWORD_BCRYPT);
                $stmt   = $conn->prepare(
                    "INSERT INTO users (full_name, phone, email, login, password)
                     VALUES (:full_name, :phone, :email, :login, :password)"
                );
                $stmt->execute([
                    ':full_name' => $full_name,
                    ':phone'     => $phone,
                    ':email'     => $email,
                    ':login'     => $login,
                    ':password'  => $hashed,
                ]);
                header('Location: login.php?registered=1');
                exit();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Регистрация — Horizons</title>
  <link rel="stylesheet" href="main.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,300;1,400&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500&display=swap" rel="stylesheet">
</head>
<body class="auth-page">
  <div class="auth-card" style="max-width:500px;">
    <div class="auth-logo">
      <a href="index.html" class="logo" style="justify-content:center;">
        <span class="logo-anchor">⚓</span>
        <span class="logo-text">Horizons</span>
      </a>
    </div>
    <h1 class="auth-title">Создать аккаунт</h1>
    <p class="auth-sub">Зарегистрируйтесь и бронируйте круизы онлайн</p>

    <?php if ($error): ?>
      <div class="auth-error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" novalidate>
      <?= csrf_field() ?>
      <div class="form-group">
        <label for="full_name">Полное имя</label>
        <input type="text" id="full_name" name="full_name"
               placeholder="Иванов Иван Иванович" required
               value="<?= htmlspecialchars($fields['full_name']) ?>">
      </div>
      <div class="form-group">
        <label for="phone">Телефон</label>
        <input type="tel" id="phone" name="phone"
               placeholder="+7 900 000 00 00" required
               value="<?= htmlspecialchars($fields['phone']) ?>">
      </div>
      <div class="form-group">
        <label for="email">Email</label>
        <input type="email" id="email" name="email"
               placeholder="you@example.com" required
               value="<?= htmlspecialchars($fields['email']) ?>">
      </div>
      <div class="form-group">
        <label for="login">Логин</label>
        <input type="text" id="login" name="login"
               placeholder="Придумайте логин" required
               value="<?= htmlspecialchars($fields['login']) ?>">
      </div>
      <div class="form-group">
        <label for="password">Пароль</label>
        <input type="password" id="password" name="password"
               placeholder="Минимум 8 символов" required minlength="8">
      </div>
      <button type="submit" class="auth-submit">Зарегистрироваться</button>
    </form>

    <div class="auth-link">
      Уже есть аккаунт? <a href="login.php">Войти</a>
    </div>
  </div>
</body>
</html>
