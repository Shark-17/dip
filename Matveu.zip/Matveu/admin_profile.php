<?php
session_start();
include 'includes/db.php';
require 'includes/csrf.php';

if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header('Location: login.php'); exit();
}

$admin_id = isset($_SESSION['admin_id']) ? (int)$_SESSION['admin_id'] : 1;
$error    = '';
$success  = '';

$aStmt = $conn->prepare("SELECT * FROM admins WHERE id=:id");
$aStmt->execute([':id' => $admin_id]);
$admin = $aStmt->fetch();
if (!$admin) {
    // Фолбэк — берём первого
    $admin = $conn->query("SELECT * FROM admins LIMIT 1")->fetch();
    if (!$admin) { session_destroy(); header('Location: login.php'); exit(); }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $newPass  = trim($_POST['new_password']     ?? '');
    $currPass = trim($_POST['current_password'] ?? '');

    if (!password_verify($currPass, $admin['password'])) {
        $error = 'Неверный текущий пароль.';
    } elseif ($newPass === '') {
        $error = 'Введите новый пароль.';
    } elseif (mb_strlen($newPass) < 6) {
        $error = 'Новый пароль должен быть не менее 6 символов.';
    } else {
        $hashed = password_hash($newPass, PASSWORD_BCRYPT);
        $conn->prepare("UPDATE admins SET password=:pw WHERE id=:id")
             ->execute([':pw' => $hashed, ':id' => $admin['id']]);
        $success = 'Пароль администратора успешно изменён!';
        $aStmt->execute([':id' => $admin['id']]);
        $admin = $aStmt->fetch();
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>Профиль администратора — Horizons</title>
  <link rel="stylesheet" href="main.css">
  <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,300;1,400&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500&display=swap" rel="stylesheet">
  <style>
    .auth-success{background:rgba(22,163,74,.12);border:1px solid rgba(22,163,74,.3);color:#166534;padding:12px 16px;border-radius:8px;font-size:.85rem;margin-bottom:20px}
    .info-block{background:#f4f7fb;border:1px solid #e0e8f0;border-radius:12px;padding:24px;margin-bottom:28px}
    .info-row{display:flex;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid #e8eff6}
    .info-row:last-child{border-bottom:none}
    .info-label{font-size:.78rem;font-weight:600;color:#5a85a8;text-transform:uppercase;letter-spacing:.04em;width:120px;flex-shrink:0}
    .info-value{font-size:.92rem;color:#1e3a5f;font-weight:500}
    .admin-avatar{width:72px;height:72px;background:linear-gradient(135deg,#0d2144,#1c3d6e);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:2rem;color:#c9a860;margin:0 auto 20px}
    .section-divider{font-size:.82rem;font-weight:600;color:#5a85a8;text-transform:uppercase;letter-spacing:.06em;margin-bottom:16px;padding-bottom:8px;border-bottom:1px solid #e0e8f0}
  </style>
</head>
<body class="admin-page dash-page">

  <header class="dash-header">
    <div class="container">
      <div class="header-inner">
        <a href="index.html" class="logo" style="text-decoration:none">
          <span class="logo-anchor">⚓</span>
          <span class="logo-text">Horizons</span>
        </a>
        <nav class="dash-nav">
          <a href="admin.php">Бронирования</a>
          <a href="analytics.php">Аналитика</a>
          <a href="admin_profile.php" class="active">Профиль</a>
          <a href="logout.php" style="color:rgba(232,240,247,.4)">Выйти</a>
        </nav>
      </div>
    </div>
  </header>

  <main class="dash-body">
    <div class="container" style="max-width:560px">
      <div class="dash-welcome">
        <h1>Профиль администратора</h1>
        <p>Данные учётной записи и смена пароля</p>
      </div>

      <div style="background:#fff;border:1px solid #dde7f0;border-radius:16px;padding:40px;box-shadow:0 2px 10px rgba(6,14,28,.08)">

        <div style="text-align:center;margin-bottom:28px">
          <div class="admin-avatar">⚙️</div>
          <h2 style="font-family:'Cormorant Garamond',serif;font-size:1.5rem;color:#0d2144;margin-bottom:4px">
            <?= htmlspecialchars($admin['full_name']) ?>
          </h2>
          <p style="font-size:.82rem;color:#5a85a8">Администратор системы</p>
        </div>

        <div class="info-block">
          <div class="info-row">
            <span class="info-label">Имя</span>
            <span class="info-value"><?= htmlspecialchars($admin['full_name']) ?></span>
          </div>
          <div class="info-row">
            <span class="info-label">Логин</span>
            <span class="info-value"><?= htmlspecialchars($admin['login']) ?></span>
          </div>
        </div>

        <p class="section-divider">Смена пароля</p>

        <?php if ($error): ?><div class="auth-error"><?= htmlspecialchars($error) ?></div><?php endif ?>
        <?php if ($success): ?><div class="auth-success"><?= htmlspecialchars($success) ?></div><?php endif ?>

        <form method="POST" novalidate>
          <?= csrf_field() ?>
          <div class="form-group">
            <label for="new_password">Новый пароль</label>
            <input type="password" id="new_password" name="new_password" placeholder="Минимум 6 символов" required>
          </div>
          <div class="form-group">
            <label for="current_password">Текущий пароль <span style="color:#dc2626">*</span></label>
            <input type="password" id="current_password" name="current_password" required placeholder="Для подтверждения">
          </div>
          <button type="submit" class="auth-submit">Изменить пароль</button>
        </form>

        <div class="auth-link" style="margin-top:20px"><a href="admin.php">← Вернуться в панель</a></div>
      </div>
    </div>
  </main>
</body>
</html>
