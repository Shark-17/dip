-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Июн 24 2026 г., 23:03
-- Версия сервера: 8.0.15
-- Версия PHP: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `horizons_cruise`
--

-- --------------------------------------------------------

--
-- Структура таблицы `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `login` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `admins`
--

INSERT INTO `admins` (`id`, `full_name`, `login`, `password`) VALUES
(1, 'Администратор', 'admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');

-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `address` varchar(255) NOT NULL COMMENT 'Email для подтверждения',
  `service_type` varchar(100) NOT NULL COMMENT 'Тарифный пакет',
  `desired_date` date NOT NULL COMMENT 'Дата отправления',
  `desired_time` time NOT NULL COMMENT 'Время отправления',
  `payment_type` varchar(50) NOT NULL,
  `status` enum('новая','выполнена','отменена') NOT NULL DEFAULT 'новая',
  `admin_comment` text COMMENT 'Комментарий администратора',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `address`, `service_type`, `desired_date`, `desired_time`, `payment_type`, `status`, `admin_comment`) VALUES
(10, 5, 'examin@gmail.com', 'Дальний Восток', '2026-06-09', '04:25:00', 'банковская карта', 'выполнена', 'спасибо, бронь завершена'),
(11, 5, 'examin@gmail.com', 'Карибский бассейн', '2026-06-09', '02:29:00', 'банковская карта', 'выполнена', 'бронь завершена'),
(12, 5, 'examin@gmail.com', 'Дальний Восток', '2026-06-09', '04:34:00', 'наличные', 'новая', NULL),
(13, 6, 'exfjfmin220@gmail.com', 'Дальний Восток', '2026-06-11', '05:27:00', 'банковская карта', 'новая', NULL),
(14, 6, 'exfjfmin220@gmail.com', 'Карибский бассейн', '2026-07-30', '07:30:00', 'банковская карта', 'новая', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `order_log`
--

CREATE TABLE `order_log` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `admin_id` int(11) DEFAULT NULL COMMENT 'ID администратора, внёсшего изменение',
  `changed_by` varchar(100) NOT NULL COMMENT 'Имя/логин администратора',
  `old_status` varchar(50) DEFAULT NULL,
  `new_status` varchar(50) DEFAULT NULL,
  `comment` text,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `order_log`
--

INSERT INTO `order_log` (`id`, `order_id`, `admin_id`, `changed_by`, `old_status`, `new_status`, `comment`) VALUES
(5, 10, NULL, 'Администратор', NULL, NULL, 'Комментарий обновлён: f'),
(6, 10, NULL, 'Администратор', 'новая', 'выполнена', 'Статус изменён: новая → выполнена'),
(7, 10, NULL, 'Администратор', 'выполнена', 'новая', 'Статус изменён: выполнена → новая'),
(8, 11, NULL, 'Администратор', NULL, NULL, 'Комментарий обновлён: good'),
(9, 11, NULL, 'Администратор', 'новая', 'выполнена', 'Статус изменён: новая → выполнена'),
(10, 12, NULL, 'Администратор', NULL, NULL, 'Комментарий обновлён: goof'),
(11, 12, NULL, 'Администратор', 'новая', 'выполнена', 'Статус изменён: новая → выполнена'),
(12, 11, NULL, 'Администратор', NULL, NULL, 'Комментарий обновлён: клиент доволен'),
(13, 10, NULL, 'Администратор', NULL, NULL, 'Комментарий обновлён: спасибо, бронь завершена'),
(14, 11, NULL, 'Администратор', NULL, NULL, 'Комментарий обновлён: бронь завершена, всего доброго'),
(15, 12, NULL, 'Администратор', NULL, NULL, 'Комментарий обновлён: '),
(16, 12, NULL, 'Администратор', 'выполнена', 'новая', 'Статус изменён: выполнена → новая'),
(17, 10, NULL, 'Администратор', 'новая', 'выполнена', 'Статус изменён: новая → выполнена'),
(18, 11, NULL, 'Администратор', NULL, NULL, 'Комментарий обновлён: бронь завершена');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `login` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `full_name`, `phone`, `email`, `login`, `password`) VALUES
(5, 'Иванов Иван Петрович', '+7 928 364 45 90', 'examin@gmail.com', 'ssss', '$2y$10$H8v/Uv2n8DuJXc3pcR58nuice3WbLiDDTUMA.jEmcWENvePEXgenO'),
(6, 'Емелин Михаил Иванович', '+7 988 364 46 97', 'exfjfmin220@gmail.com', 'emelin', '$2y$10$.Fj6l.h/6tqUFzQkjRhxIekPeQ7BXJDU5Gbs/S0KOkSQvxxxMpGYq');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `login` (`login`);

--
-- Индексы таблицы `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_orders_user` (`user_id`);

--
-- Индексы таблицы `order_log`
--
ALTER TABLE `order_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_log_order` (`order_id`),
  ADD KEY `idx_log_admin` (`admin_id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `login` (`login`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT для таблицы `order_log`
--
ALTER TABLE `order_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `fk_orders_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `order_log`
--
ALTER TABLE `order_log`
  ADD CONSTRAINT `fk_log_admin` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_log_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
