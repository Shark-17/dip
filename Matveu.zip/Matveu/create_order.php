<?php
session_start();
include 'includes/db.php';
require 'includes/csrf.php';

if (!isset($_SESSION['user_id'])) { header('Location: login.php'); exit(); }

$user_id = (int) $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT email, full_name FROM users WHERE id=:user_id");
$stmt->execute([':user_id' => $user_id]);
$user       = $stmt->fetch();
$user_email = $user['email'] ?? '';

$allowed_services = ['Средиземноморье', 'Карибский бассейн', 'Северная Европа', 'Дальний Восток'];
$allowed_payments = ['банковская карта', 'наличные'];

$error   = '';
$prefill = [
    'address'      => $user_email,
    'service_type' => 'Средиземноморье',
    'desired_date' => '',
    'desired_time' => '',
    'payment_type' => 'банковская карта',
];
$isRepeat = false;

// Предзаполнение при повторе заказа
if (isset($_GET['repeat']) && is_numeric($_GET['repeat'])) {
    $rs = $conn->prepare("SELECT * FROM orders WHERE id=:id AND user_id=:uid LIMIT 1");
    $rs->execute([':id' => (int)$_GET['repeat'], ':uid' => $user_id]);
    $prev = $rs->fetch();
    if ($prev) {
        $prefill['service_type'] = $prev['service_type'];
        $prefill['payment_type'] = $prev['payment_type'];
        $isRepeat = true;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    $address      = trim($_POST['address']      ?? '');
    $service_type = $_POST['service_type']      ?? '';
    $desired_date = $_POST['desired_date']      ?? '';
    $desired_time = $_POST['desired_time']      ?? '';
    $payment_type = $_POST['payment_type']      ?? '';

    if ($address === '' || $desired_date === '' || $desired_time === '') {
        $error = 'Пожалуйста, заполните все обязательные поля.';
    } elseif (!filter_var($address, FILTER_VALIDATE_EMAIL)) {
        $error = 'Введите корректный email для подтверждения.';
    } elseif ($desired_date < date('Y-m-d')) {
        $error = 'Дата не может быть в прошлом.';
    } elseif (!in_array($service_type, $allowed_services)) {
        $error = 'Выберите корректное направление.';
    } elseif (!in_array($payment_type, $allowed_payments)) {
        $error = 'Выберите корректный способ оплаты.';
    } else {
        $ins = $conn->prepare(
            "INSERT INTO orders (user_id, address, service_type, desired_date, desired_time, payment_type)
             VALUES (:uid, :addr, :svc, :date, :time, :pay)"
        );
        $ins->execute([':uid'=>$user_id,':addr'=>$address,':svc'=>$service_type,
                       ':date'=>$desired_date,':time'=>$desired_time,':pay'=>$payment_type]);
        header('Location: dashboard.php?created=1');
        exit();
    }

    $prefill = compact('address', 'service_type', 'desired_date', 'desired_time', 'payment_type');
}

$today           = date('Y-m-d');
$selectedTariff  = $prefill['service_type'];
$selectedPayment = $prefill['payment_type'];

$destinations = [
    'med'   => ['val'=>'Средиземноморье',  'icon'=>'🌊', 'price'=>'от 90 000 ₽',  'sub'=>'Греция · Италия · Испания',           'days'=>'7–14 дней'],
    'carib' => ['val'=>'Карибский бассейн','icon'=>'🌴', 'price'=>'от 89 000 ₽',  'sub'=>'Куба · Ямайка · Барбадос',            'days'=>'10–18 дней'],
    'neur'  => ['val'=>'Северная Европа',  'icon'=>'🏔', 'price'=>'от 175 000 ₽', 'sub'=>'Норвегия · Исландия · Финляндия',     'days'=>'12–21 день'],
    'fe'    => ['val'=>'Дальний Восток',   'icon'=>'🏯', 'price'=>'от 95 000 ₽',  'sub'=>'Япония · Южная Корея · Владивосток',  'days'=>'10–16 дней'],
];
?>
<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title><?= $isRepeat ? 'Повторное бронирование' : 'Новое бронирование' ?> — Horizons</title>
  <link rel="stylesheet" href="main.css">
  <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,300;1,400&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500&display=swap" rel="stylesheet">
  <style>
    body.booking-page{min-height:100vh;background:linear-gradient(160deg,#060e1c 0%,#0a1e3d 45%,#0d2a52 100%);display:flex;align-items:flex-start;justify-content:center;padding:48px 16px 80px}
    .booking-card{width:100%;max-width:600px;background:rgba(13,33,68,.72);border:1px solid rgba(201,168,96,.18);border-radius:20px;padding:48px 44px;backdrop-filter:blur(16px);box-shadow:0 24px 64px rgba(6,14,28,.55)}
    .bk-logo{display:flex;align-items:center;justify-content:center;gap:10px;text-decoration:none;margin-bottom:32px}
    .bk-logo-anchor{font-size:1.5rem}
    .bk-logo-text{font-family:'Cormorant Garamond',serif;font-size:1.6rem;font-weight:600;color:#fff;letter-spacing:.05em}
    .bk-title{font-family:'Cormorant Garamond',serif;font-size:2rem;font-weight:300;color:#e8f0f7;text-align:center;margin-bottom:6px}
    .bk-sub{text-align:center;color:#7ba3bc;font-size:.88rem;margin-bottom:36px}
    .bk-label{display:block;font-size:.72rem;font-weight:600;color:#7ba3bc;letter-spacing:.1em;text-transform:uppercase;margin-bottom:12px}
    .dest-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:28px}
    .dest-radio{display:none}
    .dest-label{display:flex;align-items:center;gap:14px;padding:16px 18px;border:1.5px solid rgba(255,255,255,.1);border-radius:14px;cursor:pointer;background:rgba(255,255,255,.04);position:relative;overflow:hidden}
    .dest-radio:checked + .dest-label{border-color:#c9a860;background:rgba(201,168,96,.1)}
    .dest-check{position:absolute;top:10px;right:12px;width:18px;height:18px;border:1.5px solid rgba(255,255,255,.2);border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0}
    .dest-radio:checked + .dest-label .dest-check{background:#c9a860;border-color:#c9a860}
    .dest-radio:checked + .dest-label .dest-check::after{content:'✓';font-size:.65rem;color:#060e1c;font-weight:700}
    .dest-icon{font-size:1.7rem;flex-shrink:0;line-height:1}
    .dest-info{min-width:0}
    .dest-name{font-family:'Cormorant Garamond',serif;font-size:1.05rem;font-weight:600;color:#e8f0f7;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
    .dest-sub{font-size:.72rem;color:#7ba3bc;margin-top:1px}
    .dest-price{font-size:.75rem;font-weight:600;color:#c9a860;margin-top:4px}
    .bk-field{margin-bottom:20px}
    .bk-field input,.bk-field select{width:100%;padding:13px 16px;background:rgba(255,255,255,.07);border:1.5px solid rgba(255,255,255,.1);border-radius:12px;color:#e8f0f7;font-family:'DM Sans',sans-serif;font-size:.92rem;outline:none;appearance:none}
    .bk-field input::placeholder{color:rgba(123,163,188,.45)}
    .bk-field input:focus,.bk-field select:focus{border-color:#c9a860;background:rgba(201,168,96,.05)}
    .bk-field select{cursor:pointer;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 20 20'%3E%3Cpath fill='%237ba3bc' d='M6 8l4 4 4-4'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 14px center;background-size:18px}
    .bk-field select option{background:#0d2144}
    .bk-row{display:grid;grid-template-columns:1fr 1fr;gap:12px}
    .bk-divider{height:1px;background:rgba(255,255,255,.08);margin:28px 0}
    .bk-error{background:rgba(220,38,38,.15);border:1px solid rgba(220,38,38,.4);color:#fca5a5;padding:12px 16px;border-radius:12px;font-size:.88rem;margin-bottom:24px}
    .bk-submit{width:100%;padding:15px;background:#c9a860;color:#060e1c;font-family:'DM Sans',sans-serif;font-weight:600;font-size:.95rem;border:none;border-radius:100px;cursor:pointer;letter-spacing:.02em}
    .bk-back{text-align:center;margin-top:20px;font-size:.84rem;color:#7ba3bc}
    .bk-back a{color:#c9a860;text-decoration:none}
    .repeat-badge{display:flex;justify-content:center;align-items:center;gap:6px;padding:5px 14px;border-radius:100px;background:rgba(201,168,96,.12);border:1px solid rgba(201,168,96,.3);color:#c9a860;font-size:.75rem;font-weight:500;letter-spacing:.06em;text-transform:uppercase;margin-bottom:20px}
    @media(max-width:560px){.booking-card{padding:32px 20px}.dest-grid,.bk-row{grid-template-columns:1fr}}
  </style>
</head>
<body class="booking-page">
  <div class="booking-card">
    <a href="index.html" class="bk-logo">
      <span class="bk-logo-anchor">⚓</span>
      <span class="bk-logo-text">Horizons</span>
    </a>

    <?php if ($isRepeat): ?>
      <div class="repeat-badge">↺ Повторное бронирование</div>
    <?php endif ?>

    <h1 class="bk-title"><?= $isRepeat ? 'Повторить круиз' : 'Новое бронирование' ?></h1>
    <p class="bk-sub"><?= $isRepeat ? 'Данные предзаполнены из прошлого заказа' : 'Выберите направление и удобную дату отправления' ?></p>

    <?php if ($error): ?>
      <div class="bk-error"><?= htmlspecialchars($error) ?></div>
    <?php endif ?>

    <form method="POST" novalidate>
      <?= csrf_field() ?>

      <span class="bk-label">Направление</span>
      <div class="dest-grid">
        <?php foreach ($destinations as $id => $d): ?>
          <input type="radio" name="service_type" id="dest-<?= $id ?>"
                 value="<?= htmlspecialchars($d['val']) ?>" class="dest-radio"
                 <?= $selectedTariff === $d['val'] ? 'checked' : '' ?>>
          <label for="dest-<?= $id ?>" class="dest-label">
            <span class="dest-icon"><?= $d['icon'] ?></span>
            <span class="dest-info">
              <span class="dest-name"><?= htmlspecialchars($d['val']) ?></span>
              <span class="dest-sub"><?= $d['sub'] ?></span>
              <span class="dest-price"><?= $d['price'] ?><?= $d['days'] ? ' · ' . $d['days'] : '' ?></span>
            </span>
            <span class="dest-check"></span>
          </label>
        <?php endforeach ?>
      </div>

      <div class="bk-divider"></div>

      <div class="bk-field">
        <span class="bk-label">Email для подтверждения</span>
        <input type="email" name="address" placeholder="your@email.com"
               value="<?= htmlspecialchars($prefill['address']) ?>" required>
      </div>

      <div class="bk-row">
        <div class="bk-field">
          <span class="bk-label">Дата отправления</span>
          <input type="date" name="desired_date" min="<?= $today ?>"
                 value="<?= htmlspecialchars($prefill['desired_date']) ?>" required>
        </div>
        <div class="bk-field">
          <span class="bk-label">Время отправления</span>
          <input type="time" name="desired_time"
                 value="<?= htmlspecialchars($prefill['desired_time']) ?>" required>
        </div>
      </div>

      <div class="bk-field">
        <span class="bk-label">Способ оплаты</span>
        <select name="payment_type">
          <option value="банковская карта" <?= $selectedPayment === 'банковская карта' ? 'selected' : '' ?>>💳 Банковская карта</option>
          <option value="наличные"         <?= $selectedPayment === 'наличные'         ? 'selected' : '' ?>>💵 Наличные</option>
        </select>
      </div>

      <button type="submit" class="bk-submit">Отправить заявку ⚓</button>
    </form>

    <div class="bk-back"><a href="dashboard.php">← Вернуться в кабинет</a></div>
  </div>
</body>
</html>
