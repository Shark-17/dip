<?php
session_start();
include 'includes/db.php';

if (!isset($_SESSION['user_id'])) { header('Location: login.php'); exit(); }

$user_id = $_SESSION['user_id'];
$uStmt = $conn->prepare("SELECT * FROM users WHERE id=:id");
$uStmt->execute([':id' => $user_id]);
$user = $uStmt->fetch();
if (!$user) { session_destroy(); header('Location: login.php'); exit(); }

// Тарифные цены
$tariffPrices = [
    'Средиземноморье' => 90000,
    'Карибский бассейн' => 89000,
    'Северная Европа'   => 175000,
    'Дальний Восток'    => 95000,
];

// Filters
$filterStatus  = $_GET['status']       ?? 'all';
$filterDate    = $_GET['date']         ?? '';
$filterTariff  = $_GET['tariff']       ?? '';
$sortTariff    = $_GET['sort_tariff']  ?? ''; // 'asc' | 'desc'

$sql    = "SELECT orders.*, last_log.changed_by AS comment_author
        FROM orders
        LEFT JOIN (
            SELECT ol.order_id, ol.changed_by
            FROM order_log ol
            INNER JOIN (
                SELECT order_id, MAX(created_at) AS max_at
                FROM order_log
                WHERE comment IS NOT NULL AND comment != ''
                GROUP BY order_id
            ) AS latest ON latest.order_id = ol.order_id AND latest.max_at = ol.created_at
            WHERE ol.comment IS NOT NULL AND ol.comment != ''
        ) AS last_log ON last_log.order_id = orders.id
        WHERE orders.user_id = :user_id";
$params = [':user_id' => $user_id];

if ($filterStatus !== 'all') { $sql .= " AND status=:status"; $params[':status'] = $filterStatus; }
if ($filterDate   !== '')    { $sql .= " AND desired_date=:date"; $params[':date'] = $filterDate; }
if ($filterTariff !== '')    { $sql .= " AND service_type=:tariff"; $params[':tariff'] = $filterTariff; }

$sql .= " ORDER BY desired_date DESC, desired_time DESC";

$stmt = $conn->prepare($sql);
$stmt->execute($params);
$orders = $stmt->fetchAll();

// Сортировка по цене тарифа (PHP-side)
if ($sortTariff === 'asc' || $sortTariff === 'desc') {
    usort($orders, function($a, $b) use ($tariffPrices, $sortTariff) {
        $pa = isset($tariffPrices[$a['service_type']]) ? $tariffPrices[$a['service_type']] : 0;
        $pb = isset($tariffPrices[$b['service_type']]) ? $tariffPrices[$b['service_type']] : 0;
        return $sortTariff === 'asc' ? ($pa - $pb) : ($pb - $pa);
    });
}

// Stats (always all orders)
$allStmt = $conn->prepare("SELECT * FROM orders WHERE user_id=:uid");
$allStmt->execute([':uid' => $user_id]);
$allOrders = $allStmt->fetchAll();
$total    = count($allOrders);
$done     = 0; $canceled = 0; $active = 0;
foreach ($allOrders as $o) {
    $s = isset($o['status']) ? $o['status'] : '';
    if ($s === 'выполнена') $done++;
    elseif ($s === 'отменена') $canceled++;
    elseif ($s === 'новая') $active++;
}

$statusClass = ['новая' => 'status-new', 'выполнена' => 'status-done', 'отменена' => 'status-canceled'];
$statusLabel = ['новая' => 'Активна',    'выполнена' => 'Завершена',   'отменена' => 'Отменена'];

// Собираем query string без конкретных параметров для удобного построения ссылок
function buildQS($overrides = [], $remove = []) {
    $params = $_GET;
    foreach ($remove as $k) unset($params[$k]);
    foreach ($overrides as $k => $v) $params[$k] = $v;
    return $params ? '?' . http_build_query($params) : '';
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>Личный кабинет — Horizons</title>
  <link rel="stylesheet" href="main.css">
  <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,300;1,400&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500&display=swap" rel="stylesheet">
  <style>
    .filter-tabs{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px}
    .filter-tab{padding:7px 18px;border-radius:100px;text-decoration:none;font-size:.82rem;font-weight:500;border:1.5px solid #e0e8f0;color:var(--slate-light);}
    .filter-tab.active{background:#0d2144;border-color:#0d2144;color:#fff}
    .date-filter{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
    .date-filter input[type=date]{padding:8px 12px;border:1.5px solid #e0e8f0;border-radius:100px;font-family:'DM Sans',sans-serif;font-size:.82rem;color:#1e3a5f;outline:none;background:#fff;}
    .date-filter input[type=date]:focus{border-color:#c9a860}
    .date-filter button{padding:8px 16px;background:#0d2144;color:#fff;border:none;border-radius:100px;font-size:.82rem;cursor:pointer;font-family:'DM Sans',sans-serif}
    .repeat-btn{font-size:.78rem;font-weight:500;text-decoration:none;padding:5px 12px;border-radius:100px;border:1.5px solid #c9a860;color:#9a7c38;white-space:nowrap}
    .profile-card{background:#fff;border:1px solid #dde7f0;border-radius:12px;padding:24px;margin-bottom:32px;display:flex;align-items:center;gap:20px;box-shadow:0 2px 10px rgba(6,14,28,.08)}
    .profile-avatar{width:56px;height:56px;background:#0d2144;border-radius:50%;display:flex;align-items:center;justify-content:center;font-family:'Cormorant Garamond',serif;font-size:1.5rem;color:#c9a860;font-weight:600;flex-shrink:0}
    .profile-info h3{font-family:'Cormorant Garamond',serif;font-size:1.2rem;color:#0d2144;margin-bottom:2px}
    .profile-info p{font-size:.82rem;color:#5a85a8}
    .profile-edit-link{margin-left:auto;font-size:.82rem;color:#c9a860;text-decoration:none;border:1.5px solid #c9a860;padding:6px 14px;border-radius:100px;}
    .sort-btn{padding:7px 14px;border-radius:100px;text-decoration:none;font-size:.82rem;font-weight:500;border:1.5px solid #e0e8f0;color:var(--slate-light);white-space:nowrap}
    .sort-btn.active{background:#c9a860;border-color:#c9a860;color:#fff}
    .tariff-price-badge{font-size:.78rem;color:#9a7c38;font-weight:600;background:rgba(201,168,96,.1);padding:2px 8px;border-radius:100px;display:inline-block;margin-top:2px}
  </style>
</head>
<body class="dash-page">

  <header class="dash-header">
    <div class="container">
      <div class="header-inner">
        <a href="index.html" class="logo" style="text-decoration:none">
          <span class="logo-anchor">⚓</span>
          <span class="logo-text">Horizons</span>
        </a>
        <nav class="dash-nav">
          <a href="dashboard.php" class="active">Мои бронирования</a>
          <a href="create_order.php">Новый круиз</a>
          <a href="profile.php">Профиль</a>
          <a href="index.php">На сайт</a>
          <a href="logout.php" style="color:rgba(232,240,247,.4)">Выйти</a>
        </nav>
      </div>
    </div>
  </header>

  <main class="dash-body">
    <div class="container">

      <div class="dash-welcome">
        <h1>Привет, <?= htmlspecialchars(explode(' ', trim($user['full_name']))[0] ?? 'Гость') ?> 👋</h1>
        <p>Здесь вы можете отслеживать свои бронирования круизов в «Horizons»</p>
      </div>

      <?php if (isset($_GET['created'])): ?>
        <div style="background:rgba(22,163,74,.12);border:1px solid rgba(22,163,74,.3);color:#166534;
                    padding:14px 18px;border-radius:12px;margin-bottom:24px;font-size:.9rem;">
          ✓ Ваша заявка успешно создана! Ожидайте подтверждения.
        </div>
      <?php endif ?>

      <!-- Profile card -->
      <div class="profile-card">
        <div class="profile-avatar"><?= mb_substr($user['full_name'], 0, 1, 'UTF-8') ?></div>
        <div class="profile-info">
          <h3><?= htmlspecialchars($user['full_name']) ?></h3>
          <p><?= htmlspecialchars($user['email']) ?> · <?= htmlspecialchars($user['phone']) ?></p>
        </div>
        <a href="profile.php" class="profile-edit-link">Профиль</a>
      </div>

      <!-- Stats -->
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:16px;margin-bottom:36px">
        <div class="dash-stat-card"><span class="dash-stat-num"><?= $total ?></span><span class="dash-stat-label">Всего бронирований</span></div>
        <div class="dash-stat-card"><span class="dash-stat-num" style="color:#16a34a"><?= $done ?></span><span class="dash-stat-label">Завершено</span></div>
        <div class="dash-stat-card"><span class="dash-stat-num" style="color:#2563eb"><?= $active ?></span><span class="dash-stat-label">Активных</span></div>
        <div class="dash-stat-card"><span class="dash-stat-num" style="color:#dc2626"><?= $canceled ?></span><span class="dash-stat-label">Отменено</span></div>
      </div>

      <a href="create_order.php" class="dash-action">⚓ Новое бронирование</a>

      <!-- Статус-фильтры -->
      <div class="filter-tabs" style="margin-top:24px">
        <a href="dashboard.php" class="filter-tab <?= $filterStatus==='all'?'active':'' ?>">Все</a>
        <a href="<?= buildQS(['status'=>'новая'], []) ?>"     class="filter-tab <?= $filterStatus==='новая'?'active':'' ?>">Активные</a>
        <a href="<?= buildQS(['status'=>'выполнена'], []) ?>" class="filter-tab <?= $filterStatus==='выполнена'?'active':'' ?>">Завершённые</a>
        <a href="<?= buildQS(['status'=>'отменена'], []) ?>"  class="filter-tab <?= $filterStatus==='отменена'?'active':'' ?>">Отменённые</a>
      </div>

      <!-- Фильтр по направлению -->
      <div class="filter-tabs">
        <span style="font-size:.82rem;color:#5a85a8;font-weight:500;align-self:center">Направление:</span>
        <a href="<?= buildQS([], ['tariff']) ?>" class="filter-tab <?= $filterTariff===''?'active':'' ?>">Все</a>
        <?php foreach (array_keys($tariffPrices) as $t): ?>
          <a href="<?= buildQS(['tariff'=>$t], []) ?>" class="filter-tab <?= $filterTariff===$t?'active':'' ?>"><?= htmlspecialchars($t) ?></a>
        <?php endforeach ?>
      </div>

      <!-- Сортировка по цене -->
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:12px;flex-wrap:wrap">
        <span style="font-size:.82rem;color:#5a85a8;font-weight:500">Сортировка по цене:</span>
        <a href="<?= buildQS(['sort_tariff'=>'desc'], []) ?>" class="sort-btn <?= $sortTariff==='desc'?'active':'' ?>">↓ Дороже</a>
        <a href="<?= buildQS(['sort_tariff'=>'asc'],  []) ?>" class="sort-btn <?= $sortTariff==='asc'?'active':'' ?>">↑ Дешевле</a>
        <?php if ($sortTariff !== ''): ?>
          <a href="<?= buildQS([], ['sort_tariff']) ?>" style="font-size:.82rem;color:#dc2626;text-decoration:none">✕ Сбросить сорт.</a>
        <?php endif ?>
      </div>

      <!-- Фильтр по дате -->
      <form method="GET" class="date-filter" style="margin-bottom:20px">
        <?php foreach (['status', 'tariff', 'sort_tariff'] as $keep): ?>
          <?php if (isset($_GET[$keep]) && $_GET[$keep] !== ''): ?>
            <input type="hidden" name="<?= $keep ?>" value="<?= htmlspecialchars($_GET[$keep]) ?>">
          <?php endif ?>
        <?php endforeach ?>
        <label style="font-size:.82rem;color:#5a85a8;font-weight:500">Фильтр по дате отправления:</label>
        <input type="date" name="date" value="<?= htmlspecialchars($filterDate) ?>">
        <button type="submit">Применить</button>
        <?php if ($filterDate): ?>
          <a href="<?= buildQS([], ['date']) ?>" style="font-size:.82rem;color:#dc2626;text-decoration:none">✕ Сбросить дату</a>
        <?php endif ?>
      </form>

      <?php if (empty($orders)): ?>
        <div class="dash-empty">
          <span style="font-size:3rem">🚢</span>
          <p>Бронирований не найдено</p>
          <a href="create_order.php" class="btn-primary" style="margin-top:16px;display:inline-flex">Забронировать круиз</a>
        </div>
      <?php else: ?>
        <div style="overflow-x:auto">
          <table class="orders-table">
            <thead><tr>
              <th>Email</th><th>Тариф</th><th>Цена</th><th>Дата отправления</th>
              <th>Время</th><th>Оплата</th><th>Статус</th><th>Комментарий</th><th>Действие</th>
            </tr></thead>
            <tbody>
            <?php foreach ($orders as $order):
              $status = isset($order['status']) ? $order['status'] : 'новая';
              $class  = isset($statusClass[$status]) ? $statusClass[$status] : 'status-new';
              $label  = isset($statusLabel[$status]) ? $statusLabel[$status] : htmlspecialchars($status);
              $price  = $tariffPrices[$order['service_type']] ?? null;
            ?>
              <tr>
                <td data-label="Email"><?= htmlspecialchars($order['address'] ?? '—') ?></td>
                <td data-label="Тариф"><span style="font-weight:500"><?= htmlspecialchars($order['service_type'] ?? '—') ?></span></td>
                <td data-label="Цена">
                  <?php if ($price !== null): ?>
                    <span class="tariff-price-badge">от <?= number_format($price, 0, '.', ' ') ?> ₽</span>
                  <?php else: ?>
                    <span style="font-size:.82rem;color:#5a85a8">по запросу</span>
                  <?php endif ?>
                </td>
                <td data-label="Дата"><?= date('d.m.Y', strtotime($order['desired_date'] ?? 'now')) ?></td>
                <td data-label="Время"><?= substr($order['desired_time'] ?? '00:00', 0, 5) ?></td>
                <td data-label="Оплата" style="font-size:.82rem;color:var(--slate-light)"><?= htmlspecialchars($order['payment_type'] ?? '—') ?></td>
                <td data-label="Статус"><span class="status-badge <?= $class ?>"><?= $label ?></span></td>
                <td data-label="Коммент." style="font-size:.82rem;color:var(--slate-light);max-width:160px">
                  <?php if (!empty($order['admin_comment'])): ?>
                    <span style="color:#1e3a5f"><?= htmlspecialchars($order['admin_comment']) ?></span>
                    <?php if (!empty($order['comment_author'])): ?>
                      <br><span style="font-size:.74rem;color:#c9a860;opacity:.9">— <?= htmlspecialchars($order['comment_author']) ?></span>
                    <?php endif ?>
                  <?php else: ?>
                    <span style="opacity:.4">—</span>
                  <?php endif ?>
                </td>
                <td data-label="Действие">
                  <a href="create_order.php?repeat=<?= $order['id'] ?>" class="repeat-btn" title="Создать похожий заказ">↺ Повторить</a>
                </td>
              </tr>
            <?php endforeach ?>
            </tbody>
          </table>
        </div>
      <?php endif ?>

    </div>
  </main>
</body>
</html>
