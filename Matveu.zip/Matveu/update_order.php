<?php
session_start();
include 'includes/db.php';

if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header('Location: login.php'); exit();
}

$allowed = ['новая', 'выполнена', 'отменена'];

if (isset($_GET['id']) && isset($_GET['status']) && in_array($_GET['status'], $allowed)) {
    $id        = (int) $_GET['id'];
    $status    = $_GET['status'];
    $adminName = $_SESSION['admin_name'] ?? $_SESSION['admin_login'] ?? 'admin';

    // Получаем старый статус для лога
    $old = $conn->prepare("SELECT status FROM orders WHERE id=:id");
    $old->execute([':id' => $id]);
    $oldRow    = $old->fetch();
    $oldStatus = $oldRow['status'] ?? '';

    $stmt = $conn->prepare("UPDATE orders SET status=:status WHERE id=:id");
    $stmt->execute([':status' => $status, ':id' => $id]);

    // Логируем изменение с именем администратора
    if ($oldStatus !== $status) {
        $log = $conn->prepare(
            "INSERT INTO order_log (order_id, changed_by, old_status, new_status, comment)
             VALUES (:oid, :who, :old, :new, :comment)"
        );
        $log->execute([
            ':oid'     => $id,
            ':who'     => $adminName,
            ':old'     => $oldStatus,
            ':new'     => $status,
            ':comment' => "Статус изменён: $oldStatus → $status",
        ]);
    }
}

$backStatus = isset($_GET['status']) ? '?status=' . urlencode($_GET['status']) : '';
header('Location: admin.php' . $backStatus);
exit();
