<?php
session_start();
include 'includes/db.php';
require 'includes/csrf.php';

if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header('Location: login.php'); exit();
}

// Save comment only (убрали assigned_to)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_comment'])) {
    csrf_verify();
    $orderId = (int)($_POST['order_id'] ?? 0);
    $comment = trim($_POST['admin_comment'] ?? '');
    $stmt = $conn->prepare("UPDATE orders SET admin_comment=:c WHERE id=:id");
    $stmt->execute([':c' => $comment ?: null, ':id' => $orderId]);
    $adminName = $_SESSION['admin_name'] ?? $_SESSION['admin_login'] ?? 'admin';
    $logStmt = $conn->prepare("INSERT INTO order_log (order_id, changed_by, comment) VALUES (:oid,:who,:comment)");
    $logStmt->execute([':oid' => $orderId, ':who' => $adminName, ':comment' => "Комментарий обновлён: $comment"]);
    header('Location: admin.php' . ($_SERVER['QUERY_STRING'] ? '?' . $_SERVER['QUERY_STRING'] : ''));
    exit();
}

$filterStatus = $_GET['status'] ?? 'all';
$search       = trim($_GET['search'] ?? '');

// XLSX Export (native PHP, без зависимостей)
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    $sql = "SELECT orders.id, users.full_name, users.phone, orders.address,
                   orders.service_type, orders.desired_date, orders.desired_time,
                   orders.payment_type, orders.status, orders.admin_comment
            FROM orders JOIN users ON orders.user_id=users.id";
    $params = []; $conditions = [];
    if ($filterStatus !== 'all') { $conditions[] = "orders.status=:status"; $params[':status'] = $filterStatus; }
    if ($search !== '') { $conditions[] = "(users.full_name LIKE :s OR users.phone LIKE :s OR orders.address LIKE :s)"; $params[':s'] = "%$search%"; }
    if ($conditions) $sql .= ' WHERE ' . implode(' AND ', $conditions);
    $sql .= " ORDER BY orders.user_id ASC, orders.id ASC";
    $stmt = $conn->prepare($sql); $stmt->execute($params); $rows = $stmt->fetchAll();

    // Ширины столбцов (в символах Excel)
    $colWidths = [6, 28, 18, 30, 16, 14, 10, 20, 14, 40];
    $headers   = ['ID','Гость','Телефон','Email','Тариф','Дата','Время','Оплата','Статус','Комментарий'];

    // Цвет шапки: тёмно-синий (#0d2144), текст золотой (#c9a860)
    $headerFill = 'FF0D2144';
    $headerFont = 'FFC9A860';

    // Строим XML строки
    $sharedStrings = []; $ssIndex = [];
    function ss($v, &$sharedStrings, &$ssIndex) {
        if (!isset($ssIndex[$v])) { $ssIndex[$v] = count($sharedStrings); $sharedStrings[] = $v; }
        return $ssIndex[$v];
    }

    // Собираем данные: заголовки + строки
    $xlsRows = [];
    $hRow = [];
    foreach ($headers as $h) $hRow[] = ['t'=>'s','v'=>ss($h, $sharedStrings, $ssIndex)];
    $xlsRows[] = $hRow;

    $statusLabels = ['новая'=>'Активна','выполнена'=>'Завершена','отменена'=>'Отменена'];
    foreach ($rows as $r) {
        $xlsRows[] = [
            ['t'=>'n','v'=>$r['id']],
            ['t'=>'s','v'=>ss($r['full_name'],$sharedStrings,$ssIndex)],
            ['t'=>'s','v'=>ss($r['phone'],$sharedStrings,$ssIndex)],
            ['t'=>'s','v'=>ss($r['address'],$sharedStrings,$ssIndex)],
            ['t'=>'s','v'=>ss($r['service_type'],$sharedStrings,$ssIndex)],
            ['t'=>'s','v'=>ss($r['desired_date'] ? date('d.m.Y',strtotime($r['desired_date'])) : '',$sharedStrings,$ssIndex)],
            ['t'=>'s','v'=>ss(substr($r['desired_time']??'',0,5),$sharedStrings,$ssIndex)],
            ['t'=>'s','v'=>ss($r['payment_type'],$sharedStrings,$ssIndex)],
            ['t'=>'s','v'=>ss($statusLabels[$r['status']] ?? $r['status'],$sharedStrings,$ssIndex)],
            ['t'=>'s','v'=>ss($r['admin_comment']??'',$sharedStrings,$ssIndex)],
        ];
    }

    // Колонки A..J
    $colLetters = ['A','B','C','D','E','F','G','H','I','J'];

    // sheet1.xml
    $sheetXml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<sheetViews><sheetView workbookViewId="0" showGridLines="1"/></sheetViews>
<sheetFormatPr defaultRowHeight="18"/>
<cols>';
    foreach ($colWidths as $i => $w) {
        $cn = $i+1;
        $sheetXml .= '<col min="'.$cn.'" max="'.$cn.'" width="'.$w.'" customWidth="1"/>';
    }
    $sheetXml .= '</cols><sheetData>';

    foreach ($xlsRows as $ri => $row) {
        $rn = $ri+1;
        $styleIdx = ($ri === 0) ? '1' : '0'; // 1=header style, 0=normal
        $sheetXml .= '<row r="'.$rn.'" ht="'.($ri===0?'22':'16').'" customHeight="1">';
        foreach ($row as $ci => $cell) {
            $cn = $colLetters[$ci].$rn;
            if ($cell['t'] === 'n') {
                $sheetXml .= '<c r="'.$cn.'" s="'.$styleIdx.'"><v>'.htmlspecialchars((string)$cell['v'],ENT_XML1).'</v></c>';
            } else {
                $sheetXml .= '<c r="'.$cn.'" t="s" s="'.$styleIdx.'"><v>'.$cell['v'].'</v></c>';
            }
        }
        $sheetXml .= '</row>';
    }
    $sheetXml .= '</sheetData>
<sheetProtection/></worksheet>';

    // sharedStrings.xml
    $ssXml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="'.count($sharedStrings).'" uniqueCount="'.count($sharedStrings).'">';
    foreach ($sharedStrings as $s) {
        $ssXml .= '<si><t xml:space="preserve">'.htmlspecialchars($s,ENT_XML1,'UTF-8').'</t></si>';
    }
    $ssXml .= '</sst>';

    // styles.xml — normal(0) + header(1)
    $stylesXml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<fonts count="2">
  <font><sz val="10"/><name val="Arial"/></font>
  <font><b/><sz val="10"/><name val="Arial"/><color rgb="'.$headerFont.'"/></font>
</fonts>
<fills count="3">
  <fill><patternFill patternType="none"/></fill>
  <fill><patternFill patternType="gray125"/></fill>
  <fill><patternFill patternType="solid"><fgColor rgb="'.$headerFill.'"/></patternFill></fill>
</fills>
<borders count="2">
  <border><left/><right/><top/><bottom/><diagonal/></border>
  <border><left style="thin"><color rgb="FFD0DCE8"/></left><right style="thin"><color rgb="FFD0DCE8"/></right><top style="thin"><color rgb="FFD0DCE8"/></top><bottom style="thin"><color rgb="FFD0DCE8"/></bottom><diagonal/></border>
</borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="2">
  <xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0"><alignment vertical="center" wrapText="0"/></xf>
  <xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0"><alignment horizontal="center" vertical="center"/></xf>
</cellXfs>
</styleSheet>';

    // Собираем ZIP (.xlsx)
    $files = [
        '_rels/.rels' => '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>',
        'xl/_rels/workbook.xml.rels' => '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings" Target="sharedStrings.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>',
        '[Content_Types].xml' => '<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>',
        'xl/workbook.xml' => '<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Бронирования" sheetId="1" r:id="rId1"/></sheets></workbook>',
        'xl/worksheets/sheet1.xml' => $sheetXml,
        'xl/sharedStrings.xml' => $ssXml,
        'xl/styles.xml' => $stylesXml,
    ];

    $tmpFile = tempnam(sys_get_temp_dir(), 'horizons_xlsx_');
    $zip = new ZipArchive();
    $zip->open($tmpFile, ZipArchive::OVERWRITE);
    foreach ($files as $name => $content) $zip->addFromString($name, $content);
    $zip->close();

    $filename = 'horizons_orders_' . date('Y-m-d') . '.xlsx';
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Length: ' . filesize($tmpFile));
    readfile($tmpFile);
    unlink($tmpFile);
    exit();
}

// Main query
$sql = "SELECT orders.*, users.full_name, users.phone FROM orders JOIN users ON orders.user_id=users.id";
$params = []; $conditions = [];
if ($filterStatus !== 'all') { $conditions[] = "orders.status=:status"; $params[':status'] = $filterStatus; }
if ($search !== '') { $conditions[] = "(users.full_name LIKE :s OR users.phone LIKE :s OR orders.address LIKE :s)"; $params[':s'] = "%$search%"; }
if ($conditions) $sql .= ' WHERE ' . implode(' AND ', $conditions);
$sql .= " ORDER BY orders.user_id ASC, orders.id ASC";
$stmt = $conn->prepare($sql); $stmt->execute($params); $orders = $stmt->fetchAll();

$allStmt = $conn->query("SELECT status, COUNT(*) as cnt FROM orders GROUP BY status");
$stats = []; foreach ($allStmt->fetchAll() as $row) $stats[$row['status']] = $row['cnt'];
$totalOrders = array_sum($stats);

$statusClass = ['новая' => 'status-new', 'выполнена' => 'status-done', 'отменена' => 'status-canceled'];
$statusLabel = ['новая' => 'Активна',    'выполнена' => 'Завершена',   'отменена' => 'Отменена'];

$editOrderId = isset($_GET['edit']) ? (int)$_GET['edit'] : null;
$editOrder = null; $orderLogs = [];
if ($editOrderId) {
    $es = $conn->prepare("SELECT orders.*,users.full_name FROM orders JOIN users ON orders.user_id=users.id WHERE orders.id=:id");
    $es->execute([':id' => $editOrderId]); $editOrder = $es->fetch();
    $ls = $conn->prepare("SELECT * FROM order_log WHERE order_id=:id ORDER BY created_at DESC LIMIT 10");
    $ls->execute([':id' => $editOrderId]); $orderLogs = $ls->fetchAll();
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>Панель администратора — Horizons</title>
  <link rel="stylesheet" href="main.css">
  <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,300;1,400&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500&display=swap" rel="stylesheet">
  <style>
    .filter-tabs{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px}
    .filter-tab{padding:7px 18px;border-radius:100px;text-decoration:none;font-size:.82rem;font-weight:500;border:1.5px solid #e0e8f0;color:var(--slate-light);}
    .filter-tab.active{background:#0d2144;border-color:#0d2144;color:#fff}
    .action-link{font-size:.78rem;font-weight:500;text-decoration:none;padding:5px 12px;border-radius:100px;border:1.5px solid;white-space:nowrap}
    .action-done{border-color:#16a34a;color:#16a34a}
    .action-cancel{border-color:#dc2626;color:#dc2626}
    .action-new{border-color:#2563eb;color:#2563eb}
    .action-edit{border-color:#9a7c38;color:#9a7c38}
    .search-bar{display:flex;gap:10px;margin-bottom:0;flex:1;max-width:500px}
    .search-bar input{flex:1;padding:10px 16px;border:1.5px solid #e0e8f0;border-radius:100px;font-family:'DM Sans',sans-serif;font-size:.88rem;outline:none;color:#1e3a5f;background:#fff}
    .search-bar input:focus{border-color:#c9a860}
    .search-bar button{padding:10px 20px;background:#0d2144;color:#fff;border:none;border-radius:100px;font-size:.84rem;font-weight:500;cursor:pointer;}
    .export-btn{display:inline-flex;align-items:center;gap:6px;padding:10px 18px;background:#16a34a;color:#fff;border-radius:100px;font-size:.82rem;font-weight:500;text-decoration:none;}
    .toolbar{display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:20px}
    .modal-overlay{display:none;position:fixed;inset:0;background:rgba(6,14,28,.7);backdrop-filter:blur(4px);z-index:1000;align-items:center;justify-content:center}
    .modal-overlay.open{display:flex}
    .modal-box{background:#fff;border-radius:16px;padding:36px 32px;max-width:520px;width:95%;max-height:90vh;overflow-y:auto;color:#1e3a5f;box-shadow:0 20px 60px rgba(6,14,28,.4)}
    .modal-box h3{font-family:'Cormorant Garamond',serif;font-size:1.6rem;margin-bottom:20px;color:#0d2144}
    .modal-close{float:right;font-size:1.4rem;cursor:pointer;color:#5a85a8;background:none;border:none;line-height:1}
    .modal-field-label{display:block;font-size:.78rem;font-weight:500;color:#5a85a8;letter-spacing:.04em;text-transform:uppercase;margin-bottom:6px;margin-top:16px}
    .modal-input{width:100%;padding:10px 14px;border:1.5px solid #e0e8f0;border-radius:10px;font-family:'DM Sans',sans-serif;font-size:.9rem;color:#1e3a5f;background:#f4f7fb;outline:none;box-sizing:border-box}
    .modal-input:focus{border-color:#c9a860}
    .modal-save{width:100%;padding:13px;background:#c9a860;color:#060e1c;font-weight:600;font-size:.93rem;border:none;border-radius:100px;cursor:pointer;margin-top:16px}
    .log-entry{padding:10px 0;border-bottom:1px solid #e0e8f0;font-size:.82rem;color:#5a85a8}
    .log-entry:last-child{border-bottom:none}
    .log-time{font-size:.74rem;color:#b0c8d9}
    .comment-preview{max-width:180px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-size:.8rem;color:#5a85a8;font-style:italic}
  </style>
</head>
<body class="admin-page dash-page">

  <header class="dash-header">
    <div class="container">
      <div class="header-inner">
        <a href="index.html" class="logo" style="text-decoration:none">
          <span class="logo-anchor">⚓</span>
          <span class="logo-text">Horizons</span>
        </a>
        <nav class="dash-nav">
          <a href="admin.php" class="active">Бронирования</a>
          <a href="analytics.php">Аналитика</a>
          <a href="admin_profile.php">Профиль</a>
          <a href="logout.php" style="color:rgba(232,240,247,.4)">Выйти</a>
        </nav>
      </div>
    </div>
  </header>

  <main class="dash-body">
    <div class="container">

      <div class="dash-welcome">
        <h1>Панель администратора</h1>
        <p>Управление бронированиями круизного центра «Horizons»</p>
      </div>

      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:16px;margin-bottom:36px">
        <div class="dash-stat-card"><span class="dash-stat-num"><?= $totalOrders ?></span><span class="dash-stat-label">Всего бронирований</span></div>
        <div class="dash-stat-card"><span class="dash-stat-num" style="color:#2563eb"><?= $stats['новая'] ?? 0 ?></span><span class="dash-stat-label">Активных</span></div>
        <div class="dash-stat-card"><span class="dash-stat-num" style="color:#16a34a"><?= $stats['выполнена'] ?? 0 ?></span><span class="dash-stat-label">Завершено</span></div>
        <div class="dash-stat-card"><span class="dash-stat-num" style="color:#dc2626"><?= $stats['отменена'] ?? 0 ?></span><span class="dash-stat-label">Отменено</span></div>
      </div>

      <div class="filter-tabs">
        <a href="admin.php" class="filter-tab <?= $filterStatus === 'all' ? 'active' : '' ?>">Все</a>
        <a href="admin.php?status=новая"     class="filter-tab <?= $filterStatus === 'новая'     ? 'active' : '' ?>">Активные</a>
        <a href="admin.php?status=выполнена" class="filter-tab <?= $filterStatus === 'выполнена' ? 'active' : '' ?>">Завершённые</a>
        <a href="admin.php?status=отменена"  class="filter-tab <?= $filterStatus === 'отменена'  ? 'active' : '' ?>">Отменённые</a>
      </div>

      <div class="toolbar">
        <form method="GET" class="search-bar">
          <?php if ($filterStatus !== 'all'): ?><input type="hidden" name="status" value="<?= htmlspecialchars($filterStatus) ?>"><?php endif ?>
          <input type="text" name="search" placeholder="🔍  Поиск по имени, телефону или email..." value="<?= htmlspecialchars($search) ?>">
          <button type="submit">Найти</button>
          <?php if ($search): ?><a href="admin.php<?= $filterStatus !== 'all' ? '?status=' . urlencode($filterStatus) : '' ?>" style="padding:10px 14px;color:#dc2626;font-size:1.1rem;text-decoration:none">✕</a><?php endif ?>
        </form>
        <a href="admin.php?export=csv<?= $filterStatus !== 'all' ? '&status=' . urlencode($filterStatus) : '' ?><?= $search ? '&search=' . urlencode($search) : '' ?>" class="export-btn">⬇ Экспорт XLSX</a>
      </div>

      <?php if ($search): ?>
        <p style="font-size:.85rem;color:#5a85a8;margin-bottom:16px">Найдено: <strong><?= count($orders) ?></strong> по запросу «<?= htmlspecialchars($search) ?>»</p>
      <?php endif ?>

      <?php if (empty($orders)): ?>
        <div class="dash-empty"><span style="font-size:3rem">📋</span><p>Бронирований не найдено</p></div>
      <?php else: ?>
        <div style="overflow-x:auto">
          <table class="orders-table">
            <thead><tr>
              <th>#</th><th>Гость (по ID ↑)</th><th>Телефон</th><th>Email</th><th>Тариф</th>
              <th>Дата</th><th>Время</th><th>Оплата</th><th>Комментарий</th><th>Статус</th><th>Действия</th>
            </tr></thead>
            <tbody>
            <?php foreach ($orders as $order): ?>
              <tr>
                <td data-label="ID" style="color:var(--slate-light);font-size:.8rem"><?= $order['id'] ?></td>
                <td data-label="Клиент" style="font-weight:500"><?= htmlspecialchars($order['full_name']) ?></td>
                <td data-label="Телефон" style="font-size:.85rem"><?= htmlspecialchars($order['phone']) ?></td>
                <td data-label="Email" style="font-size:.85rem;color:var(--slate-light)"><?= htmlspecialchars($order['address']) ?></td>
                <td data-label="Тариф"><?= htmlspecialchars($order['service_type']) ?></td>
                <td data-label="Дата"><?= date('d.m.Y', strtotime($order['desired_date'])) ?></td>
                <td data-label="Время"><?= substr($order['desired_time'], 0, 5) ?></td>
                <td data-label="Оплата" style="font-size:.8rem;color:var(--slate-light)"><?= htmlspecialchars($order['payment_type']) ?></td>
                <td data-label="Коммент.">
                  <?php if (!empty($order['admin_comment'])): ?>
                    <span class="comment-preview" title="<?= htmlspecialchars($order['admin_comment']) ?>">
                      <?= htmlspecialchars($order['admin_comment']) ?>
                    </span>
                  <?php else: ?>
                    <span style="color:#b0c8d9;font-size:.8rem">—</span>
                  <?php endif ?>
                </td>
                <td data-label="Статус">
                  <span class="status-badge <?= $statusClass[$order['status']] ?? 'status-new' ?>">
                    <?= $statusLabel[$order['status']] ?? htmlspecialchars($order['status']) ?>
                  </span>
                </td>
                <td data-label="Действия">
                  <div style="display:flex;gap:6px;flex-wrap:wrap">
                    <a href="admin.php?edit=<?= $order['id'] ?><?= $filterStatus !== 'all' ? '&status=' . urlencode($filterStatus) : '' ?><?= $search ? '&search=' . urlencode($search) : '' ?>" class="action-link action-edit">✏</a>
                    <?php if ($order['status'] !== 'выполнена'): ?><a href="update_order.php?id=<?= $order['id'] ?>&status=выполнена" class="action-link action-done" onclick="return confirm('Отметить как завершённую?')">✓</a><?php endif ?>
                    <?php if ($order['status'] !== 'новая'): ?><a href="update_order.php?id=<?= $order['id'] ?>&status=новая" class="action-link action-new">↺</a><?php endif ?>
                    <?php if ($order['status'] !== 'отменена'): ?><a href="update_order.php?id=<?= $order['id'] ?>&status=отменена" class="action-link action-cancel" onclick="return confirm('Отменить?')">✕</a><?php endif ?>
                  </div>
                </td>
              </tr>
            <?php endforeach ?>
            </tbody>
          </table>
        </div>
      <?php endif ?>

    </div>
  </main>

  <!-- Edit Modal — только комментарий -->
  <div class="modal-overlay <?= $editOrder ? 'open' : '' ?>" id="editModal">
    <div class="modal-box">
      <?php if ($editOrder): ?>
        <button class="modal-close" onclick="closeModal()">✕</button>
        <h3>Заявка #<?= $editOrder['id'] ?> — <?= htmlspecialchars($editOrder['full_name']) ?></h3>
        <form method="POST">
          <?= csrf_field() ?>
          <input type="hidden" name="order_id" value="<?= $editOrder['id'] ?>">
          <label class="modal-field-label">Комментарий администратора</label>
          <textarea name="admin_comment" rows="5" class="modal-input" style="resize:vertical"><?= htmlspecialchars($editOrder['admin_comment'] ?? '') ?></textarea>
          <button type="submit" name="save_comment" class="modal-save">Сохранить комментарий</button>
        </form>
        <?php if ($orderLogs): ?>
          <div style="margin-top:24px">
            <p style="font-size:.78rem;font-weight:600;color:#5a85a8;text-transform:uppercase;letter-spacing:.05em;margin-bottom:12px">История изменений</p>
            <?php foreach ($orderLogs as $log): ?>
              <div class="log-entry">
                <div><?= htmlspecialchars($log['comment'] ?? '') ?></div>
                <div class="log-time">
                  <?= htmlspecialchars($log['changed_by'] ?? 'admin') ?> ·
                  <?= date('d.m.Y H:i', strtotime($log['created_at'])) ?>
                </div>
              </div>
            <?php endforeach ?>
          </div>
        <?php endif ?>
      <?php endif ?>
    </div>
  </div>

  <script>
    function closeModal() {
      const u = new URL(window.location.href);
      u.searchParams.delete('edit');
      window.location.href = u.toString();
    }
    document.querySelector('.modal-overlay')?.addEventListener('click', function(e) {
      if (e.target === this) closeModal();
    });
  </script>
</body>
</html>
