<?php
session_start();
include 'includes/db.php';

if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header('Location: login.php'); exit();
}

// Orders by date (last 30 days)
$byDate = $conn->query("
    SELECT DATE(desired_date) as d, COUNT(*) as cnt
    FROM orders
    WHERE desired_date >= CURDATE() - INTERVAL 30 DAY
    GROUP BY DATE(desired_date)
    ORDER BY d ASC
")->fetchAll();

// Orders by tariff
$byTariff = $conn->query("
    SELECT service_type, COUNT(*) as cnt
    FROM orders GROUP BY service_type ORDER BY cnt DESC
")->fetchAll();

// Orders by status
$byStatus = $conn->query("
    SELECT status, COUNT(*) as cnt FROM orders GROUP BY status
")->fetchAll();

// Revenue estimate by tariff
$prices  = ['Средиземноморье' => 90000, 'Карибский бассейн' => 89000, 'Северная Европа' => 175000, 'Дальний Восток' => 95000];
$revenue = 0;
foreach ($byTariff as $row) {
    $revenue += ($prices[$row['service_type']] ?? 100000) * $row['cnt'];
}

// Monthly bookings
$byMonth = $conn->query("
    SELECT DATE_FORMAT(desired_date,'%Y-%m') as m, COUNT(*) as cnt
    FROM orders GROUP BY m ORDER BY m ASC LIMIT 12
")->fetchAll();

// Conversion
$total    = $conn->query("SELECT COUNT(*) FROM orders")->fetchColumn();
$done     = $conn->query("SELECT COUNT(*) FROM orders WHERE status='выполнена'")->fetchColumn();
$convRate = $total > 0 ? round($done / $total * 100, 1) : 0;
?>
<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>Аналитика — Horizons</title>
  <link rel="stylesheet" href="main.css">
  <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,300;1,400&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500&display=swap" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
  <style>
    .analytics-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:16px;margin-bottom:36px}
    .chart-card{background:#fff;border:1px solid #dde7f0;border-radius:14px;padding:28px;box-shadow:0 2px 10px rgba(6,14,28,.07);margin-bottom:24px}
    .chart-card h3{font-family:'Cormorant Garamond',serif;font-size:1.25rem;color:#0d2144;margin-bottom:20px}
    .chart-wrap{position:relative;width:100%;max-height:320px}
    .tariff-bar-row{display:flex;align-items:center;gap:12px;margin-bottom:12px}
    .tariff-bar-label{width:120px;font-size:.82rem;color:#5a85a8;flex-shrink:0}
    .tariff-bar-track{flex:1;height:10px;background:#f0f5fa;border-radius:100px;overflow:hidden}
    .tariff-bar-fill{height:100%;border-radius:100px;background:linear-gradient(90deg,#c9a860,#e2c98a);}
    .tariff-bar-count{font-size:.82rem;font-weight:600;color:#0d2144;width:24px;text-align:right;flex-shrink:0}
    .kpi-card{background:#fff;border:1px solid #dde7f0;border-radius:14px;padding:24px;box-shadow:0 2px 10px rgba(6,14,28,.07)}
    .kpi-num{font-family:'Cormorant Garamond',serif;font-size:2.2rem;font-weight:600;color:#0d2144;line-height:1;display:block}
    .kpi-label{font-size:.78rem;color:#5a85a8;font-weight:500;margin-top:4px;display:block}
  </style>
</head>
<body class="admin-page dash-page">

  <header class="dash-header">
    <div class="container">
      <div class="header-inner">
        <a href="index.php" class="logo" style="text-decoration:none">
          <span class="logo-anchor">⚓</span>
          <span class="logo-text">Horizons</span>
        </a>
        <nav class="dash-nav">
          <a href="admin.php">Бронирования</a>
          <a href="analytics.php" class="active">Аналитика</a>
          <a href="admin_profile.php">Профиль</a>
          <a href="logout.php" style="color:rgba(232,240,247,.4)">Выйти</a>
        </nav>
      </div>
    </div>
  </header>

  <main class="dash-body">
    <div class="container">
      <div class="dash-welcome">
        <h1>Аналитика</h1>
        <p>Статистика и показатели круизного центра «Horizons»</p>
      </div>

      <div class="analytics-grid">
        <div class="kpi-card">
          <span class="kpi-num"><?= $total ?></span>
          <span class="kpi-label">Всего бронирований</span>
        </div>
        <div class="kpi-card">
          <span class="kpi-num" style="color:#16a34a"><?= $done ?></span>
          <span class="kpi-label">Завершено круизов</span>
        </div>
        <div class="kpi-card">
          <span class="kpi-num" style="color:#c9a860"><?= number_format($revenue / 1000, 0, '.', ' ') ?>K ₽</span>
          <span class="kpi-label">Выручка (оценка)</span>
        </div>
        <div class="kpi-card">
          <span class="kpi-num" style="color:#2563eb"><?= $convRate ?>%</span>
          <span class="kpi-label">Конверсия статусов</span>
        </div>
      </div>

      <div style="display:grid;grid-template-columns:2fr 1fr;gap:24px;margin-bottom:24px">
        <div class="chart-card">
          <h3>📅 Бронирования по месяцам</h3>
          <div class="chart-wrap"><canvas id="monthChart"></canvas></div>
        </div>
        <div class="chart-card">
          <h3>📊 Статусы</h3>
          <div class="chart-wrap" style="max-height:260px"><canvas id="statusChart"></canvas></div>
        </div>
      </div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:24px">
        <div class="chart-card">
          <h3>📈 Заказы за последние 30 дней</h3>
          <div class="chart-wrap"><canvas id="dateChart"></canvas></div>
        </div>
        <div class="chart-card">
          <h3>🏆 Популярность тарифов</h3>
          <?php
          $maxTariff   = max(array_column($byTariff, 'cnt') ?: [1]);
          $tariffIcons = ['Средиземноморье' => '🌊', 'Карибский бассейн' => '🌴', 'Северная Европа' => '🏔', 'Дальний Восток' => '🏯'];
          foreach ($byTariff as $row):
            $pct = round($row['cnt'] / $maxTariff * 100);
          ?>
            <div class="tariff-bar-row">
              <span class="tariff-bar-label"><?= ($tariffIcons[$row['service_type']] ?? '⚓') . ' ' . htmlspecialchars($row['service_type']) ?></span>
              <div class="tariff-bar-track"><div class="tariff-bar-fill" style="width:<?= $pct ?>%"></div></div>
              <span class="tariff-bar-count"><?= $row['cnt'] ?></span>
            </div>
          <?php endforeach ?>
        </div>
      </div>

    </div>
  </main>

<script>
const NAVY='#0d2144', GOLD='#c9a860', SLATE='#5a85a8';
const gridColor='rgba(30,58,95,.1)';

const monthLabels = <?= json_encode(array_column($byMonth, 'm')) ?>;
const monthData   = <?= json_encode(array_column($byMonth, 'cnt')) ?>;
new Chart(document.getElementById('monthChart'), {
  type: 'line',
  data: {labels: monthLabels, datasets: [{label:'Бронирований',data:monthData,borderColor:GOLD,backgroundColor:'rgba(201,168,96,.12)',borderWidth:2.5,pointBackgroundColor:GOLD,pointRadius:4,fill:true,tension:.4}]},
  options: {responsive:true,animation:false,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true,ticks:{stepSize:1,color:SLATE},grid:{color:gridColor}},x:{ticks:{color:SLATE},grid:{display:false}}}}
}); = <?= json_encode(array_column($byStatus, 'status')) ?>;
const statusData   = <?= json_encode(array_column($byStatus, 'cnt')) ?>;
const statusColors = {'новая':'#2563eb','выполнена':'#16a34a','отменена':'#dc2626'};
new Chart(document.getElementById('statusChart'), {
  type: 'doughnut',
  data: {labels:statusLabels,datasets:[{data:statusData,backgroundColor:statusLabels.map(l=>statusColors[l]||GOLD),borderWidth:0}]},
  options: {responsive:true,animation:false,cutout:'65%',plugins:{legend:{position:'bottom',labels:{color:SLATE,font:{size:12},padding:12}}}}
});

const dateLabels = <?= json_encode(array_column($byDate, 'd')) ?>;
const dateData   = <?= json_encode(array_column($byDate, 'cnt')) ?>;
new Chart(document.getElementById('dateChart'), {
  type: 'bar',
  data: {labels:dateLabels,datasets:[{label:'Заказов',data:dateData,backgroundColor:'rgba(201,168,96,.7)',borderRadius:6}]},
  options: {responsive:true,animation:false,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true,ticks:{stepSize:1,color:SLATE},grid:{color:gridColor}},x:{ticks:{color:SLATE,maxRotation:45},grid:{display:false}}}}
});
</script>
</body>
</html>
