<?php
session_start();
require 'includes/db.php';

if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header('Location: login.php');
    exit();
}

// ── Цены тарифов для расчёта выручки ──
$tariffPrices = [
    'Silver'      => 15000,
    'Gold'        => 50000,
    'Diamond'     => 150000,
    'Свой тариф'  => 0,
];

// ── KPI ──
$totalOrders = (int) $conn->query("SELECT COUNT(*) FROM orders")->fetchColumn();
$doneOrders  = (int) $conn->query("SELECT COUNT(*) FROM orders WHERE status = 'выполнена'")->fetchColumn();
$conversion  = $totalOrders > 0 ? round($doneOrders / $totalOrders * 100, 1) : 0;

// Выручка: сумма цен тарифов всех заявок
$revenueRows = $conn->query("SELECT service_type, COUNT(*) as cnt FROM orders GROUP BY service_type")->fetchAll();
$revenue = 0;
foreach ($revenueRows as $row) {
    $price    = $tariffPrices[$row['service_type']] ?? 0;
    $revenue += $price * (int) $row['cnt'];
}
$revenueK = round($revenue / 1000, 1); // в тысячах ₽

// ── Бронирования по месяцам (последние 12) ──
$monthRows = $conn->query(
    "SELECT DATE_FORMAT(desired_date,'%Y-%m') as ym, COUNT(*) as cnt
     FROM orders
     WHERE desired_date >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
     GROUP BY ym ORDER BY ym ASC"
)->fetchAll();
$monthLabels = [];
$monthData   = [];
foreach ($monthRows as $r) {
    [$y, $m] = explode('-', $r['ym']);
    $monthLabels[] = date('M Y', mktime(0,0,0,(int)$m,1,(int)$y));
    $monthData[]   = (int) $r['cnt'];
}

// ── Статусы (donut) ──
$statusRows = $conn->query("SELECT status, COUNT(*) as cnt FROM orders GROUP BY status")->fetchAll();
$statusLabels = [];
$statusData   = [];
$statusColors = ['новая' => '#2563eb', 'выполнена' => '#16a34a', 'отменена' => '#dc2626'];
foreach ($statusRows as $r) {
    $statusLabels[] = ucfirst($r['status']);
    $statusData[]   = (int) $r['cnt'];
    $statusColorsArr[] = $statusColors[$r['status']] ?? '#aaa';
}

// ── Заказы за последние 30 дней ──
$days30Rows = $conn->query(
    "SELECT DATE(desired_date) as d, COUNT(*) as cnt
     FROM orders
     WHERE desired_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
     GROUP BY d ORDER BY d ASC"
)->fetchAll();
$days30Labels = [];
$days30Data   = [];
foreach ($days30Rows as $r) {
    $days30Labels[] = date('d.m', strtotime($r['d']));
    $days30Data[]   = (int) $r['cnt'];
}

// ── Популярность тарифов ──
$tariffRows = $conn->query(
    "SELECT service_type, COUNT(*) as cnt FROM orders GROUP BY service_type ORDER BY cnt DESC"
)->fetchAll();
$maxTariff = $tariffRows ? max(array_column($tariffRows, 'cnt')) : 1;

$tariffIcons = [
    'Silver'     => '🥈',
    'Gold'       => '🥇',
    'Diamond'    => '💎',
    'Свой тариф' => '✏️',
];
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Аналитика — Alpine Spirit</title>
    <link rel="stylesheet" href="main.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,300;1,400&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <style>
        .analytics-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px;
            margin-bottom: 40px;
        }
        .kpi-card {
            background: var(--white);
            border-radius: var(--radius-lg);
            padding: 28px 24px;
            border: 1px solid rgba(90,159,212,0.1);
            box-shadow: 0 4px 20px rgba(26,42,58,0.05);
        }
        .kpi-icon { font-size: 1.8rem; margin-bottom: 12px; }
        .kpi-value {
            font-family: var(--font-display);
            font-size: 2.4rem;
            font-weight: 600;
            color: var(--slate);
            line-height: 1;
            margin-bottom: 6px;
        }
        .kpi-label {
            font-size: 0.78rem;
            color: var(--slate-light);
            text-transform: uppercase;
            letter-spacing: 0.06em;
        }
        .charts-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 24px;
            margin-bottom: 24px;
        }
        .chart-card {
            background: var(--white);
            border-radius: var(--radius-lg);
            padding: 28px;
            border: 1px solid rgba(90,159,212,0.08);
            box-shadow: 0 4px 20px rgba(26,42,58,0.05);
        }
        .chart-title {
            font-family: var(--font-display);
            font-size: 1.3rem;
            font-weight: 500;
            color: var(--slate);
            margin-bottom: 20px;
        }
        .chart-wrap { position: relative; }
        .progress-bar-outer {
            background: #f0f4f8;
            border-radius: 100px;
            height: 10px;
            overflow: hidden;
            margin: 6px 0 14px;
        }
        .progress-bar-inner {
            height: 100%;
            border-radius: 100px;
            background: linear-gradient(90deg, var(--accent) 0%, var(--accent-dark) 100%);
            
        }
        .tariff-row { margin-bottom: 4px; }
        .tariff-row-head {
            display: flex;
            justify-content: space-between;
            font-size: 0.85rem;
            color: var(--slate);
            margin-bottom: 4px;
        }
        .tariff-row-head span:last-child { color: var(--slate-light); }
        @media (max-width: 900px) {
            .charts-grid { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body class="dash-page">

<header class="dash-header">
    <div class="container">
        <div class="header-inner">
            <a href="index.html" style="text-decoration:none; display:flex; align-items:center; gap:10px;">
                <span style="font-size:1.5rem;">⛷</span>
                <span class="logo-text">Alpine <em>Spirit</em></span>
            </a>
            <nav class="dash-nav">
                <a href="admin.php">Бронирования</a>
                <a href="analytics.php" class="active">Аналитика</a>
                <a href="admin_profile.php">Профиль</a>
                <a href="logout.php" style="color:rgba(255,255,255,0.45);">Выйти</a>
            </nav>
        </div>
    </div>
</header>

<main class="dash-body">
    <div class="container">

        <div class="dash-welcome">
            <h1>Аналитика</h1>
            <p>Статистика по бронированиям горнолыжного курорта</p>
        </div>

        <!-- KPI карточки -->
        <div class="analytics-grid">
            <div class="kpi-card">
                <div class="kpi-icon">📋</div>
                <div class="kpi-value"><?= $totalOrders ?></div>
                <div class="kpi-label">Всего бронирований</div>
            </div>
            <div class="kpi-card">
                <div class="kpi-icon">✅</div>
                <div class="kpi-value" style="color:#16a34a;"><?= $doneOrders ?></div>
                <div class="kpi-label">Завершено круизов</div>
            </div>
            <div class="kpi-card">
                <div class="kpi-icon">💰</div>
                <div class="kpi-value" style="color:var(--gold);"><?= number_format($revenueK, 1, '.', ' ') ?> тыс.</div>
                <div class="kpi-label">Выручка (оценка, ₽)</div>
            </div>
            <div class="kpi-card">
                <div class="kpi-icon">📈</div>
                <div class="kpi-value" style="color:var(--accent);"><?= $conversion ?>%</div>
                <div class="kpi-label">Конверсия в выполненные</div>
            </div>
        </div>

        <!-- Линейный + Donut -->
        <div class="charts-grid">
            <div class="chart-card">
                <div class="chart-title">📅 Бронирования по месяцам</div>
                <div class="chart-wrap" style="height:260px;">
                    <canvas id="monthChart"></canvas>
                </div>
            </div>
            <div class="chart-card">
                <div class="chart-title">🔵 Статусы заявок</div>
                <div class="chart-wrap" style="height:260px;">
                    <canvas id="statusChart"></canvas>
                </div>
            </div>
        </div>

        <!-- Столбчатый + Прогресс-бары -->
        <div class="charts-grid">
            <div class="chart-card">
                <div class="chart-title">📊 Заказы за последние 30 дней</div>
                <div class="chart-wrap" style="height:260px;">
                    <canvas id="days30Chart"></canvas>
                </div>
            </div>
            <div class="chart-card">
                <div class="chart-title">🏆 Популярность тарифов</div>
                <?php foreach ($tariffRows as $row): ?>
                    <?php
                    $pct   = $maxTariff > 0 ? round($row['cnt'] / $maxTariff * 100) : 0;
                    $icon  = $tariffIcons[$row['service_type']] ?? '⛷';
                    ?>
                    <div class="tariff-row">
                        <div class="tariff-row-head">
                            <span><?= $icon ?> <?= htmlspecialchars($row['service_type']) ?></span>
                            <span><?= $row['cnt'] ?> зак.</span>
                        </div>
                        <div class="progress-bar-outer">
                            <div class="progress-bar-inner" style="width:<?= $pct ?>%"></div>
                        </div>
                    </div>
                <?php endforeach; ?>
                <?php if (empty($tariffRows)): ?>
                    <p style="color:var(--slate-light); font-size:0.9rem;">Пока нет данных</p>
                <?php endif; ?>
            </div>
        </div>

    </div>
</main>

<script>
const accentColor = '#5a9fd4';
const goldColor   = '#c9a94a';

// ── Линейный: по месяцам ──
new Chart(document.getElementById('monthChart'), {
    type: 'line',
    data: {
        labels: <?= json_encode($monthLabels, JSON_UNESCAPED_UNICODE) ?>,
        datasets: [{
            label: 'Бронирований',
            data: <?= json_encode($monthData) ?>,
            borderColor: goldColor,
            backgroundColor: 'rgba(201,169,74,0.12)',
            borderWidth: 2.5,
            pointRadius: 5,
            pointBackgroundColor: goldColor,
            fill: true,
            tension: 0.35,
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
            y: { beginAtZero: true, ticks: { precision: 0 }, grid: { color: '#f0f4f8' } },
            x: { grid: { display: false } }
        }
    }
});

// ── Donut: статусы ──
new Chart(document.getElementById('statusChart'), {
    type: 'doughnut',
    data: {
        labels: <?= json_encode($statusLabels, JSON_UNESCAPED_UNICODE) ?>,
        datasets: [{
            data: <?= json_encode($statusData) ?>,
            backgroundColor: <?= json_encode($statusColorsArr ?? []) ?>,
            borderWidth: 0,
            hoverOffset: 6
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '65%',
        plugins: {
            legend: { position: 'bottom', labels: { padding: 16, font: { size: 12 } } }
        }
    }
});

// ── Столбчатый: 30 дней ──
new Chart(document.getElementById('days30Chart'), {
    type: 'bar',
    data: {
        labels: <?= json_encode($days30Labels, JSON_UNESCAPED_UNICODE) ?>,
        datasets: [{
            label: 'Заказов',
            data: <?= json_encode($days30Data) ?>,
            backgroundColor: goldColor,
            borderRadius: 6,
            borderSkipped: false,
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
            y: { beginAtZero: true, ticks: { precision: 0 }, grid: { color: '#f0f4f8' } },
            x: { grid: { display: false }, ticks: { maxRotation: 45, font: { size: 10 } } }
        }
    }
});
</script>

</body>
</html>
