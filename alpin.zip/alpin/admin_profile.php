<?php
session_start();
require 'includes/db.php';
require 'includes/csrf.php';

if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header('Location: login.php');
    exit();
}

// Получаем данные администратора (фолбэк: первый в таблице)
$adminId = $_SESSION['admin_id'] ?? null;
if ($adminId) {
    $aStmt = $conn->prepare("SELECT * FROM admins WHERE id = :id LIMIT 1");
    $aStmt->execute([':id' => (int) $adminId]);
    $admin = $aStmt->fetch();
}
if (empty($admin)) {
    $admin = $conn->query("SELECT * FROM admins LIMIT 1")->fetch();
}
if (!$admin) {
    die('Администратор не найден.');
}

$success = false;
$error   = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    $full_name = trim($_POST['full_name'] ?? '');
    $new_pass  = $_POST['new_password']     ?? '';
    $cur_pass  = $_POST['current_password'] ?? '';

    if ($full_name === '') {
        $error = 'Введите имя.';
    } elseif ($new_pass !== '') {
        if (!password_verify($cur_pass, $admin['password'])) {
            $error = 'Текущий пароль указан неверно.';
        } elseif (mb_strlen($new_pass) < 6) {
            $error = 'Новый пароль должен содержать не менее 6 символов.';
        } else {
            $hashed = password_hash($new_pass, PASSWORD_BCRYPT);
            $conn->prepare("UPDATE admins SET full_name=:fn, password=:pw WHERE id=:id")
                 ->execute([':fn' => $full_name, ':pw' => $hashed, ':id' => $admin['id']]);
            $_SESSION['admin_name'] = $full_name;
            $success = true;
            $admin['full_name'] = $full_name;
        }
    } else {
        $conn->prepare("UPDATE admins SET full_name=:fn WHERE id=:id")
             ->execute([':fn' => $full_name, ':id' => $admin['id']]);
        $_SESSION['admin_name'] = $full_name;
        $success = true;
        $admin['full_name'] = $full_name;
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Профиль администратора — Alpine Spirit</title>
    <link rel="stylesheet" href="main.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,300;1,400&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
</head>
<body class="dash-page">

<header class="dash-header">
    <div class="container">
        <div class="header-inner">
            <a href="index.html" style="text-decoration:none; display:flex; align-items:center; gap:10px;">
                <span style="font-size:1.5rem;">⛷</span>
                <span class="logo-text">Alpine <em>Spirit</em></span>
            </a>
            <nav class="dash-nav">
                <a href="admin.php">Бронирования</a>
                <a href="analytics.php">Аналитика</a>
                <a href="admin_profile.php" class="active">Профиль</a>
                <a href="logout.php" style="color:rgba(255,255,255,0.45);">Выйти</a>
            </nav>
        </div>
    </div>
</header>

<main class="dash-body">
    <div class="container" style="max-width:600px;">

        <div class="dash-welcome">
            <h1>Профиль администратора</h1>
            <p>Управление учётной записью</p>
        </div>

        <!-- Инфо-карточка -->
        <div style="background:var(--white); border-radius:var(--radius-lg); padding:32px;
                    box-shadow:0 4px 20px rgba(26,42,58,0.06); margin-bottom:28px;
                    display:flex; align-items:center; gap:24px;">
            <div style="width:72px; height:72px; border-radius:50%;
                        background:linear-gradient(135deg,#1a3a5c,#243d52);
                        display:flex; align-items:center; justify-content:center;
                        font-size:2rem; flex-shrink:0;">⚙️</div>
            <div>
                <div style="font-family:var(--font-display); font-size:1.5rem; color:var(--slate); font-weight:500;">
                    <?= htmlspecialchars($admin['full_name']) ?>
                </div>
                <div style="font-size:0.82rem; color:var(--slate-light); margin-top:4px;">Администратор системы</div>
            </div>
        </div>

        <!-- Данные -->
        <div style="background:var(--white); border-radius:var(--radius-lg); padding:28px;
                    box-shadow:0 4px 20px rgba(26,42,58,0.06); margin-bottom:28px;">
            <div style="font-size:0.75rem; text-transform:uppercase; letter-spacing:0.1em;
                        color:var(--slate-light); margin-bottom:16px; font-weight:500;">Информация</div>
            <div style="display:grid; gap:12px;">
                <?php foreach (['Имя' => $admin['full_name'], 'Логин' => $admin['login']] as $lbl => $val): ?>
                <div style="display:flex; justify-content:space-between; padding:10px 0;
                            border-bottom:1px solid #f0f4f8;">
                    <span style="font-size:0.82rem; color:var(--slate-light);"><?= $lbl ?></span>
                    <span style="font-size:0.9rem; font-weight:500; color:var(--slate);"><?= htmlspecialchars($val) ?></span>
                </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Форма -->
        <?php if ($success): ?>
            <div style="background:#f0fdf4; border:1px solid #bbf7d0; color:#16a34a;
                        padding:12px 16px; border-radius:12px; margin-bottom:24px; font-size:0.9rem;">
                ✓ Данные успешно сохранены
            </div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="auth-error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div style="background:var(--white); border-radius:var(--radius-lg); padding:32px;
                    box-shadow:0 4px 20px rgba(26,42,58,0.06);">
            <form method="POST" novalidate>
                <?= csrf_field() ?>

                <div class="form-group">
                    <label for="full_name">Отображаемое имя</label>
                    <input type="text" id="full_name" name="full_name" required
                           value="<?= htmlspecialchars($admin['full_name']) ?>">
                </div>

                <hr style="border:none; border-top:1px solid #e0e8f0; margin:24px 0;">
                <p style="font-size:0.82rem; color:var(--slate-light); margin-bottom:16px;">
                    Оставьте поля пароля пустыми, если не хотите его менять.
                </p>

                <div class="form-group">
                    <label for="current_password">Текущий пароль</label>
                    <input type="password" id="current_password" name="current_password"
                           placeholder="Введите текущий пароль" autocomplete="current-password">
                </div>
                <div class="form-group">
                    <label for="new_password">Новый пароль</label>
                    <input type="password" id="new_password" name="new_password"
                           placeholder="Минимум 6 символов" minlength="6" autocomplete="new-password">
                </div>

                <button type="submit" class="auth-submit" style="margin-top:8px;">Сохранить изменения</button>
            </form>
        </div>

        <div style="margin-top:20px; text-align:center;">
            <a href="admin.php" style="color:var(--accent); font-size:0.875rem; text-decoration:none;">
                ← Вернуться к бронированиям
            </a>
        </div>
    </div>
</main>

</body>
</html>
