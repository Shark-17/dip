<?php
/**
 * session_check.php
 * Возвращает JSON с состоянием сессии для клиентского JS.
 * Используется главной страницей для переключения кнопок шапки.
 */
header('Content-Type: application/json');
header('Cache-Control: no-store');

session_start();

echo json_encode([
    'admin' => isset($_SESSION['admin']) && $_SESSION['admin'] === true,
    'user'  => isset($_SESSION['user_id']),
]);
