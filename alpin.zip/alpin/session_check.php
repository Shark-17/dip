<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
echo json_encode([
    'admin' => isset($_SESSION['admin']) && $_SESSION['admin'] === true,
    'user'  => isset($_SESSION['user_id']),
]);
