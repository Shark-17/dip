<?php
session_start();
require 'includes/db.php';
require 'includes/csrf.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = (int) $_SESSION['user_id'];

$uStmt = $conn->prepare("SELECT * FROM users WHERE id = :id");
$uStmt->execute([':id' => $user_id]);
$user = $uStmt->fetch();

if (!$user) {
    session_destroy();
    header('Location: login.php');
    exit();
}

$success = false;
$error   = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    $full_name = trim($_POST['full_name'] ?? '');
    $phone     = trim($_POST['phone']     ?? '');
    $email     = trim($_POST['email']     ?? '');
    $new_pass  = $_POST['new_password']   ?? '';
    $cur_pass  = $_POST['current_password'] ?? '';

    if ($full_name === '' || $phone === '' || $email === '') {
        $error = 'Заполните все обязательные поля.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Введите корректный email.';
    } else {
        // Проверяем уникальность email (кроме текущего пользователя)
        $chk = $conn->prepare("SELECT id FROM users WHERE email = :email AND id != :id LIMIT 1");
        $chk->execute([':email' => $email, ':id' => $user_id]);
        if ($chk->fetch()) {
            $error = 'Этот email уже используется другим аккаунтом.';
        } else {
            if ($new_pass !== '') {
                if (!password_verify($cur_pass, $user['password'])) {
                    $error = 'Текущий пароль указан неверно.';
                } elseif (mb_strlen($new_pass) < 8) {
                    $error = 'Новый пароль должен содержать не менее 8 символов.';
                } else {
                    $hashed = password_hash($new_pass, PASSWORD_BCRYPT);
                    $upd    = $conn->prepare(
                        "UPDATE users SET full_name=:fn, phone=:ph, email=:em, password=:pw WHERE id=:id"
                    );
                    $upd->execute([':fn'=>$full_name,':ph'=>$phone,':em'=>$email,':pw'=>$hashed,':id'=>$user_id]);
                    $_SESSION['user_name'] = $full_name;
                    $success = true;
                    // Обновляем локальный массив
                    $user = array_merge($user, ['full_name'=>$full_name,'phone'=>$phone,'email'=>$email]);
                }
            } else {
                $upd = $conn->prepare(
                    "UPDATE users SET full_name=:fn, phone=:ph, email=:em WHERE id=:id"
                );
                $upd->execute([':fn'=>$full_name,':ph'=>$phone,':em'=>$email,':id'=>$user_id]);
                $_SESSION['user_name'] = $full_name;
                $success = true;
                $user    = array_merge($user, ['full_name'=>$full_name,'phone'=>$phone,'email'=>$email]);
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Профиль — Alpine Spirit</title>
    <link rel="stylesheet" href="main.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,300;1,400&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
</head>
<body class="dash-page">

<header class="dash-header">
    <div class="container">
        <div class="header-inner">
            <a href="index.html" style="text-decoration:none; display:flex; align-items:center; gap:10px;">
                <span style="font-size:1.5rem;">⛷</span>
                <span class="logo-text">Alpine <em>Spirit</em></span>
            </a>
            <nav class="dash-nav">
                <a href="dashboard.php">Мои заявки</a>
                <a href="create_order.php">Новая бронь</a>
                <a href="profile.php" class="active">Профиль</a>
                <a href="index.html">На сайт</a>
                <a href="logout.php" style="color:rgba(255,255,255,0.45);">Выйти</a>
            </nav>
        </div>
    </div>
</header>

<main class="dash-body">
    <div class="container" style="max-width:560px;">

        <div class="dash-welcome">
            <h1>Мой профиль</h1>
            <p>Обновите личные данные или смените пароль</p>
        </div>

        <?php if ($success): ?>
            <div style="background:#f0fdf4; border:1px solid #bbf7d0; color:#16a34a;
                        padding:12px 16px; border-radius:12px; margin-bottom:24px; font-size:0.9rem;">
                ✓ Данные успешно сохранены
            </div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="auth-error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div style="background:var(--white); border-radius:var(--radius-lg);
                    padding:32px; box-shadow:0 4px 20px rgba(26,42,58,0.06);">
            <form method="POST" novalidate>
                <?= csrf_field() ?>

                <div class="form-group">
                    <label for="full_name">Полное имя</label>
                    <input type="text" id="full_name" name="full_name" required
                           value="<?= htmlspecialchars($user['full_name']) ?>">
                </div>
                <div class="form-group">
                    <label for="phone">Телефон</label>
                    <input type="tel" id="phone" name="phone" required
                           value="<?= htmlspecialchars($user['phone']) ?>">
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" required
                           value="<?= htmlspecialchars($user['email']) ?>">
                </div>

                <hr style="border:none; border-top:1px solid #e0e8f0; margin:24px 0;">
                <p style="font-size:0.82rem; color:var(--slate-light); margin-bottom:16px;">
                    Оставьте поля пароля пустыми, если не хотите его менять.
                </p>

                <div class="form-group">
                    <label for="current_password">Текущий пароль</label>
                    <input type="password" id="current_password" name="current_password"
                           placeholder="Введите текущий пароль" autocomplete="current-password">
                </div>
                <div class="form-group">
                    <label for="new_password">Новый пароль</label>
                    <input type="password" id="new_password" name="new_password"
                           placeholder="Минимум 8 символов" minlength="8" autocomplete="new-password">
                </div>

                <button type="submit" class="auth-submit" style="margin-top:8px;">Сохранить изменения</button>
            </form>
        </div>

        <div style="margin-top:20px; text-align:center;">
            <a href="dashboard.php" style="color:var(--accent); font-size:0.875rem; text-decoration:none;">
                ← Вернуться к заявкам
            </a>
        </div>

    </div>
</main>

</body>
</html>
