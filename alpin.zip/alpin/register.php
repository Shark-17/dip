<?php
session_start();
require 'includes/db.php';
require 'includes/csrf.php';

if (isset($_SESSION['user_id'])) { header('Location: dashboard.php'); exit(); }

$error  = '';
$fields = ['full_name' => '', 'phone' => '', 'email' => '', 'login' => ''];

$currentYear  = (int) date('Y');
$minBirthYear = $currentYear - 100;
$maxBirthYear = $currentYear - 14;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    $full_name   = trim($_POST['full_name']   ?? '');
    $birth_day   = $_POST['birth_day']        ?? '';
    $birth_month = $_POST['birth_month']      ?? '';
    $birth_year  = $_POST['birth_year']       ?? '';
    $phone       = trim($_POST['phone']       ?? '');
    $email       = trim($_POST['email']       ?? '');
    $login       = trim($_POST['login']       ?? '');
    $password    = $_POST['password']         ?? '';

    $birth_date = '';
    if ($birth_day !== '' && $birth_month !== '' && $birth_year !== ''
        && checkdate((int)$birth_month, (int)$birth_day, (int)$birth_year))
        $birth_date = sprintf('%04d-%02d-%02d', (int)$birth_year, (int)$birth_month, (int)$birth_day);

    $fields = compact('full_name', 'phone', 'email', 'login');

    if ($full_name === '' || $birth_date === '' || $phone === '' || $email === '' || $login === '' || $password === '') {
        $error = $birth_date === '' && $birth_day !== '' ? 'Указана некорректная дата рождения.' : 'Пожалуйста, заполните все поля.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Введите корректный email.';
    } elseif (!preg_match('/^[A-Za-z0-9]{6,}$/', $login)) {
        $error = 'Логин должен содержать только латинские буквы и цифры, минимум 6 символов.';
    } elseif (mb_strlen($password) < 8) {
        $error = 'Пароль должен содержать не менее 8 символов.';
    } else {
        $chk = $conn->prepare("SELECT id FROM users WHERE login = :login LIMIT 1");
        $chk->execute([':login' => $login]);
        if ($chk->fetch()) {
            $error = 'Этот логин уже занят. Выберите другой.';
        } else {
            $chk = $conn->prepare("SELECT id FROM users WHERE email = :email LIMIT 1");
            $chk->execute([':email' => $email]);
            if ($chk->fetch()) {
                $error = 'Аккаунт с таким email уже существует.';
            } else {
                $stmt = $conn->prepare(
                    "INSERT INTO users (full_name, birth_date, phone, email, login, password)
                     VALUES (:full_name, :birth_date, :phone, :email, :login, :password)"
                );
                $stmt->execute([
                    ':full_name'  => $full_name,
                    ':birth_date' => $birth_date,
                    ':phone'      => $phone,
                    ':email'      => $email,
                    ':login'      => $login,
                    ':password'   => password_hash($password, PASSWORD_BCRYPT),
                ]);
                header('Location: login.php?registered=1');
                exit();
            }
        }
    }
}

$selDay   = (int)($_POST['birth_day']   ?? 0);
$selMonth = (int)($_POST['birth_month'] ?? 0);
$selYear  = (int)($_POST['birth_year']  ?? 0);

$months = [1=>'Январь',2=>'Февраль',3=>'Март',4=>'Апрель',5=>'Май',6=>'Июнь',
           7=>'Июль',8=>'Август',9=>'Сентябрь',10=>'Октябрь',11=>'Ноябрь',12=>'Декабрь'];
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Регистрация — Водить.РФ</title>
    <link rel="stylesheet" href="main.css">
    <style>
        .birth-date-row { display:grid; grid-template-columns:1fr 1.6fr 1fr; gap:8px; }
    </style>
</head>
<body class="auth-page">
    <div class="auth-card" style="max-width:520px;">
        <div class="auth-logo">
            <a href="index.html" style="text-decoration:none;">
                <span style="font-size:2rem;">⚓</span>
                <div class="logo-text">Водить<em>.РФ</em></div>
            </a>
        </div>
        <h1 class="auth-title">Создать аккаунт</h1>
        <p class="auth-sub">Зарегистрируйтесь и записывайтесь на курсы онлайн</p>

        <?php if ($error): ?>
            <div class="auth-error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="POST" novalidate>
            <?= csrf_field() ?>
            <div class="form-group">
                <label for="full_name">Полное имя</label>
                <input type="text" id="full_name" name="full_name" placeholder="Иванов Иван Иванович" required
                       value="<?= htmlspecialchars($fields['full_name']) ?>">
            </div>
            <div class="form-group">
                <label>Дата рождения</label>
                <div class="birth-date-row">
                    <select name="birth_day" required>
                        <option value="">День</option>
                        <?php for ($d = 1; $d <= 31; $d++): ?>
                            <option value="<?= $d ?>" <?= $selDay === $d ? 'selected' : '' ?>><?= $d ?></option>
                        <?php endfor; ?>
                    </select>
                    <select name="birth_month" required>
                        <option value="">Месяц</option>
                        <?php foreach ($months as $num => $name): ?>
                            <option value="<?= $num ?>" <?= $selMonth === $num ? 'selected' : '' ?>><?= $name ?></option>
                        <?php endforeach; ?>
                    </select>
                    <select name="birth_year" required>
                        <option value="">Год</option>
                        <?php for ($y = $maxBirthYear; $y >= $minBirthYear; $y--): ?>
                            <option value="<?= $y ?>" <?= $selYear === $y ? 'selected' : '' ?>><?= $y ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label for="phone">Телефон</label>
                <input type="tel" id="phone" name="phone" placeholder="+7 900 000 00 00" required
                       value="<?= htmlspecialchars($fields['phone']) ?>">
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" placeholder="you@example.com" required
                       value="<?= htmlspecialchars($fields['email']) ?>">
            </div>
            <div class="form-group">
                <label for="login">Логин</label>
                <input type="text" id="login" name="login" placeholder="Латиница и цифры, минимум 6 символов"
                       required pattern="[A-Za-z0-9]{6,}" value="<?= htmlspecialchars($fields['login']) ?>">
            </div>
            <div class="form-group">
                <label for="password">Пароль</label>
                <input type="password" id="password" name="password" placeholder="Минимум 8 символов" required minlength="8">
            </div>
            <button type="submit" class="auth-submit">Зарегистрироваться</button>
        </form>

        <div class="auth-link">
            Уже есть аккаунт? <a href="login.php">Войти</a>
        </div>
    </div>
</body>
</html>
