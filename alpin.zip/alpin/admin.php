<?php
session_start();
require 'includes/db.php';
require 'includes/csrf.php';

if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header('Location: login.php');
    exit();
}

// ── Экспорт в Excel (XML Spreadsheet) ──
if (isset($_GET['export']) && $_GET['export'] === 'xlsx') {
    $expStmt = $conn->query(
        "SELECT orders.id, users.full_name, users.phone, orders.address,
                orders.service_type, orders.desired_date, orders.desired_time,
                orders.payment_type, orders.status, orders.admin_comment
         FROM orders JOIN users ON orders.user_id = users.id
         ORDER BY orders.id ASC"
    );
    $rows = $expStmt->fetchAll();

    $filename = 'alpine_spirit_orders_' . date('Y-m-d') . '.xls';
    header('Content-Type: application/vnd.ms-excel; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: max-age=0');

    $x = function($v) { return htmlspecialchars((string)$v, ENT_XML1 | ENT_QUOTES, 'UTF-8'); };
    $cols = ['#','Гость','Телефон','Email','Тариф','Дата','Время','Оплата','Статус','Комментарий'];

    echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    echo '<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
         xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
         xmlns:x="urn:schemas-microsoft-com:office:excel">
<Styles>
  <Style ss:ID="header">
    <Font ss:Bold="1" ss:Color="#C9A860"/>
    <Interior ss:Color="#0D2144" ss:Pattern="Solid"/>
  </Style>
  <Style ss:ID="cell">
    <Borders>
      <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#e0e8f0"/>
    </Borders>
    <Alignment ss:Vertical="Center"/>
  </Style>
</Styles>
<Worksheet ss:Name="Бронирования">
<Table ss:DefaultColumnWidth="80">';

    // Ширины столбцов
    $colWidths = [30, 120, 90, 140, 80, 80, 60, 100, 80, 160];
    foreach ($colWidths as $w) {
        echo '<Column ss:Width="' . $w . '"/>';
    }

    echo '<Row ss:Height="22">';
    foreach ($cols as $col) {
        echo '<Cell ss:StyleID="header"><Data ss:Type="String">' . $x($col) . '</Data></Cell>';
    }
    echo '</Row>';

    foreach ($rows as $r) {
        $date  = $r['desired_date'] ? date('d.m.Y', strtotime($r['desired_date'])) : '';
        $time  = substr($r['desired_time'] ?? '', 0, 5);
        $cells = [
            ['Number', (string)(int)$r['id']],
            ['String', $r['full_name']],
            ['String', $r['phone']],
            ['String', $r['address']],
            ['String', $r['service_type']],
            ['String', $date],
            ['String', $time],
            ['String', $r['payment_type']],
            ['String', $r['status']],
            ['String', $r['admin_comment'] ?? ''],
        ];
        echo '<Row ss:Height="18">';
        foreach ($cells as [$type, $val]) {
            echo '<Cell ss:StyleID="cell"><Data ss:Type="' . $type . '">' . $x((string)$val) . '</Data></Cell>';
        }
        echo '</Row>';
    }
    echo '</Table></Worksheet></Workbook>';
    exit();
}

// ── Модальное окно редактирования ──
$editOrder = null;
$editLog   = [];
if (isset($_GET['edit']) && is_numeric($_GET['edit'])) {
    $editId = (int) $_GET['edit'];
    $eStmt  = $conn->prepare(
        "SELECT orders.*, users.full_name, users.phone
         FROM orders JOIN users ON orders.user_id = users.id
         WHERE orders.id = :id LIMIT 1"
    );
    $eStmt->execute([':id' => $editId]);
    $editOrder = $eStmt->fetch();

    // История изменений (последние 10)
    try {
        $logStmt = $conn->prepare(
            "SELECT order_log.*, admins.full_name AS admin_full_name
             FROM order_log
             LEFT JOIN admins ON order_log.admin_id = admins.id
             WHERE order_log.order_id = :oid
             ORDER BY changed_at DESC LIMIT 10"
        );
        $logStmt->execute([':oid' => $editId]);
        $editLog = $logStmt->fetchAll();
    } catch (PDOException $e) {
        $editLog = []; // таблица может отсутствовать
    }
}

// ── Фильтры ──
$filterStatus = $_GET['status'] ?? 'all';
$search       = trim($_GET['q'] ?? '');
$allowed      = ['all', 'новая', 'выполнена', 'отменена'];
if (!in_array($filterStatus, $allowed)) $filterStatus = 'all';

$where  = [];
$params = [];
if ($filterStatus !== 'all') {
    $where[]           = "orders.status = :status";
    $params[':status'] = $filterStatus;
}
if ($search !== '') {
    $where[]       = "(users.full_name LIKE :q1 OR users.phone LIKE :q2 OR orders.address LIKE :q3)";
    $params[':q1'] = '%' . $search . '%';
    $params[':q2'] = '%' . $search . '%';
    $params[':q3'] = '%' . $search . '%';
}

$sql = "SELECT orders.*, users.full_name, users.phone
        FROM orders JOIN users ON orders.user_id = users.id";
if ($where) $sql .= ' WHERE ' . implode(' AND ', $where);
$sql .= " ORDER BY orders.id ASC";

$stmt = $conn->prepare($sql);
$stmt->execute($params);
$orders = $stmt->fetchAll();

// ── Статистика ──
$statRows = $conn->query("SELECT status, COUNT(*) as cnt FROM orders GROUP BY status")->fetchAll();
$stats    = [];
foreach ($statRows as $row) $stats[$row['status']] = (int) $row['cnt'];
$totalOrders = array_sum($stats);

$statusClass = ['новая' => 'status-new', 'выполнена' => 'status-done', 'отменена' => 'status-canceled'];
$statusLabel = ['новая' => 'Новая',      'выполнена' => 'Выполнена',   'отменена' => 'Отменена'];

// Строим qs для возврата фильтров
$qs = ($filterStatus !== 'all' ? '?status='.urlencode($filterStatus) : '')
    . ($search ? ($filterStatus!=='all'?'&':'?').'q='.urlencode($search) : '');
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Панель администратора — Alpine Spirit</title>
    <link rel="stylesheet" href="main.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,300;1,400&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
    <style>
        .filter-tabs { display:flex; gap:8px; flex-wrap:wrap; margin-bottom:16px; }
        .filter-tab {
            padding:7px 18px; border-radius:100px; text-decoration:none;
            font-size:0.82rem; font-weight:500; border:1.5px solid #e0e8f0;
            color:var(--slate-light); 
        }
        .filter-tab:hover  { border-color:var(--accent); color:var(--accent); }
        .filter-tab.active { background:var(--accent); border-color:var(--accent); color:#fff; }
        .action-link {
            font-size:0.78rem; font-weight:500; text-decoration:none;
            padding:5px 12px; border-radius:100px; border:1.5px solid;
             white-space:nowrap;
        }
        .action-edit   { border-color:var(--gold); color:var(--gold); }
        .action-edit:hover { background:var(--gold); color:#fff; }
        .action-done   { border-color:#16a34a; color:#16a34a; }
        .action-done:hover   { background:#16a34a; color:#fff; }
        .action-cancel { border-color:#dc2626; color:#dc2626; }
        .action-cancel:hover { background:#dc2626; color:#fff; }
        .action-new    { border-color:#2563eb; color:#2563eb; }
        .action-new:hover    { background:#2563eb; color:#fff; }
        .search-bar { display:flex; gap:8px; margin-bottom:20px; }
        .search-bar input {
            flex:1; padding:10px 16px; border:1.5px solid #e0e8f0; border-radius:100px;
            font-family:var(--font-body); font-size:0.9rem; outline:none; 
        }
        .search-bar input:focus { border-color:var(--accent); }
        .search-bar button {
            padding:10px 20px; background:var(--accent); color:#fff; border:none;
            border-radius:100px; cursor:pointer; font-size:0.9rem; 
        }
        .search-bar button:hover { background:var(--accent-dark); }
        .export-btn {
            display:inline-flex; align-items:center; gap:6px;
            padding:8px 18px; border:1.5px solid #16a34a; color:#16a34a;
            border-radius:100px; text-decoration:none; font-size:0.82rem;
            font-weight:500; 
        }
        .export-btn:hover { background:#16a34a; color:#fff; }
        .comment-cell {
            font-size:0.8rem; color:var(--slate-light);
            display:block; max-width:160px;
            white-space:nowrap; overflow:hidden; text-overflow:ellipsis;
        }
        td.td-comment {
            max-width:160px; width:160px;
            overflow:hidden;
        }

        /* ── Модальное окно ── */
        .modal-overlay {
            position:fixed; inset:0; background:rgba(10,20,35,0.6); backdrop-filter:blur(4px);
            z-index:1000; display:flex; align-items:center; justify-content:center; padding:20px;
        }
        .modal-box {
            background:var(--white); border-radius:var(--radius-lg); padding:36px;
            width:100%; max-width:540px; max-height:90vh; overflow-y:auto;
            box-shadow:0 40px 100px rgba(0,0,0,0.3); position:relative;
        }
        .modal-close {
            position:absolute; top:16px; right:20px;
            background:none; border:none; font-size:1.3rem;
            cursor:pointer; color:var(--slate-light); line-height:1;
        }
        .modal-close:hover { color:var(--slate); }
        .modal-title {
            font-family:var(--font-display); font-size:1.5rem; color:var(--slate);
            font-weight:500; margin-bottom:4px;
        }
        .modal-sub { font-size:0.82rem; color:var(--slate-light); margin-bottom:24px; }
        .modal-label {
            font-size:0.75rem; font-weight:500; color:var(--slate-mid);
            text-transform:uppercase; letter-spacing:0.04em; margin-bottom:6px; display:block;
        }
        .modal-textarea {
            width:100%; padding:12px 16px; border:1.5px solid #e0e8f0;
            border-radius:var(--radius); font-family:var(--font-body); font-size:0.9rem;
            color:var(--slate); outline:none; resize:vertical; min-height:100px;
             background:var(--snow);
        }
        .modal-textarea:focus { border-color:var(--accent); background:var(--white); }
        .modal-save-btn {
            margin-top:12px; padding:11px 24px; background:var(--accent); color:#fff;
            border:none; border-radius:100px; cursor:pointer; font-size:0.9rem;
            font-weight:500; 
        }
        .modal-save-btn:hover { background:var(--accent-dark); }
        .log-entry {
            padding:10px 0; border-bottom:1px solid #f0f4f8; font-size:0.82rem;
        }
        .log-entry:last-child { border-bottom:none; }
        .log-text { color:var(--slate); line-height:1.5; }
        .log-time { color:var(--slate-light); font-size:0.75rem; margin-top:2px; }
    </style>
</head>
<body class="admin-page dash-page">

<?php if ($editOrder): ?>
<!-- ── Модальное окно редактирования ── -->
<div class="modal-overlay" id="editModal" onclick="closeModalOnOverlay(event)">
    <div class="modal-box">
        <button class="modal-close" onclick="closeModal()" title="Закрыть">✕</button>
        <div class="modal-title">Заявка #<?= $editOrder['id'] ?></div>
        <div class="modal-sub"><?= htmlspecialchars($editOrder['full_name']) ?> · <?= htmlspecialchars($editOrder['phone']) ?></div>

        <form method="POST" action="update_order.php">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="comment">
            <input type="hidden" name="id" value="<?= (int) $editOrder['id'] ?>">
            <input type="hidden" name="_edit_back" value="<?= htmlspecialchars($qs) ?>">

            <label class="modal-label" for="modal_comment">Комментарий администратора</label>
            <textarea class="modal-textarea" id="modal_comment" name="comment"
                      placeholder="Добавьте комментарий к заявке…"><?= htmlspecialchars($editOrder['admin_comment'] ?? '') ?></textarea>
            <button type="submit" class="modal-save-btn">Сохранить комментарий</button>
        </form>

        <?php if (!empty($editLog)): ?>
        <div style="margin-top:28px;">
            <div style="font-size:0.75rem; text-transform:uppercase; letter-spacing:0.1em;
                        color:var(--slate-light); margin-bottom:12px; font-weight:500;">История изменений</div>
            <?php foreach ($editLog as $log): ?>
            <div class="log-entry">
                <div class="log-text">
                    <?php if (!empty($log['old_status']) && !empty($log['new_status'])): ?>
                        Статус изменён: <strong><?= htmlspecialchars($log['old_status']) ?></strong>
                        → <strong><?= htmlspecialchars($log['new_status']) ?></strong>
                    <?php elseif (!empty($log['comment'])): ?>
                        Комментарий: «<?= htmlspecialchars($log['comment']) ?>»
                    <?php else: ?>
                        Изменение записано
                    <?php endif; ?>
                </div>
                <div class="log-time">
                    <?= htmlspecialchars($log['admin_full_name'] ?? $log['changed_by'] ?? 'admin') ?> ·
                    <?= date('d.m.Y H:i', strtotime($log['changed_at'])) ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php elseif (isset($editLog)): ?>
            <div style="margin-top:24px; font-size:0.82rem; color:var(--slate-light);">История изменений пока пуста.</div>
        <?php endif; ?>
    </div>
</div>
<script>
function closeModal() {
    window.location.href = 'admin.php<?= htmlspecialchars($qs) ?>';
}
function closeModalOnOverlay(e) {
    if (e.target.id === 'editModal') closeModal();
}
document.addEventListener('keydown', function(e) { if (e.key === 'Escape') closeModal(); });
</script>
<?php endif; ?>

<header class="dash-header">
    <div class="container">
        <div class="header-inner">
            <a href="index.html" style="text-decoration:none; display:flex; align-items:center; gap:10px;">
                <span style="font-size:1.5rem;">⛷</span>
                <span class="logo-text">Alpine <em>Spirit</em></span>
            </a>
            <nav class="dash-nav">
                <a href="admin.php" class="active">Бронирования</a>
                <a href="analytics.php">Аналитика</a>
                <a href="admin_profile.php">Профиль</a>
                <a href="logout.php" style="color:rgba(255,255,255,0.45);">Выйти</a>
            </nav>
        </div>
    </div>
</header>

<main class="dash-body">
    <div class="container">

        <div class="dash-welcome">
            <h1>Панель администратора</h1>
            <p>Управление бронированиями горнолыжного курорта Alpine Spirit</p>
        </div>

        <!-- Статистика -->
        <div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(140px,1fr)); gap:16px; margin-bottom:36px;">
            <div class="dash-stat-card">
                <span class="dash-stat-num"><?= $totalOrders ?></span>
                <span class="dash-stat-label">Всего заявок</span>
            </div>
            <div class="dash-stat-card">
                <span class="dash-stat-num" style="color:#2563eb;"><?= $stats['новая'] ?? 0 ?></span>
                <span class="dash-stat-label">Активных</span>
            </div>
            <div class="dash-stat-card">
                <span class="dash-stat-num" style="color:#16a34a;"><?= $stats['выполнена'] ?? 0 ?></span>
                <span class="dash-stat-label">Выполнено</span>
            </div>
            <div class="dash-stat-card">
                <span class="dash-stat-num" style="color:#dc2626;"><?= $stats['отменена'] ?? 0 ?></span>
                <span class="dash-stat-label">Отменено</span>
            </div>
        </div>

        <!-- Поиск + экспорт -->
        <div style="display:flex; gap:12px; align-items:flex-end; flex-wrap:wrap; margin-bottom:16px;">
            <form class="search-bar" method="GET" style="flex:1; min-width:220px; margin:0;">
                <?php if ($filterStatus !== 'all'): ?>
                    <input type="hidden" name="status" value="<?= htmlspecialchars($filterStatus) ?>">
                <?php endif; ?>
                <input type="text" name="q" placeholder="Поиск по имени, телефону, email…"
                       value="<?= htmlspecialchars($search) ?>">
                <button type="submit">Найти</button>
                <?php if ($search): ?>
                    <a href="admin.php<?= $filterStatus !== 'all' ? '?status='.urlencode($filterStatus) : '' ?>"
                       style="padding:10px 14px; color:var(--slate-light); font-size:0.85rem; white-space:nowrap;">✕ Сбросить</a>
                <?php endif; ?>
            </form>
            <a href="admin.php?export=xlsx" class="export-btn">⬇ Экспорт XLSX</a>
        </div>

        <?php if ($search && !empty($orders)): ?>
            <div style="font-size:0.85rem; color:var(--slate-light); margin-bottom:12px;">
                Найдено результатов: <strong><?= count($orders) ?></strong>
            </div>
            </div><!-- /admin-table-wrap -->
        <?php endif; ?>

        <!-- Фильтры по статусу -->
        <div class="filter-tabs">
            <a href="admin.php<?= $search ? '?q='.urlencode($search) : '' ?>"
               class="filter-tab <?= $filterStatus === 'all' ? 'active' : '' ?>">Все</a>
            <?php foreach (['новая' => 'Активные', 'выполнена' => 'Завершённые', 'отменена' => 'Отменённые'] as $val => $lbl): ?>
                <a href="admin.php?status=<?= urlencode($val) ?><?= $search ? '&q='.urlencode($search) : '' ?>"
                   class="filter-tab <?= $filterStatus === $val ? 'active' : '' ?>"><?= $lbl ?></a>
            <?php endforeach; ?>
        </div>

    </div><!-- /container — таблица на всю ширину -->
    <?php if (empty($orders)): ?>
        <div class="container">
            <div class="dash-empty">
                <span style="font-size:3rem;">📋</span>
                <p>Заявок не найдено</p>
            </div>
        </div>
    <?php else: ?>
        <div class="full-table-wrap">
            <div id="tbl-scroll-top"><div id="tbl-scroll-top-inner"></div></div>
            <div id="tbl-scroll" style="overflow-x:auto;">
                <table class="orders-table" style="width:100%; table-layout:auto;">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Гость</th>
                            <th>Телефон</th>
                            <th>Email</th>
                            <th>Тариф</th>
                            <th>Дата</th>
                            <th>Время</th>
                            <th>Оплата</th>
                            <th>Комментарий</th>
                            <th>Статус</th>
                            <th>Действия</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($orders as $order): ?>
                        <tr>
                            <td style="color:var(--slate-light); font-size:0.8rem;"><?= $order['id'] ?></td>
                            <td style="font-weight:500;"><?= htmlspecialchars($order['full_name']) ?></td>
                            <td style="font-size:0.85rem;"><?= htmlspecialchars($order['phone']) ?></td>
                            <td style="font-size:0.85rem; color:var(--slate-light);"><?= htmlspecialchars($order['address']) ?></td>
                            <td><?= htmlspecialchars($order['service_type']) ?></td>
                            <td><?= date('d.m.Y', strtotime($order['desired_date'])) ?></td>
                            <td><?= substr($order['desired_time'], 0, 5) ?></td>
                            <td style="font-size:0.8rem; color:var(--slate-light);"><?= htmlspecialchars($order['payment_type']) ?></td>
                            <td class="td-comment">
                                <?php if ($order['admin_comment']): ?>
                                    <span class="comment-cell"
                                          title="<?= htmlspecialchars($order['admin_comment']) ?>">
                                        <?= htmlspecialchars($order['admin_comment']) ?>
                                    </span>
                                <?php else: ?>
                                    <span style="opacity:.3; font-size:0.8rem;">—</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="status-badge <?= $statusClass[$order['status']] ?? 'status-new' ?>">
                                    <?= $statusLabel[$order['status']] ?? htmlspecialchars($order['status']) ?>
                                </span>
                            </td>
                            <td>
                                <div style="display:flex; gap:6px; flex-wrap:wrap;">
                                    <!-- Редактировать (модал) -->
                                    <a href="admin.php<?= $qs ? $qs . '&' : '?' ?>edit=<?= $order['id'] ?>"
                                       class="action-link action-edit">✏ Ред.</a>
                                    <?php if ($order['status'] !== 'выполнена'): ?>
                                        <a href="update_order.php?id=<?= $order['id'] ?>&status=выполнена&_back=<?= urlencode($qs) ?>"
                                           class="action-link action-done"
                                           onclick="return confirm('Отметить как выполненную?')">✓ Выполнена</a>
                                    <?php endif; ?>
                                    <?php if ($order['status'] !== 'новая'): ?>
                                        <a href="update_order.php?id=<?= $order['id'] ?>&status=новая&_back=<?= urlencode($qs) ?>"
                                           class="action-link action-new">↺ Новая</a>
                                    <?php endif; ?>
                                    <?php if ($order['status'] !== 'отменена'): ?>
                                        <a href="update_order.php?id=<?= $order['id'] ?>&status=отменена&_back=<?= urlencode($qs) ?>"
                                           class="action-link action-cancel"
                                           onclick="return confirm('Отменить заявку?')">✕ Отменить</a>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
</main>


<style>
/* Полоса прокрутки сверху */
#tbl-scroll-top {
    overflow-x: auto;
    overflow-y: hidden;
    height: 12px;
    margin-bottom: 4px;
}
#tbl-scroll-top-inner {
    height: 1px;
}
/* Расширяем таблицу за пределы стандартного контейнера */
.full-table-wrap {
    width: 100%;
    padding: 0 32px;
    box-sizing: border-box;
}
@media (max-width: 768px) {
    .full-table-wrap { padding: 0 12px; }
}
</style>
<script>
(function(){
    var top  = document.getElementById('tbl-scroll-top');
    var bot  = document.getElementById('tbl-scroll');
    if (!top || !bot) return;
    // sync inner width
    function syncWidth(){
        document.getElementById('tbl-scroll-top-inner').style.width = bot.scrollWidth + 'px';
    }
    syncWidth();
    window.addEventListener('resize', syncWidth);
    top.addEventListener('scroll', function(){ bot.scrollLeft = top.scrollLeft; });
    bot.addEventListener('scroll', function(){ top.scrollLeft = bot.scrollLeft; });
})();
</script>
</body>
</html>
