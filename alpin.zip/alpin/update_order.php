<?php
session_start();
require 'includes/db.php';
require 'includes/csrf.php';

if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) { header('Location: login.php'); exit(); }

$allowed_statuses = ['новая', 'идет_обучение', 'обучение_завершено'];
$statusLabel = ['новая'=>'Новая','идет_обучение'=>'Идёт обучение','обучение_завершено'=>'Обучение завершено'];

$id     = (int)($_GET['id']     ?? 0);
$status = $_GET['status']       ?? '';
$back   = $_GET['_back']        ?? '';
$toast  = '';

if ($id > 0 && in_array($status, $allowed_statuses)) {
    $cur = $conn->prepare("SELECT status FROM orders WHERE id = :id LIMIT 1");
    $cur->execute([':id' => $id]);
    $oldStatus = $cur->fetchColumn();

    if ($oldStatus === false) {
        $toast = 'Заявка №' . $id . ' не найдена';
    } elseif ($oldStatus !== $status) {
        $upd = $conn->prepare("UPDATE orders SET status = :status WHERE id = :id");
        $upd->execute([':status' => $status, ':id' => $id]);
        $toast = 'Заявка №' . $id . ': статус изменён на «' . ($statusLabel[$status] ?? $status) . '»';
    }
}

$redirect = 'admin.php' . (($back && preg_match('/^[?&a-zA-Z0-9=_%.-]+$/', $back)) ? $back : '');
$redirect .= (strpos($redirect, '?') !== false ? '&' : '?') . 'toast=' . urlencode($toast);
header('Location: ' . $redirect);
exit();
