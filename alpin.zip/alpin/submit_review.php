<?php
session_start();
require 'includes/db.php';
require 'includes/csrf.php';

if (!isset($_SESSION['user_id'])) { header('Location: login.php'); exit(); }

$user_id = (int)$_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    $order_id = (int)($_POST['order_id'] ?? 0);
    $rating   = (int)($_POST['rating']   ?? 0);
    $text     = trim($_POST['text']      ?? '');

    $stmt = $conn->prepare("SELECT * FROM orders WHERE id = :id AND user_id = :uid LIMIT 1");
    $stmt->execute([':id' => $order_id, ':uid' => $user_id]);
    $order = $stmt->fetch();

    if ($order && $order['status'] !== 'новая' && $rating >= 1 && $rating <= 5 && $text !== '') {
        $ins = $conn->prepare(
            "INSERT INTO reviews (order_id, user_id, rating, text)
             VALUES (:order_id, :user_id, :rating, :text)
             ON DUPLICATE KEY UPDATE rating = :rating2, text = :text2"
        );
        $ins->execute([
            ':order_id' => $order_id,
            ':user_id'  => $user_id,
            ':rating'   => $rating,
            ':text'     => $text,
            ':rating2'  => $rating,
            ':text2'    => $text,
        ]);
    }
}

header('Location: dashboard.php');
exit();
