<?php
session_start();
require 'includes/db.php';
require 'includes/csrf.php';

if (!isset($_SESSION['user_id'])) { header('Location: login.php'); exit(); }

$user_id = (int)$_SESSION['user_id'];

$uStmt = $conn->prepare("SELECT email FROM users WHERE id = :id");
$uStmt->execute([':id' => $user_id]);
$user_email = $uStmt->fetchColumn() ?? '';

$error = '';
$allowed_services = ['Катер', 'Яхта', 'Круизный лайнер'];
$allowed_payments = ['предоплата по QR-коду', 'оплата картой МИР', 'постоплата в офисе организации'];

$todayY = (int)date('Y');
$maxYear = $todayY + 2;
$months = [1=>'Январь',2=>'Февраль',3=>'Март',4=>'Апрель',5=>'Май',6=>'Июнь',
           7=>'Июль',8=>'Август',9=>'Сентябрь',10=>'Октябрь',11=>'Ноябрь',12=>'Декабрь'];

$prefill = ['address'=>$user_email, 'service_type'=>'Катер', 'payment_type'=>'предоплата по QR-коду'];
$selDay = $selMonth = $selYear = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    $address      = trim($_POST['address']      ?? '');
    $service_type = $_POST['service_type']      ?? 'Катер';
    $selDay       = $_POST['desired_day']       ?? '';
    $selMonth     = $_POST['desired_month']     ?? '';
    $selYear      = $_POST['desired_year']      ?? '';
    $desired_time = $_POST['desired_time']      ?? '';
    $payment_type = $_POST['payment_type']      ?? '';

    $validDate = $selDay !== '' && $selMonth !== '' && $selYear !== ''
                 && checkdate((int)$selMonth, (int)$selDay, (int)$selYear);
    $desired_date = $validDate
        ? sprintf('%04d-%02d-%02d', (int)$selYear, (int)$selMonth, (int)$selDay)
        : '';

    if ($address === '' || !$validDate || $desired_time === '') {
        $error = 'Пожалуйста, заполните все обязательные поля.';
    } elseif (!filter_var($address, FILTER_VALIDATE_EMAIL)) {
        $error = 'Введите корректный email для подтверждения.';
    } elseif ($desired_date < date('Y-m-d')) {
        $error = 'Дата не может быть в прошлом.';
    } elseif (!in_array($service_type, $allowed_services)) {
        $error = 'Выберите корректный вид транспорта.';
    } elseif (!in_array($payment_type, $allowed_payments)) {
        $error = 'Выберите корректный способ оплаты.';
    } else {
        $stmt = $conn->prepare(
            "INSERT INTO orders (user_id, address, service_type, desired_date, desired_time, payment_type)
             VALUES (:user_id, :address, :service_type, :desired_date, :desired_time, :payment_type)"
        );
        $stmt->execute([
            ':user_id'      => $user_id,
            ':address'      => $address,
            ':service_type' => $service_type,
            ':desired_date' => $desired_date,
            ':desired_time' => $desired_time,
            ':payment_type' => $payment_type,
        ]);
        header('Location: dashboard.php?created=1');
        exit();
    }

    $prefill = ['address' => $address, 'service_type' => $service_type, 'payment_type' => $payment_type];
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Новая заявка на обучение — Водить.РФ</title>
    <link rel="stylesheet" href="main.css">
    <style>
        .transport-selector { display:grid; grid-template-columns:repeat(3,1fr); gap:10px; margin-bottom:16px; }
        .transport-option { display:none; }
        .transport-card {
            display:flex; flex-direction:column; align-items:center; justify-content:center;
            padding:18px 14px; border:1.5px solid #e0e8f0; border-radius:12px;
            cursor:pointer; background:var(--snow); gap:6px; user-select:none; text-align:center;
        }
        .transport-card .t-icon { font-size:1.6rem; }
        .transport-card .t-name { font-weight:600; color:var(--slate); font-size:0.92rem; }
        .transport-card.selected { border-color:var(--accent); background:rgba(90,159,212,0.06); }
        .transport-card.selected .t-name { color:var(--accent-dark); }
        .date-row { display:grid; grid-template-columns:1fr 1.6fr 1fr; gap:8px; }
    </style>
</head>
<body class="auth-page">
    <div class="auth-card" style="max-width:540px;">
        <div class="auth-logo">
            <a href="index.html" style="text-decoration:none;">
                <span style="font-size:2rem;">⚓</span>
                <div class="logo-text">Водить<em>.РФ</em></div>
            </a>
        </div>
        <h1 class="auth-title">Новая заявка на обучение</h1>
        <p class="auth-sub">Выберите вид транспорта и удобное время</p>

        <?php if ($error): ?>
            <div class="auth-error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="POST" novalidate>
            <?= csrf_field() ?>

            <div class="form-group">
                <label>Вид транспорта</label>
                <div class="transport-selector">
                    <?php
                    $transports = ['Катер'=>'🚤','Яхта'=>'⛵','Круизный лайнер'=>'🛳️'];
                    foreach ($transports as $val => $icon):
                        $sel = $prefill['service_type'] === $val;
                    ?>
                    <div class="transport-card <?= $sel ? 'selected' : '' ?>" onclick="selectTransport('<?= htmlspecialchars($val, ENT_QUOTES) ?>', this)">
                        <input type="radio" name="service_type" value="<?= htmlspecialchars($val) ?>" class="transport-option" <?= $sel ? 'checked' : '' ?>>
                        <span class="t-icon"><?= $icon ?></span>
                        <span class="t-name"><?= htmlspecialchars($val) ?></span>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="form-group">
                <label for="address">Email для подтверждения</label>
                <input type="email" id="address" name="address" placeholder="your@email.com"
                       value="<?= htmlspecialchars($prefill['address']) ?>" required>
            </div>

            <div class="form-group">
                <label>Желаемая дата начала обучения (ДД.ММ.ГГГГ)</label>
                <div class="date-row">
                    <select name="desired_day" required>
                        <option value="">День</option>
                        <?php for ($d = 1; $d <= 31; $d++): ?>
                            <option value="<?= $d ?>" <?= (string)$selDay === (string)$d ? 'selected' : '' ?>><?= $d ?></option>
                        <?php endfor; ?>
                    </select>
                    <select name="desired_month" required>
                        <option value="">Месяц</option>
                        <?php foreach ($months as $num => $name): ?>
                            <option value="<?= $num ?>" <?= (string)$selMonth === (string)$num ? 'selected' : '' ?>><?= $name ?></option>
                        <?php endforeach; ?>
                    </select>
                    <select name="desired_year" required>
                        <option value="">Год</option>
                        <?php for ($y = $todayY; $y <= $maxYear; $y++): ?>
                            <option value="<?= $y ?>" <?= (string)$selYear === (string)$y ? 'selected' : '' ?>><?= $y ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label for="desired_time">Время начала</label>
                <input type="time" id="desired_time" name="desired_time" required>
            </div>

            <div class="form-group">
                <label for="payment_type">Способ оплаты</label>
                <select id="payment_type" name="payment_type">
                    <?php foreach ($allowed_payments as $p): ?>
                        <option value="<?= $p ?>" <?= $prefill['payment_type'] === $p ? 'selected' : '' ?>>
                            <?= htmlspecialchars(ucfirst($p)) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <button type="submit" class="auth-submit">Отправить заявку</button>
        </form>

        <div class="auth-link">
            <a href="dashboard.php">← Вернуться в кабинет</a>
        </div>
    </div>
<script>
function selectTransport(val, card) {
    document.querySelectorAll('.transport-card').forEach(c => c.classList.remove('selected'));
    card.classList.add('selected');
    card.querySelector('input[type="radio"]').checked = true;
}
</script>
</body>
</html>
