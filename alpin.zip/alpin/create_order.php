<?php
session_start();
require 'includes/db.php';
require 'includes/csrf.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = (int) $_SESSION['user_id'];

$uStmt = $conn->prepare("SELECT email, full_name FROM users WHERE id = :id");
$uStmt->execute([':id' => $user_id]);
$user       = $uStmt->fetch();
$user_email = $user['email'] ?? '';

$error = '';

// Предзаполнение при повторе заказа
$prefill = [
    'address'      => $user_email,
    'service_type' => 'Silver',
    'desired_date' => '',
    'desired_time' => '',
    'payment_type' => 'наличные',
];

if (isset($_GET['repeat']) && is_numeric($_GET['repeat'])) {
    $rStmt = $conn->prepare(
        "SELECT * FROM orders WHERE id = :id AND user_id = :uid LIMIT 1"
    );
    $rStmt->execute([':id' => (int) $_GET['repeat'], ':uid' => $user_id]);
    $prev = $rStmt->fetch();
    if ($prev) {
        $prefill['service_type'] = $prev['service_type'];
        $prefill['payment_type'] = $prev['payment_type'];
        // email берём из профиля, дату и время оставляем пустыми (новая дата)
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    $address      = trim($_POST['address']      ?? '');
    $service_type = $_POST['service_type']      ?? 'Silver';
    $desired_date = $_POST['desired_date']       ?? '';
    $desired_time = $_POST['desired_time']       ?? '';
    $payment_type = $_POST['payment_type']       ?? 'наличные';

    $allowed_services  = ['Silver', 'Gold', 'Diamond', 'Свой тариф'];
    $allowed_payments  = ['наличные', 'банковская карта'];

    if ($address === '' || $desired_date === '' || $desired_time === '') {
        $error = 'Пожалуйста, заполните все обязательные поля.';
    } elseif (!filter_var($address, FILTER_VALIDATE_EMAIL)) {
        $error = 'Введите корректный email для подтверждения.';
    } elseif ($desired_date < date('Y-m-d')) {
        $error = 'Дата не может быть в прошлом.';
    } elseif (!in_array($service_type, $allowed_services)) {
        $error = 'Выберите корректный тариф.';
    } elseif (!in_array($payment_type, $allowed_payments)) {
        $error = 'Выберите корректный способ оплаты.';
    } else {
        $stmt = $conn->prepare(
            "INSERT INTO orders (user_id, address, service_type, desired_date, desired_time, payment_type)
             VALUES (:user_id, :address, :service_type, :desired_date, :desired_time, :payment_type)"
        );
        $stmt->execute([
            ':user_id'      => $user_id,
            ':address'      => $address,
            ':service_type' => $service_type,
            ':desired_date' => $desired_date,
            ':desired_time' => $desired_time,
            ':payment_type' => $payment_type,
        ]);
        header('Location: dashboard.php?created=1');
        exit();
    }

    // Если ошибка — сохраняем введённые данные
    $prefill = compact('address', 'service_type', 'desired_date', 'desired_time', 'payment_type');
}

$today = date('Y-m-d');
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Новое бронирование — Alpine Spirit</title>
    <link rel="stylesheet" href="main.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,300;1,400&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
    <style>
        .tariff-selector {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 10px;
            margin-bottom: 16px;
        }
        .tariff-option { display: none; }
        .tariff-option + label {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            padding: 14px 14px;
            border: 1.5px solid #e0e8f0;
            border-radius: 12px;
            cursor: pointer;
            
            background: var(--snow);
            gap: 2px;
        }
        .tariff-option + label .t-icon  { font-size: 1.3rem; margin-bottom: 4px; }
        .tariff-option + label .t-name  { font-weight: 600; color: var(--slate); font-size: 0.92rem; margin-bottom: 1px; }
        .tariff-option + label .t-price { font-size: 0.78rem; color: var(--accent-dark); font-weight: 500; margin-bottom: 8px; }
        .tariff-option + label .t-features {
            list-style: none; margin: 0; padding: 0;
            display: flex; flex-direction: column; gap: 4px;
            width: 100%;
        }
        .tariff-option + label .t-features li {
            font-size: 0.74rem;
            color: var(--slate-light);
            display: flex; align-items: flex-start; gap: 5px;
            line-height: 1.35;
        }
        .tariff-option + label .t-features li::before {
            content: '✓';
            color: #5a9fd4;
            font-weight: 700;
            font-size: 0.65rem;
            flex-shrink: 0;
            margin-top: 1px;
        }
        .tariff-option:checked + label {
            border-color: var(--accent);
            background: rgba(90,159,212,0.06);
        }
        .tariff-option:checked + label .t-name  { color: var(--accent-dark); }
        .tariff-option:checked + label .t-features li { color: var(--slate); }
    </style>
</head>
<body class="auth-page">
    <div class="auth-card" style="max-width:520px;">
        <div class="auth-logo">
            <a href="index.html" style="text-decoration:none;">
                <span style="font-size:2rem;">⛷</span>
                <div class="logo-text">Alpine <em>Spirit</em></div>
            </a>
        </div>

        <h1 class="auth-title">Новое бронирование</h1>
        <p class="auth-sub">Выберите тариф и удобное время</p>

        <?php if ($error): ?>
            <div class="auth-error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="POST" novalidate>
            <?= csrf_field() ?>

            <div class="form-group">
                <label>Выберите тариф</label>
                <div class="tariff-selector">
                    <?php
                    $tariffs = [
                        'Silver' => [
                            'icon'     => '🥈',
                            'name'     => 'Silver',
                            'price'    => 'от 15 000 ₽ / сутки',
                            'features' => [
                                'Доступ к зелёным и синим трассам',
                                '1 подъём на канатной дороге',
                                'Прокат лыж или сноуборда',
                                'Инструктор в комплекте',
                                'VIP-зона апрески',
                            ],
                        ],
                        'Gold' => [
                            'icon'     => '🥇',
                            'name'     => 'Gold',
                            'price'    => 'от 50 000 ₽ / 7 дней',
                            'features' => [
                                'Доступ ко всем трассам',
                                'Безлимитные подъёмники',
                                'Прокат снаряжения',
                                '2 часа с инструктором',
                                'VIP-зона апрески',
                            ],
                        ],
                        'Diamond' => [
                            'icon'     => '💎',
                            'name'     => 'Diamond',
                            'price'    => 'от 150 000 ₽ / месяц',
                            'features' => [
                                'Безлимитный доступ везде',
                                'Персональный инструктор',
                                'Элитное снаряжение',
                                'VIP-зона апрески',
                            ],
                        ],
                        'Свой тариф' => [
                            'icon'     => '✏️',
                            'name'     => 'Свой тариф',
                            'price'    => 'по запросу',
                            'features' => [
                                'Любые услуги на выбор',
                                'Групповые пакеты',
                                'Корпоративные предложения',
                            ],
                        ],
                    ];
                    foreach ($tariffs as $val => $t):
                        $id      = 't-' . preg_replace('/[^a-z0-9]/i', '', mb_strtolower($t['name']));
                        $checked = ($prefill['service_type'] === $val) ? 'checked' : '';
                    ?>
                    <input type="radio" name="service_type" id="<?= $id ?>"
                           value="<?= htmlspecialchars($val) ?>" class="tariff-option" <?= $checked ?>>
                    <label for="<?= $id ?>">
                        <span class="t-icon"><?= $t['icon'] ?></span>
                        <span class="t-name"><?= htmlspecialchars($t['name']) ?></span>
                        <span class="t-price"><?= $t['price'] ?></span>
                        <ul class="t-features">
                            <?php foreach ($t['features'] as $f): ?>
                                <li><?= htmlspecialchars($f) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </label>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="form-group">
                <label for="address">Email для подтверждения</label>
                <input type="email" id="address" name="address"
                       placeholder="your@email.com"
                       value="<?= htmlspecialchars($prefill['address']) ?>" required>
            </div>

            <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
                <div class="form-group">
                    <label for="desired_date">Дата</label>
                    <input type="date" id="desired_date" name="desired_date"
                           min="<?= $today ?>"
                           value="<?= htmlspecialchars($prefill['desired_date']) ?>" required>
                </div>
                <div class="form-group">
                    <label for="desired_time">Время начала</label>
                    <input type="time" id="desired_time" name="desired_time"
                           value="<?= htmlspecialchars($prefill['desired_time']) ?>" required>
                </div>
            </div>

            <div class="form-group">
                <label for="payment_type">Способ оплаты</label>
                <select id="payment_type" name="payment_type">
                    <option value="наличные"
                        <?= $prefill['payment_type'] === 'наличные' ? 'selected' : '' ?>>Наличные</option>
                    <option value="банковская карта"
                        <?= $prefill['payment_type'] === 'банковская карта' ? 'selected' : '' ?>>Банковская карта</option>
                </select>
            </div>

            <button type="submit" class="auth-submit">Отправить заявку</button>
        </form>

        <div class="auth-link">
            <a href="dashboard.php">← Вернуться в кабинет</a>
        </div>
    </div>
</body>
</html>
