<?php
session_start();
require 'includes/db.php';
require 'includes/csrf.php';

// Уже авторизован — редирект
if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit();
}
if (isset($_SESSION['admin'])) {
    header('Location: admin.php');
    exit();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    $login    = trim($_POST['login'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($login === '' || $password === '') {
        $error = 'Заполните все поля.';
    } else {
        // ── Проверяем таблицу admins (безопасно, без хардкода) ──
        $aStmt = $conn->prepare("SELECT * FROM admins WHERE login = :login LIMIT 1");
        $aStmt->execute([':login' => $login]);
        $admin = $aStmt->fetch();

        if ($admin && password_verify($password, $admin['password'])) {
            session_regenerate_id(true);
            $_SESSION['admin']      = true;
            $_SESSION['admin_name'] = $admin['full_name'] ?? 'Администратор';
            $_SESSION['admin_id']   = $admin['id'];
            header('Location: admin.php');
            exit();
        }

        // ── Проверяем обычных пользователей ──
        $stmt = $conn->prepare("SELECT * FROM users WHERE login = :login LIMIT 1");
        $stmt->execute([':login' => $login]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            session_regenerate_id(true);
            $_SESSION['user_id']   = $user['id'];
            $_SESSION['user_name'] = $user['full_name'];
            header('Location: dashboard.php');
            exit();
        }

        $error = 'Неверный логин или пароль.';
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Вход — Alpine Spirit</title>
    <link rel="stylesheet" href="main.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,300;1,400&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
</head>
<body class="auth-page">
    <div class="auth-card">
        <div class="auth-logo">
            <a href="index.html" style="text-decoration:none;">
                <span style="font-size:2rem;">⛷</span>
                <div class="logo-text">Alpine <em>Spirit</em></div>
            </a>
        </div>

        <h1 class="auth-title">Добро пожаловать</h1>
        <p class="auth-sub">Войдите в личный кабинет</p>

        <?php if ($error): ?>
            <div class="auth-error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="POST" novalidate>
            <?= csrf_field() ?>
            <div class="form-group">
                <label for="login">Логин</label>
                <input type="text" id="login" name="login"
                       placeholder="Ваш логин" required autocomplete="username"
                       value="<?= htmlspecialchars($_POST['login'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label for="password">Пароль</label>
                <input type="password" id="password" name="password"
                       placeholder="••••••••" required autocomplete="current-password">
            </div>
            <button type="submit" class="auth-submit">Войти</button>
        </form>

        <div class="auth-link">
            Нет аккаунта? <a href="register.php">Зарегистрироваться</a>
        </div>
    </div>
</body>
</html>
