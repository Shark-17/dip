<?php
/**
 * CSRF-защита
 * Подключайте этот файл в начале каждого PHP-скрипта, обрабатывающего формы.
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Генерирует (или возвращает существующий) CSRF-токен сессии.
 */
function csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Выводит скрытое поле с CSRF-токеном.
 */
function csrf_field(): string {
    return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars(csrf_token()) . '">';
}

/**
 * Проверяет токен из POST-запроса. При неудаче завершает выполнение.
 */
function csrf_verify(): void {
    $token = $_POST['csrf_token'] ?? '';
    if (!hash_equals(csrf_token(), $token)) {
        http_response_code(403);
        die('Недействительный CSRF-токен. Обновите страницу и попробуйте снова.');
    }
}
