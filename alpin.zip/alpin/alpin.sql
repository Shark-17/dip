-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Июн 24 2026 г., 23:02
-- Версия сервера: 8.0.15
-- Версия PHP: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `alpin`
--

-- --------------------------------------------------------

--
-- Структура таблицы `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `full_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `login` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `admins`
--

INSERT INTO `admins` (`id`, `full_name`, `login`, `password`) VALUES
(1, 'Админ', 'admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');

-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Email для подтверждения',
  `service_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `desired_date` date NOT NULL,
  `desired_time` time NOT NULL,
  `payment_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('новая','выполнена','отменена') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'новая',
  `admin_comment` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `address`, `service_type`, `desired_date`, `desired_time`, `payment_type`, `status`, `admin_comment`) VALUES
(1, 1, 'ivan@example.com', 'Gold', '2025-12-20', '09:00:00', 'банковская карта', 'выполнена', 'Клиент доволен, приедет снова'),
(2, 1, 'ivan@example.com', 'Silver', '2025-12-28', '10:30:00', 'наличные', 'новая', NULL),
(3, 2, 'maria@example.com', 'Diamond', '2026-01-05', '08:00:00', 'банковская карта', 'новая', NULL),
(4, 3, 'examin@gmail.com', 'Gold', '2026-06-03', '05:09:00', 'банковская карта', 'выполнена', 'бронь завершена'),
(5, 3, 'examin@gmail.com', 'Silver', '2026-06-03', '02:06:00', 'наличные', 'новая', NULL),
(6, 4, 'tityln@gmail.com', 'Silver', '2026-06-11', '08:37:00', 'банковская карта', 'выполнена', 'бронь завершена, всего доброго'),
(7, 4, 'tityln@gmail.com', 'Свой тариф', '2026-08-30', '05:35:00', 'банковская карта', 'новая', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `order_log`
--

CREATE TABLE `order_log` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `admin_id` int(11) DEFAULT NULL COMMENT 'Кто из администраторов внёс изменение',
  `changed_by` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'admin' COMMENT 'Кто изменил: admin / user',
  `old_status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Старый статус (NULL если менялся только комментарий)',
  `new_status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Новый статус',
  `comment` text COLLATE utf8mb4_unicode_ci COMMENT 'Текст комментария (если менялся)',
  `changed_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `order_log`
--

INSERT INTO `order_log` (`id`, `order_id`, `admin_id`, `changed_by`, `old_status`, `new_status`, `comment`) VALUES
(1, 1, NULL, 'admin', 'новая', 'выполнена', NULL),
(2, 4, 1, 'admin', NULL, NULL, 'good good'),
(3, 5, 1, 'admin', NULL, NULL, 'gooof'),
(4, 4, 1, 'admin', 'новая', 'выполнена', NULL),
(5, 4, 1, 'admin', NULL, NULL, 'бронь завершена'),
(6, 5, 1, 'admin', NULL, NULL, NULL),
(7, 6, 1, 'admin', 'новая', 'выполнена', NULL),
(8, 6, 1, 'admin', NULL, NULL, 'бронь завершена, всего доброго'),
(9, 1, 1, 'admin', NULL, NULL, 'Клиент доволен, приедет снова');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `full_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `login` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `full_name`, `phone`, `email`, `login`, `password`) VALUES
(1, 'Иван Петров', '+7 900 111 22 33', 'ivan@example.com', 'ivan', '$2y$10$ShtzF9vAdnwvlQcKThKQtuoZ0dQAjyq6PbKteBltomQ/S4ls6LiLq'),
(2, 'Мария Сидорова', '+7 900 444 55 66', 'maria@example.com', 'maria', '$2y$10$bf3s1j8zlzQgAhEhScPPWeRvXAqixWrOGgJHjno9lGKCpsQ2Pta2W'),
(3, 'Иванов Иван Петрович', '+7 928 364 45 90', 'examin@gmail.com', 'sss', '$2y$10$dxjuztcZ9I/SR8v54SFdMuxmG.mxoUuxCpu76ijSO8o8JBfFf66eW'),
(4, 'Матеев Вадим Владимирович', '+7 928 365 40 91', 'tityln@gmail.com', 'mati', '$2y$10$/aKp9a4rNH3VD1bVGfDd.uovChjXRfywCNRPNjTdPRHlhEZOk26k6');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `login` (`login`);

--
-- Индексы таблицы `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `status` (`status`),
  ADD KEY `desired_date` (`desired_date`);

--
-- Индексы таблицы `order_log`
--
ALTER TABLE `order_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `changed_at` (`changed_at`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `login` (`login`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT для таблицы `order_log`
--
ALTER TABLE `order_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `order_log`
--
ALTER TABLE `order_log`
  ADD CONSTRAINT `order_log_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `order_log_ibfk_2` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
