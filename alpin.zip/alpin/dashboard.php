<?php
session_start();
require 'includes/db.php';
require 'includes/csrf.php';

if (!isset($_SESSION['user_id'])) { header('Location: login.php'); exit(); }

$user_id = (int)$_SESSION['user_id'];

$uStmt = $conn->prepare("SELECT * FROM users WHERE id = :id");
$uStmt->execute([':id' => $user_id]);
$user = $uStmt->fetch();

if (!$user) { session_destroy(); header('Location: login.php'); exit(); }

$stmt = $conn->prepare(
    "SELECT orders.*, reviews.id AS review_id, reviews.rating AS review_rating, reviews.text AS review_text
     FROM orders LEFT JOIN reviews ON reviews.order_id = orders.id
     WHERE orders.user_id = :uid ORDER BY orders.desired_date DESC, orders.id DESC"
);
$stmt->execute([':uid' => $user_id]);
$orders = $stmt->fetchAll();

$statusClass = ['новая'=>'status-new','идет_обучение'=>'status-progress','обучение_завершено'=>'status-done'];
$statusLabel = ['новая'=>'Новая','идет_обучение'=>'Идёт обучение','обучение_завершено'=>'Обучение завершено'];
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Личный кабинет — Водить.РФ</title>
    <link rel="stylesheet" href="main.css">
    <style>
        .info-slider-wrap {
            position:relative; background:linear-gradient(160deg,#0d1f30 0%,#1a3a5c 100%);
            border-radius:var(--radius-lg); overflow:hidden; height:220px;
            margin-bottom:32px; box-shadow:0 24px 60px rgba(26,42,58,0.18);
        }
        .info-slider-track { display:flex; height:100%; transition:transform 0.5s ease; }
        .info-slide {
            flex:0 0 100%; display:flex; align-items:center;
            gap:32px; padding:0 60px; color:#fff;
        }
        .info-slide-icon-wrap {
            width:110px; height:85px; flex-shrink:0; background:rgba(255,255,255,0.92);
            border-radius:12px; display:flex; align-items:center; justify-content:center; padding:8px;
        }
        .info-slide-img { width:100%; height:100%; object-fit:contain; }
        .info-slide-img.dash-slide-photo { width:110px; height:85px; flex-shrink:0; border-radius:10px; object-fit:cover; }
        .info-slide-title { font-family:var(--font-display); font-size:1.7rem; margin-bottom:8px; font-weight:500; }
        .info-slide-text { font-size:0.92rem; color:rgba(255,255,255,0.72); max-width:520px; line-height:1.6; }
        .info-slider-btn {
            position:absolute; top:50%; transform:translateY(-50%);
            background:rgba(255,255,255,0.12); border:none; color:#fff;
            width:40px; height:40px; border-radius:50%; cursor:pointer;
            font-size:1.2rem; display:flex; align-items:center; justify-content:center; z-index:5;
        }
        .info-slider-btn:hover { background:rgba(255,255,255,0.25); }
        .info-slider-prev { left:18px; }
        .info-slider-next { right:18px; }
        .info-slider-dots { position:absolute; bottom:14px; right:24px; display:flex; gap:8px; z-index:5; }
        .info-slider-dot { width:8px; height:8px; border-radius:50%; background:rgba(255,255,255,0.4); cursor:pointer; border:none; padding:0; }
        .info-slider-dot.active { background:#fff; }
        .status-progress { background:#fff7ed; color:#c2730a; }
        .review-form { display:none; margin-top:8px; }
        .review-form.open { display:block; }
        .review-form textarea { width:100%; padding:8px; border:1.5px solid #e0e8f0; border-radius:8px; font-size:0.82rem; margin:6px 0; resize:vertical; }
        .review-form button[type="submit"] { padding:6px 14px; background:var(--accent); color:#fff; border:none; border-radius:100px; cursor:pointer; font-size:0.82rem; }
        .review-toggle { font-size:0.78rem; color:var(--accent); background:none; border:none; cursor:pointer; padding:0; }
        .review-stars-input { display:flex; flex-direction:row-reverse; gap:2px; }
        .review-stars-input input { display:none; }
        .review-stars-input label { font-size:1.2rem; cursor:pointer; color:#ccc; }
        .review-stars-input input:checked ~ label,
        .review-stars-input label:hover,
        .review-stars-input label:hover ~ label { color:#f59e0b; }
        .stars { color:#f59e0b; }
    </style>
</head>
<body class="dash-page">

<header class="dash-header">
    <div class="container">
        <div class="header-inner">
            <a href="index.html" style="text-decoration:none;display:flex;align-items:center;gap:10px;">
                <span style="font-size:1.5rem;">⚓</span>
                <span class="logo-text">Водить<em>.РФ</em></span>
            </a>
            <nav class="dash-nav">
                <a href="index.html">На сайт</a>
                <a href="logout.php" style="color:rgba(255,255,255,0.45);">Выйти</a>
            </nav>
        </div>
    </div>
</header>

<main class="dash-body">
    <div class="container">

        <div class="dash-welcome">
            <h1>Добро пожаловать, дорогой клиент</h1>
            <p>Ваш личный кабинет — здесь отображаются все ваши заявки на обучение</p>
        </div>

        <a href="create_order.php" class="dash-action">⚓ Новая заявка на обучение</a>

        <div style="text-align:center;margin:32px 0 20px;">
            <h2 style="font-family:var(--font-display);font-size:2rem;font-weight:400;color:var(--slate);">Что вас ждёт</h2>
        </div>

        <div class="info-slider-wrap" id="dashSlider">
            <div class="info-slider-track" id="dashTrack">
                <div class="info-slide">
                    <div class="info-slide-icon-wrap"><img src="img/dash-slide1.png" class="info-slide-img" alt="Катер"></div>
                    <div>
                        <div class="info-slide-title">Курсы вождения катера</div>
                        <div class="info-slide-text">Освойте управление катером за 10 занятий с опытным инструктором. Теория, практика и сдача экзамена.</div>
                    </div>
                </div>
                <div class="info-slide">
                    <div class="info-slide-icon-wrap"><img src="img/dash-slide2.png" class="info-slide-img" alt="Яхта"></div>
                    <div>
                        <div class="info-slide-title">Обучение на яхте</div>
                        <div class="info-slide-text">Полный курс судовождения и подготовка к экзамену ГИМС. Навигация, метеорология и практика в открытой воде.</div>
                    </div>
                </div>
                <div class="info-slide">
                    <div class="info-slide-icon-wrap"><img src="img/dash-slide3.png" class="info-slide-img" alt="Круизный лайнер"></div>
                    <div>
                        <div class="info-slide-title">Круизные лайнеры</div>
                        <div class="info-slide-text">Углублённая программа для тех, кто хочет работать в команде судна. Персональный инструктор и тренажёрная подготовка.</div>
                    </div>
                </div>
                <div class="info-slide">
                    <img src="img/dash-slide4.png" class="info-slide-img dash-slide-photo" alt="Практика на воде">
                    <div>
                        <div class="info-slide-title">Не упустите свой шанс!</div>
                        <div class="info-slide-text">Почувствуйте себя настоящим моряком и получите незабываемые воспоминания.</div>
                    </div>
                </div>
            </div>
            <button class="info-slider-btn info-slider-prev" onclick="dashSlideMove(-1)" aria-label="Назад">‹</button>
            <button class="info-slider-btn info-slider-next" onclick="dashSlideMove(1)" aria-label="Вперёд">›</button>
            <div class="info-slider-dots" id="dashSliderDots"></div>
        </div>

        <?php if (empty($orders)): ?>
            <div class="dash-empty">
                <span style="font-size:3rem;">📋</span>
                <p>Заявок пока нет. Оформите первую заявку на обучение!</p>
            </div>
        <?php else: ?>
            <div style="overflow-x:auto;">
                <table class="orders-table">
                    <thead>
                        <tr>
                            <th>Email</th>
                            <th>Вид транспорта</th>
                            <th>Дата</th>
                            <th>Время</th>
                            <th>Оплата</th>
                            <th>Статус</th>
                            <th>Отзыв</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($orders as $order):
                        $status  = $order['status'] ?? 'новая';
                        $dateStr = $order['desired_date'] ? date('d.m.Y', strtotime($order['desired_date'])) : '—';
                    ?>
                        <tr>
                            <td><?= htmlspecialchars($order['address'] ?? '—') ?></td>
                            <td><span style="font-weight:500;"><?= htmlspecialchars($order['service_type'] ?? '—') ?></span></td>
                            <td><?= $dateStr ?></td>
                            <td><?= htmlspecialchars(substr($order['desired_time'] ?? '00:00', 0, 5)) ?></td>
                            <td style="font-size:0.85rem;color:var(--slate-light);"><?= htmlspecialchars($order['payment_type'] ?? '—') ?></td>
                            <td><span class="status-badge <?= $statusClass[$status] ?? 'status-new' ?>"><?= $statusLabel[$status] ?? htmlspecialchars($status) ?></span></td>
                            <td style="font-size:0.82rem;color:var(--slate-light);max-width:200px;">
                                <?php if ($status !== 'новая'): ?>
                                    <?php if (!empty($order['review_id'])): ?>
                                        <span class="stars"><?= str_repeat('★', (int)$order['review_rating']) . str_repeat('☆', 5 - (int)$order['review_rating']) ?></span><br>
                                        «<?= htmlspecialchars($order['review_text']) ?>»
                                    <?php else: ?>
                                        <button type="button" class="review-toggle" onclick="toggleReview(<?= (int)$order['id'] ?>)">+ Оставить отзыв</button>
                                        <form class="review-form" id="reviewForm<?= (int)$order['id'] ?>" method="POST" action="submit_review.php">
                                            <?= csrf_field() ?>
                                            <input type="hidden" name="order_id" value="<?= (int)$order['id'] ?>">
                                            <div class="review-stars-input">
                                                <?php for ($i = 5; $i >= 1; $i--): ?>
                                                    <input type="radio" name="rating" id="star<?= $i ?>_<?= (int)$order['id'] ?>" value="<?= $i ?>" <?= $i === 5 ? 'checked' : '' ?>>
                                                    <label for="star<?= $i ?>_<?= (int)$order['id'] ?>">★</label>
                                                <?php endfor; ?>
                                            </div>
                                            <textarea name="text" placeholder="Расскажите о вашем обучении…" required></textarea>
                                            <button type="submit">Отправить отзыв</button>
                                        </form>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>

    </div>
</main>

<script>
function toggleReview(id) {
    document.getElementById('reviewForm' + id).classList.toggle('open');
}
(function() {
    const track = document.getElementById('dashTrack');
    const dotsWrap = document.getElementById('dashSliderDots');
    if (!track || !dotsWrap) return;
    const count = track.children.length;
    let index = 0, timer;
    for (let i = 0; i < count; i++) {
        const dot = document.createElement('button');
        dot.className = 'info-slider-dot' + (i === 0 ? ' active' : '');
        dot.addEventListener('click', () => goTo(i));
        dotsWrap.appendChild(dot);
    }
    function update() {
        track.style.transform = 'translateX(-' + (index * 100) + '%)';
        Array.from(dotsWrap.children).forEach((d, i) => d.classList.toggle('active', i === index));
    }
    function goTo(i) { index = (i + count) % count; update(); restart(); }
    window.dashSlideMove = dir => goTo(index + dir);
    function restart() { clearInterval(timer); timer = setInterval(() => goTo(index + 1), 3500); }
    restart();
})();
</script>
</body>
</html>
