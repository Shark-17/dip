<?php
session_start();
require 'includes/db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = (int) $_SESSION['user_id'];

// Данные пользователя
$uStmt = $conn->prepare("SELECT * FROM users WHERE id = :id");
$uStmt->execute([':id' => $user_id]);
$user = $uStmt->fetch();

if (!$user) {
    session_destroy();
    header('Location: login.php');
    exit();
}

// ── Цены тарифов ──
$tariffPrices = [
    'Silver'      => 15000,
    'Gold'        => 50000,
    'Diamond'     => 150000,
    'Свой тариф'  => null,
];

// ── Фильтры ──
$filterStatus  = $_GET['status']  ?? 'all';
$filterTariff  = $_GET['tariff']  ?? 'all';
$filterDate    = $_GET['date']    ?? '';
$sortPrice     = $_GET['sort']    ?? '';

$allowedStatuses = ['all', 'новая', 'выполнена', 'отменена'];
$allowedTariffs  = ['all', 'Silver', 'Gold', 'Diamond', 'Свой тариф'];
$allowedSorts    = ['', 'asc', 'desc'];

if (!in_array($filterStatus, $allowedStatuses)) $filterStatus = 'all';
if (!in_array($filterTariff, $allowedTariffs))  $filterTariff = 'all';
if (!in_array($sortPrice, $allowedSorts))        $sortPrice = '';

$where  = ['user_id = :uid'];
$params = [':uid' => $user_id];

if ($filterStatus !== 'all') {
    $where[]           = 'status = :status';
    $params[':status'] = $filterStatus;
}
if ($filterTariff !== 'all') {
    $where[]           = 'service_type = :tariff';
    $params[':tariff'] = $filterTariff;
}
if ($filterDate !== '') {
    $where[]          = 'desired_date = :ddate';
    $params[':ddate'] = $filterDate;
}

$sql = "SELECT orders.*,
               last_log.admin_full_name AS comment_author
        FROM orders
        LEFT JOIN (
            SELECT ol.order_id,
                   COALESCE(a.full_name, ol.changed_by) AS admin_full_name
            FROM order_log ol
            LEFT JOIN admins a ON ol.admin_id = a.id
            WHERE ol.comment IS NOT NULL AND ol.comment != ''
            ORDER BY ol.changed_at DESC
        ) AS last_log ON last_log.order_id = orders.id
        WHERE " . implode(' AND ', $where)
     . " ORDER BY orders.desired_date DESC, orders.id DESC";

$stmt = $conn->prepare($sql);
$stmt->execute($params);
$orders = $stmt->fetchAll();

// Сортировка по цене на PHP
if ($sortPrice === 'asc' || $sortPrice === 'desc') {
    usort($orders, function($a, $b) use ($sortPrice, $tariffPrices) {
        $pa = $tariffPrices[$a['service_type']] ?? 0;
        $pb = $tariffPrices[$b['service_type']] ?? 0;
        return $sortPrice === 'asc' ? $pa - $pb : $pb - $pa;
    });
}

// ── Статистика (всегда по всем заказам) ──
$statStmt = $conn->prepare("SELECT status, COUNT(*) as cnt FROM orders WHERE user_id = :uid GROUP BY status");
$statStmt->execute([':uid' => $user_id]);
$stats = [];
foreach ($statStmt->fetchAll() as $row) {
    $stats[$row['status']] = (int) $row['cnt'];
}
$total    = array_sum($stats);
$done     = $stats['выполнена'] ?? 0;
$canceled = $stats['отменена']  ?? 0;
$active   = $stats['новая']     ?? 0;

$statusClass = ['новая' => 'status-new', 'выполнена' => 'status-done', 'отменена' => 'status-canceled'];
$statusLabel = ['новая' => 'Новая', 'выполнена' => 'Выполнена', 'отменена' => 'Отменена'];

$firstName = explode(' ', trim($user['full_name']))[0] ?? 'Гость';
$initials  = mb_strtoupper(mb_substr($user['full_name'], 0, 1));

/**
 * Формирует query string с текущими параметрами, перезаписывая указанный ключ.
 */
function buildQS(array $overrides = []): string {
    $base = [
        'status' => $_GET['status'] ?? 'all',
        'tariff' => $_GET['tariff'] ?? 'all',
        'date'   => $_GET['date']   ?? '',
        'sort'   => $_GET['sort']   ?? '',
    ];
    $merged = array_merge($base, $overrides);
    // Убираем дефолтные значения
    $filtered = array_filter($merged, function($v) { return $v !== '' && $v !== 'all'; });
    return $filtered ? '?' . http_build_query($filtered) : '';
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Личный кабинет — Alpine Spirit</title>
    <link rel="stylesheet" href="main.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,300;1,400&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
    <style>
        .filter-tabs { display:flex; gap:8px; flex-wrap:wrap; margin-bottom:10px; }
        .filter-tab {
            padding:6px 16px; border-radius:100px; text-decoration:none;
            font-size:0.8rem; font-weight:500; border:1.5px solid #e0e8f0;
            color:var(--slate-light); 
        }
        .filter-tab:hover  { border-color:var(--accent); color:var(--accent); }
        .filter-tab.active { background:var(--accent); border-color:var(--accent); color:#fff; }
        .filter-row {
            display:flex; gap:10px; flex-wrap:wrap; align-items:center;
            margin-bottom:10px;
        }
        .filter-select {
            padding:7px 14px; border:1.5px solid #e0e8f0; border-radius:100px;
            font-family:var(--font-body); font-size:0.82rem; color:var(--slate);
            outline:none; cursor:pointer; appearance:none; background:var(--white);
            
        }
        .filter-select:focus { border-color:var(--accent); }
        .filter-date-form { display:flex; gap:6px; align-items:center; }
        .filter-date-form input[type="date"] {
            padding:7px 12px; border:1.5px solid #e0e8f0; border-radius:100px;
            font-family:var(--font-body); font-size:0.82rem; color:var(--slate);
            outline:none; cursor:pointer; 
        }
        .filter-date-form input[type="date"]:focus { border-color:var(--accent); }
        .filter-date-form button {
            padding:7px 16px; background:var(--accent); color:#fff; border:none;
            border-radius:100px; cursor:pointer; font-size:0.82rem; font-weight:500;
            
        }
        .filter-date-form button:hover { background:var(--accent-dark); }
        .reset-link {
            font-size:0.8rem; color:var(--slate-light); text-decoration:none;
            padding:5px 12px; border-radius:100px; border:1.5px solid #e0e8f0;
            
        }
        .reset-link:hover { border-color:#dc2626; color:#dc2626; }

        /* Карточка профиля */
        .profile-card {
            background:var(--white); border-radius:var(--radius-lg); padding:20px 24px;
            border:1px solid rgba(90,159,212,0.1); display:flex; align-items:center;
            gap:16px; margin-bottom:24px; text-decoration:none;
            
        }
        .profile-card:hover { box-shadow:0 8px 32px rgba(26,42,58,0.1); }
        .profile-avatar {
            width:52px; height:52px; border-radius:50%;
            background:linear-gradient(135deg,#1a3a5c,#243d52);
            display:flex; align-items:center; justify-content:center;
            font-family:var(--font-display); font-size:1.4rem; font-weight:600;
            color:#a8d4f0; flex-shrink:0;
        }
        .profile-info { flex:1; min-width:0; }
        .profile-name { font-weight:500; color:var(--slate); font-size:0.95rem; }
        .profile-meta { font-size:0.8rem; color:var(--slate-light); margin-top:2px; }
        .profile-link-arrow { color:var(--accent); font-size:0.85rem; flex-shrink:0; }
    </style>
</head>
<body class="dash-page">

<header class="dash-header">
    <div class="container">
        <div class="header-inner">
            <a href="index.html" style="text-decoration:none; display:flex; align-items:center; gap:10px;">
                <span style="font-size:1.5rem;">⛷</span>
                <span class="logo-text">Alpine <em>Spirit</em></span>
            </a>
            <nav class="dash-nav">
                <a href="dashboard.php" class="active">Мои заявки</a>
                <a href="create_order.php">Новая бронь</a>
                <a href="profile.php">Профиль</a>
                <a href="index.html">На сайт</a>
                <a href="logout.php" style="color:rgba(255,255,255,0.45);">Выйти</a>
            </nav>
        </div>
    </div>
</header>

<main class="dash-body">
    <div class="container">

        <div class="dash-welcome">
            <h1>Привет, <?= htmlspecialchars($firstName) ?> 👋</h1>
            <p>Здесь вы можете отслеживать свои бронирования на курорте</p>
        </div>

        <!-- Карточка профиля -->
        <a href="profile.php" class="profile-card" style="box-shadow:0 4px 20px rgba(26,42,58,0.06);">
            <div class="profile-avatar"><?= $initials ?></div>
            <div class="profile-info">
                <div class="profile-name"><?= htmlspecialchars($user['full_name']) ?></div>
                <div class="profile-meta">
                    <?= htmlspecialchars($user['email']) ?> · <?= htmlspecialchars($user['phone']) ?>
                </div>
            </div>
            <span class="profile-link-arrow">Профиль →</span>
        </a>

        <!-- Статистика -->
        <div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(160px,1fr)); gap:16px; margin-bottom:36px;">
            <a href="dashboard.php" class="dash-stat-card" style="text-decoration:none;">
                <span class="dash-stat-num"><?= $total ?></span>
                <span class="dash-stat-label">Всего заявок</span>
            </a>
            <a href="dashboard.php?status=выполнена" class="dash-stat-card" style="text-decoration:none;">
                <span class="dash-stat-num" style="color:#16a34a;"><?= $done ?></span>
                <span class="dash-stat-label">Выполнено</span>
            </a>
            <a href="dashboard.php?status=новая" class="dash-stat-card" style="text-decoration:none;">
                <span class="dash-stat-num" style="color:#2563eb;"><?= $active ?></span>
                <span class="dash-stat-label">Активных</span>
            </a>
            <a href="dashboard.php?status=отменена" class="dash-stat-card" style="text-decoration:none;">
                <span class="dash-stat-num" style="color:#dc2626;"><?= $canceled ?></span>
                <span class="dash-stat-label">Отменено</span>
            </a>
        </div>

        <a href="create_order.php" class="dash-action">⛷ Новое бронирование</a>

        <!-- ── Фильтры ── -->
        <div style="background:var(--white); border-radius:var(--radius-lg); padding:20px 24px;
                    margin-bottom:24px; box-shadow:0 4px 20px rgba(26,42,58,0.05);
                    border:1px solid rgba(90,159,212,0.08);">

            <!-- По статусу -->
            <div style="font-size:0.72rem; text-transform:uppercase; letter-spacing:0.1em;
                        color:var(--slate-light); margin-bottom:8px; font-weight:500;">Статус</div>
            <div class="filter-tabs" style="margin-bottom:16px;">
                <?php
                $statusTabs = ['all' => 'Все', 'новая' => 'Активные', 'выполнена' => 'Завершённые', 'отменена' => 'Отменённые'];
                foreach ($statusTabs as $val => $lbl):
                ?>
                <a href="dashboard.php<?= buildQS(['status' => $val]) ?>"
                   class="filter-tab <?= $filterStatus === $val ? 'active' : '' ?>"><?= $lbl ?></a>
                <?php endforeach; ?>
            </div>

            <!-- По тарифу -->
            <div style="font-size:0.72rem; text-transform:uppercase; letter-spacing:0.1em;
                        color:var(--slate-light); margin-bottom:8px; font-weight:500;">Тариф</div>
            <div class="filter-tabs" style="margin-bottom:16px;">
                <?php
                $tariffTabs = ['all' => 'Все', 'Silver' => '🥈 Silver', 'Gold' => '🥇 Gold',
                               'Diamond' => '💎 Diamond', 'Свой тариф' => '✏️ Свой'];
                foreach ($tariffTabs as $val => $lbl):
                ?>
                <a href="dashboard.php<?= buildQS(['tariff' => $val]) ?>"
                   class="filter-tab <?= $filterTariff === $val ? 'active' : '' ?>"><?= $lbl ?></a>
                <?php endforeach; ?>
            </div>

            <!-- Дата + сортировка -->
            <div class="filter-row">
                <form class="filter-date-form" method="GET">
                    <?php if ($filterStatus !== 'all'): ?>
                        <input type="hidden" name="status" value="<?= htmlspecialchars($filterStatus) ?>">
                    <?php endif; ?>
                    <?php if ($filterTariff !== 'all'): ?>
                        <input type="hidden" name="tariff" value="<?= htmlspecialchars($filterTariff) ?>">
                    <?php endif; ?>
                    <?php if ($sortPrice !== ''): ?>
                        <input type="hidden" name="sort" value="<?= htmlspecialchars($sortPrice) ?>">
                    <?php endif; ?>
                    <input type="date" name="date" value="<?= htmlspecialchars($filterDate) ?>"
                           placeholder="Дата отправления">
                    <button type="submit">Применить</button>
                    <?php if ($filterDate !== ''): ?>
                        <a href="dashboard.php<?= buildQS(['date' => '']) ?>" class="reset-link">✕ Сбросить дату</a>
                    <?php endif; ?>
                </form>

                <!-- Сортировка по цене -->
                <a href="dashboard.php<?= buildQS(['sort' => 'desc']) ?>"
                   class="filter-tab <?= $sortPrice === 'desc' ? 'active' : '' ?>"
                   style="margin-left:auto;">↓ Дороже</a>
                <a href="dashboard.php<?= buildQS(['sort' => 'asc']) ?>"
                   class="filter-tab <?= $sortPrice === 'asc' ? 'active' : '' ?>">↑ Дешевле</a>
                <?php if ($sortPrice !== ''): ?>
                    <a href="dashboard.php<?= buildQS(['sort' => '']) ?>" class="reset-link">Сброс</a>
                <?php endif; ?>
            </div>
        </div>

        <?php if (empty($orders)): ?>
            <div class="dash-empty">
                <span style="font-size:3rem;">🎿</span>
                <p><?= $filterStatus === 'all' && $filterTariff === 'all' && $filterDate === ''
                    ? 'У вас пока нет бронирований'
                    : 'Нет заявок по выбранным фильтрам' ?></p>
                <a href="dashboard.php" class="btn-primary" style="margin-top:16px;">Сбросить фильтры</a>
            </div>
        <?php else: ?>
            <div style="overflow-x:auto;">
                <table class="orders-table">
                    <thead>
                        <tr>
                            <th>Email</th>
                            <th>Тариф</th>
                            <th>Цена</th>
                            <th>Дата</th>
                            <th>Время</th>
                            <th>Оплата</th>
                            <th>Статус</th>
                            <th>Комментарий</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($orders as $order): ?>
                        <?php
                        $status  = $order['status'] ?? 'новая';
                        $class   = $statusClass[$status] ?? 'status-new';
                        $label   = $statusLabel[$status] ?? htmlspecialchars($status);
                        $dateTs  = strtotime($order['desired_date'] ?? 'now');
                        $dateStr = $dateTs ? date('d.m.Y', $dateTs) : '—';
                        $price   = $tariffPrices[$order['service_type']] ?? null;
                        $priceStr = $price !== null ? number_format($price, 0, '.', ' ') . ' ₽' : 'по запросу';
                        ?>
                        <tr>
                            <td><?= htmlspecialchars($order['address'] ?? '—') ?></td>
                            <td><span style="font-weight:500;"><?= htmlspecialchars($order['service_type'] ?? '—') ?></span></td>
                            <td style="font-size:0.85rem; color:var(--slate); white-space:nowrap;"><?= $priceStr ?></td>
                            <td><?= $dateStr ?></td>
                            <td><?= htmlspecialchars(substr($order['desired_time'] ?? '00:00', 0, 5)) ?></td>
                            <td style="font-size:0.85rem; color:var(--slate-light);"><?= htmlspecialchars($order['payment_type'] ?? '—') ?></td>
                            <td><span class="status-badge <?= $class ?>"><?= $label ?></span></td>
                            <td style="font-size:0.82rem; color:var(--slate-light); max-width:160px;">
                                <?php if ($order['admin_comment']): ?>
                                    <span style="color:var(--slate);"><?= htmlspecialchars($order['admin_comment']) ?></span>
                                    <?php if (!empty($order['comment_author'])): ?>
                                        <br><span style="font-size:0.74rem; color:var(--accent); opacity:0.8;">
                                            — <?= htmlspecialchars($order['comment_author']) ?>
                                        </span>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <span style="opacity:.4;">—</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="create_order.php?repeat=<?= (int) $order['id'] ?>"
                                   title="Повторить бронирование"
                                   style="font-size:0.78rem; color:var(--accent); text-decoration:none; white-space:nowrap;">
                                    ↺ Повторить
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>

    </div>
</main>

</body>
</html>
