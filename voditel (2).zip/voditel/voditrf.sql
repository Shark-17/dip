-- phpMyAdmin SQL Dump
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Версия сервера: 8.0.15
-- Версия PHP: 7.3.2
--
-- База данных: «voditrf»
-- Портал «Водить.РФ» — запись на курсы вождения речного транспорта
-- (катера, круизные лайнеры, яхты)

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

-- --------------------------------------------------------

--
-- Структура таблицы `admins`
-- Логин администратора по умолчанию: Admin26 / Demo20
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `full_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `login` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `admins`
-- Пароль 'Demo20' захеширован через password_hash() PASSWORD_BCRYPT
--

INSERT INTO `admins` (`id`, `full_name`, `login`, `password`) VALUES
(1, 'Администратор портала', 'Admin26', '$2y$10$ZNMBU3XVgNRQRCtS9y7fCu5C2wIVscgqUQl.k6FJ9HViZdMhSHtDm');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
-- Логин: латиница + цифры, минимум 6 символов. Пароль: минимум 8 символов.
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `full_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `birth_date` date NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `login` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `users`
-- Пароли захешированы через password_hash() PASSWORD_BCRYPT (исходный пароль для всех: password123)
--

INSERT INTO `users` (`id`, `full_name`, `birth_date`, `phone`, `email`, `login`, `password`) VALUES
(1, 'Иван Петров', '1990-04-12', '+7 900 111 22 33', 'ivan@example.com', 'ivan123', '$2y$10$C483wttv9fd4IU3JpohiqOr1x3QGI9d18Vf5Z/QkVvXDD4T2KfEDe'),
(2, 'Мария Сидорова', '1995-07-23', '+7 900 444 55 66', 'maria@example.com', 'maria01', '$2y$10$plX8d8ZmUD6wdKA.Svc6seYmhclyxepls37KVWxo4aMwKq5MZ.Bki'),
(3, 'Иванов Иван Петрович', '1988-11-02', '+7 928 364 45 90', 'examin@gmail.com', 'sss777', '$2y$10$VwWBIigj3soGyJkZAfQuSeP8jGjrI1tCddIodY2kSLe7498bcP5jq'),
(4, 'Матеев Вадим Владимирович', '1993-02-17', '+7 928 365 40 91', 'tityln@gmail.com', 'mati2024', '$2y$10$xy.a.nXOuj6uJKKuJNo5sOiC/SQXkf.54N/mFfEISSxuZ9mJW3PBi');

-- --------------------------------------------------------

--
-- Структура таблицы `orders` (заявки на обучение)
-- service_type — вид транспорта: Катер / Яхта / Круизный лайнер / Свой вариант
-- status: новая -> идет_обучение -> обучение_завершено (или отменена)
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Email для подтверждения',
  `service_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `desired_date` date NOT NULL,
  `desired_time` time NOT NULL,
  `payment_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('новая','идет_обучение','обучение_завершено','отменена') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'новая',
  `admin_comment` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `address`, `service_type`, `desired_date`, `desired_time`, `payment_type`, `status`, `admin_comment`) VALUES
(1, 1, 'ivan@example.com', 'Яхта', '2025-12-20', '09:00:00', 'оплата картой МИР', 'обучение_завершено', 'Курс пройден успешно, выдан сертификат'),
(2, 1, 'ivan@example.com', 'Катер', '2025-12-28', '10:30:00', 'постоплата в офисе организации', 'новая', NULL),
(3, 2, 'maria@example.com', 'Круизный лайнер', '2026-01-05', '08:00:00', 'оплата картой МИР', 'новая', NULL),
(4, 3, 'examin@gmail.com', 'Яхта', '2026-06-03', '05:09:00', 'оплата картой МИР', 'обучение_завершено', 'Обучение завершено'),
(5, 3, 'examin@gmail.com', 'Катер', '2026-06-03', '02:06:00', 'постоплата в офисе организации', 'идет_обучение', NULL),
(6, 4, 'tityln@gmail.com', 'Катер', '2026-06-11', '08:37:00', 'оплата картой МИР', 'обучение_завершено', 'Курс завершён, всего доброго'),
(7, 4, 'tityln@gmail.com', 'Свой вариант', '2026-08-30', '05:35:00', 'оплата картой МИР', 'новая', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `order_log` (история изменений заявок)
--

CREATE TABLE `order_log` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `admin_id` int(11) DEFAULT NULL COMMENT 'Кто из администраторов внёс изменение',
  `changed_by` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'admin' COMMENT 'Кто изменил: admin / user',
  `old_status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `new_status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci,
  `changed_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `order_log`
--

INSERT INTO `order_log` (`id`, `order_id`, `admin_id`, `changed_by`, `old_status`, `new_status`, `comment`) VALUES
(1, 1, 1, 'admin', 'новая', 'идет_обучение', NULL),
(2, 1, 1, 'admin', 'идет_обучение', 'обучение_завершено', NULL),
(3, 1, 1, 'admin', NULL, NULL, 'Курс пройден успешно, выдан сертификат'),
(4, 4, 1, 'admin', 'новая', 'идет_обучение', NULL),
(5, 4, 1, 'admin', 'идет_обучение', 'обучение_завершено', NULL),
(6, 4, 1, 'admin', NULL, NULL, 'Обучение завершено'),
(7, 5, 1, 'admin', 'новая', 'идет_обучение', NULL),
(8, 6, 1, 'admin', 'новая', 'идет_обучение', NULL),
(9, 6, 1, 'admin', 'идет_обучение', 'обучение_завершено', NULL),
(10, 6, 1, 'admin', NULL, NULL, 'Курс завершён, всего доброго');

-- --------------------------------------------------------

--
-- Структура таблицы `reviews` (отзывы пользователей)
-- Оставить отзыв можно только после того, как администратор сменил статус заявки
-- (т.е. статус заявки уже не "новая")
--

CREATE TABLE `reviews` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `rating` tinyint(1) NOT NULL COMMENT 'Оценка от 1 до 5',
  `text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `reviews`
--

INSERT INTO `reviews` (`id`, `order_id`, `user_id`, `rating`, `text`) VALUES
(1, 1, 1, 5, 'Отличные курсы! Инструктор подробно объяснял каждый этап управления яхтой. Уже сдал на права судоводителя.'),
(4, 4, 3, 5, 'Прошёл курс на катер — всё понравилось, преподаватели опытные, материал подаётся понятно.'),
(6, 6, 4, 4, 'Хороший курс, но хотелось бы больше практических занятий на воде.');

--
-- Индексы сохранённых таблиц
--

ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `login` (`login`);

ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `login` (`login`),
  ADD UNIQUE KEY `email` (`email`);

ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `status` (`status`),
  ADD KEY `desired_date` (`desired_date`);

ALTER TABLE `order_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `changed_at` (`changed_at`);

ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `order_id` (`order_id`),
  ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

ALTER TABLE `order_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

ALTER TABLE `reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Ограничения внешнего ключа сохранённых таблиц
--

ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE `order_log`
  ADD CONSTRAINT `order_log_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `order_log_ibfk_2` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE `reviews`
  ADD CONSTRAINT `reviews_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `reviews_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
