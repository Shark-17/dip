<?php
session_start();
require 'includes/db.php';
require 'includes/csrf.php';

if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header('Location: login.php');
    exit();
}

$allowed_statuses = ['новая', 'идет_обучение', 'обучение_завершено'];
$statusLabel = [
    'новая'               => 'Новая',
    'идет_обучение'       => 'Идёт обучение',
    'обучение_завершено'  => 'Обучение завершено',
];

/**
 * Пишет запись в таблицу order_log (если таблица существует).
 */
function log_order_change(PDO $conn, int $orderId, ?string $oldStatus, ?string $newStatus, ?string $comment = null, ?int $adminId = null): void {
    try {
        $conn->prepare(
            "INSERT INTO order_log (order_id, changed_by, old_status, new_status, comment, admin_id)
             VALUES (:oid, 'admin', :old, :new, :comment, :admin_id)"
        )->execute([
            ':oid'      => $orderId,
            ':old'      => $oldStatus,
            ':new'      => $newStatus,
            ':comment'  => $comment,
            ':admin_id' => $adminId,
        ]);
    } catch (PDOException $e) {
        // Таблица order_log может не существовать — молча пропускаем
    }
}

// ── Обработка POST (сохранение комментария) ──
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    $action = $_POST['action'] ?? '';
    $id     = (int) ($_POST['id'] ?? 0);
    $back   = $_POST['_edit_back'] ?? '';
    $toast  = '';

    if ($action === 'comment' && $id > 0) {
        $comment = trim($_POST['comment'] ?? '') ?: null;

        $upd = $conn->prepare("UPDATE orders SET admin_comment = :c WHERE id = :id");
        $upd->execute([':c' => $comment, ':id' => $id]);

        $adminId = (int) ($_SESSION['admin_id'] ?? 0) ?: null;
        log_order_change($conn, $id, null, null, $comment, $adminId);
        $toast = 'Комментарий сохранён';
    }

    $redirect = 'admin.php';
    if ($back && preg_match('/^[?&a-zA-Z0-9=_%.-]+$/', $back)) {
        $redirect .= $back;
    }
    $redirect .= (strpos($redirect, '?') !== false ? '&' : '?') . 'toast=' . urlencode($toast);
    header('Location: ' . $redirect);
    exit();
}

// ── Обработка GET (смена статуса) ──
$id     = (int) ($_GET['id']     ?? 0);
$status = $_GET['status']        ?? '';
$back   = $_GET['_back']         ?? '';
$toast  = '';

if ($id > 0 && in_array($status, $allowed_statuses)) {
    $cur = $conn->prepare("SELECT status FROM orders WHERE id = :id LIMIT 1");
    $cur->execute([':id' => $id]);
    $oldStatus = $cur->fetchColumn() ?: null;

    if ($oldStatus !== $status) {
        $upd = $conn->prepare("UPDATE orders SET status = :status WHERE id = :id");
        $upd->execute([':status' => $status, ':id' => $id]);

        $adminId = (int) ($_SESSION['admin_id'] ?? 0) ?: null;
        log_order_change($conn, $id, $oldStatus, $status, null, $adminId);
        $toast = 'Заявка №' . $id . ': статус изменён на «' . ($statusLabel[$status] ?? $status) . '»';
    }
}

// Возврат с сохранением фильтров
$redirect = 'admin.php' . (($back && preg_match('/^[?&a-zA-Z0-9=_%.-]+$/', $back)) ? $back : '');
$redirect .= (strpos($redirect, '?') !== false ? '&' : '?') . 'toast=' . urlencode($toast);
header('Location: ' . $redirect);
exit();

