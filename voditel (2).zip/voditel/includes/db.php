<?php
$host     = 'localhost';
$dbname   = 'kryiz'; 
$username = 'root';
$password = '';

try {
    $conn = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $username,
        $password
    );
    $conn->setAttribute(PDO::ATTR_ERRMODE,            PDO::ERRMODE_EXCEPTION);
    $conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $conn->setAttribute(PDO::ATTR_EMULATE_PREPARES,   false);
} catch (PDOException $e) {
    // В продакшене не показываем детали ошибки
    error_log('DB connection error: ' . $e->getMessage());
    die('Ошибка подключения к базе данных. Попробуйте позже.');
}
