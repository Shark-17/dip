<?php
session_start();
require 'includes/db.php';
require 'includes/csrf.php';

if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header('Location: login.php');
    exit();
}

// Фильтры
$filterStatus = $_GET['status'] ?? 'all';
$sortBy       = $_GET['sort'] ?? 'id_asc';
$allowed      = ['all', 'новая', 'идет_обучение', 'обучение_завершено'];
$allowedSorts = ['id_asc', 'id_desc', 'date_asc', 'date_desc'];
if (!in_array($filterStatus, $allowed)) $filterStatus = 'all';
if (!in_array($sortBy, $allowedSorts))  $sortBy = 'id_asc';

$where  = [];
$params = [];
if ($filterStatus !== 'all') {
    $where[]           = "orders.status = :status";
    $params[':status'] = $filterStatus;
}

$orderByMap = [
    'id_asc'    => 'orders.id ASC',
    'id_desc'   => 'orders.id DESC',
    'date_asc'  => 'orders.desired_date ASC, orders.desired_time ASC',
    'date_desc' => 'orders.desired_date DESC, orders.desired_time DESC',
];

$sql = "SELECT orders.*, users.full_name, users.phone
        FROM orders JOIN users ON orders.user_id = users.id";
if ($where) $sql .= ' WHERE ' . implode(' AND ', $where);
$sql .= ' ORDER BY ' . $orderByMap[$sortBy];

$stmt = $conn->prepare($sql);
$stmt->execute($params);
$allOrders = $stmt->fetchAll();

// Пагинация
$perPage    = 5;
$totalFound = count($allOrders);
$totalPages = max(1, (int) ceil($totalFound / $perPage));
$page       = max(1, min($totalPages, (int) ($_GET['page'] ?? 1)));
$orders     = array_slice($allOrders, ($page - 1) * $perPage, $perPage);

// Статистика
$statRows = $conn->query("SELECT status, COUNT(*) as cnt FROM orders GROUP BY status")->fetchAll();
$stats    = [];
foreach ($statRows as $row) $stats[$row['status']] = (int) $row['cnt'];
$totalOrders = array_sum($stats);

$statusClass = [
    'новая'               => 'status-new',
    'идет_обучение'       => 'status-progress',
    'обучение_завершено'  => 'status-done',
];
$statusLabel = [
    'новая'               => 'Новая',
    'идет_обучение'       => 'Идёт обучение',
    'обучение_завершено'  => 'Обучение завершено',
];

function buildAdminQS(array $overrides = []): string {
    $base = [
        'status' => $_GET['status'] ?? 'all',
        'sort'   => $_GET['sort']   ?? 'id_asc',
        'page'   => $_GET['page']   ?? 1,
    ];
    $merged   = array_merge($base, $overrides);
    $filtered = array_filter($merged, function($v, $k) {
        if ($k === 'page') return (int) $v > 1;
        return $v !== '' && $v !== 'all' && $v !== 'id_asc';
    }, ARRAY_FILTER_USE_BOTH);
    return $filtered ? '?' . http_build_query($filtered) : '';
}
$qs = buildAdminQS();
$qsNoPage = preg_replace('/([?&])page=\d+&?/', '$1', $qs);
$qsNoPage = rtrim($qsNoPage, '?&');

$toast = $_GET['toast'] ?? '';
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Панель администратора — Водить.РФ</title>
    <link rel="stylesheet" href="main.css">
    <style>
        .filter-tabs { display:flex; gap:8px; flex-wrap:wrap; margin-bottom:16px; }
        .filter-tab {
            padding:7px 18px; border-radius:100px; text-decoration:none;
            font-size:0.82rem; font-weight:500; border:1.5px solid #e0e8f0;
            color:var(--slate-light);
        }
        .filter-tab:hover  { border-color:var(--accent); color:var(--accent); }
        .filter-tab.active { background:var(--accent); border-color:var(--accent); color:#fff; }
        .action-link {
            font-size:0.78rem; font-weight:500; text-decoration:none;
            padding:5px 12px; border-radius:100px; border:1.5px solid;
            white-space:nowrap;
        }
        .action-done   { border-color:#16a34a; color:#16a34a; }
        .action-done:hover   { background:#16a34a; color:#fff; }
        .action-new    { border-color:#2563eb; color:#2563eb; }
        .action-new:hover    { background:#2563eb; color:#fff; }
        .action-progress { border-color:#c2730a; color:#c2730a; }
        .action-progress:hover { background:#c2730a; color:#fff; }
        .status-progress { background:#fff7ed; color:#c2730a; }
        .sort-select {
            padding:10px 16px; border:1.5px solid #e0e8f0; border-radius:100px;
            font-family:var(--font-body); font-size:0.85rem; color:var(--slate);
            background:var(--white); cursor:pointer; outline:none; appearance:none;
        }
        .sort-select:focus { border-color:var(--accent); }

        /* Toast */
        .toast {
            position:fixed; top:24px; right:24px; z-index:2000;
            background:var(--white); border-left:4px solid #16a34a;
            box-shadow:0 12px 40px rgba(0,0,0,0.18); border-radius:10px;
            padding:14px 20px; font-size:0.88rem; color:var(--slate);
            display:flex; align-items:center; gap:10px;
            animation: toastIn 0.3s ease;
        }
        @keyframes toastIn { from { transform:translateX(40px); opacity:0; } to { transform:translateX(0); opacity:1; } }

        /* Пагинация */
        .pagination {
            display:flex; justify-content:center; gap:6px; margin:28px 0 8px; flex-wrap:wrap;
        }
        .page-link {
            min-width:36px; height:36px; display:flex; align-items:center; justify-content:center;
            border-radius:10px; border:1.5px solid #e0e8f0; text-decoration:none;
            font-size:0.85rem; color:var(--slate-light); padding:0 8px;
        }
        .page-link:hover { border-color:var(--accent); color:var(--accent); }
        .page-link.active { background:var(--accent); border-color:var(--accent); color:#fff; }
        .page-link.disabled { opacity:0.4; pointer-events:none; }

        #tbl-scroll-top { overflow-x:auto; overflow-y:hidden; height:12px; margin-bottom:4px; }
        #tbl-scroll-top-inner { height:1px; }
        .full-table-wrap { width:100%; padding:0 32px; box-sizing:border-box; }
        @media (max-width:768px) { .full-table-wrap { padding:0 12px; } }
    </style>
</head>
<body class="admin-page dash-page">

<?php if ($toast): ?>
<div class="toast" id="toastMsg">
    <span>✓</span><span><?= htmlspecialchars($toast) ?></span>
</div>
<script>
setTimeout(function(){
    var t = document.getElementById('toastMsg');
    if (t) t.style.display = 'none';
}, 3500);
</script>
<?php endif; ?>

<header class="dash-header">
    <div class="container">
        <div class="header-inner">
            <a href="index.html" style="text-decoration:none; display:flex; align-items:center; gap:10px;">
                <span class="logo-text">Водить<em>.РФ</em></span>
            </a>
            <nav class="dash-nav">
                <a href="admin.php" class="active">Заявки</a>
                <a href="logout.php" style="color:rgba(255,255,255,0.45);">Выйти</a>
            </nav>
        </div>
    </div>
</header>

<main class="dash-body">
    <div class="container">

        <div class="dash-welcome">
            <h1>Панель администратора</h1>
            <p>Управление заявками на обучение вождению речного транспорта</p>
        </div>

        <!-- Фильтры по статусу + сортировка -->
        <div class="filter-tabs" style="align-items:center;">
            <a href="admin.php"
               class="filter-tab <?= $filterStatus === 'all' ? 'active' : '' ?>">Все</a>
            <?php foreach ($statusLabel as $val => $lbl): ?>
                <a href="admin.php?status=<?= urlencode($val) ?><?= $sortBy !== 'id_asc' ? '&sort='.urlencode($sortBy) : '' ?>"
                   class="filter-tab <?= $filterStatus === $val ? 'active' : '' ?>"><?= $lbl ?></a>
            <?php endforeach; ?>
            <form method="GET" style="margin:0; margin-left:8px;">
                <?php if ($filterStatus !== 'all'): ?>
                    <input type="hidden" name="status" value="<?= htmlspecialchars($filterStatus) ?>">
                <?php endif; ?>
                <select name="sort" class="sort-select" onchange="this.form.submit()">
                    <option value="id_asc"    <?= $sortBy === 'id_asc'    ? 'selected' : '' ?>>Сортировка: № ↑</option>
                    <option value="id_desc"   <?= $sortBy === 'id_desc'   ? 'selected' : '' ?>>Сортировка: № ↓</option>
                    <option value="date_asc"  <?= $sortBy === 'date_asc'  ? 'selected' : '' ?>>Сортировка: дата ↑</option>
                    <option value="date_desc" <?= $sortBy === 'date_desc' ? 'selected' : '' ?>>Сортировка: дата ↓</option>
                </select>
            </form>
        </div>

    </div><!-- /container -->

    <?php if (empty($orders)): ?>
        <div class="container">
            <div class="dash-empty">
                <p>Заявок не найдено</p>
            </div>
        </div>
    <?php else: ?>
        <div class="full-table-wrap">
            <div id="tbl-scroll-top"><div id="tbl-scroll-top-inner"></div></div>
            <div id="tbl-scroll" style="overflow-x:auto;">
                <table class="orders-table" style="width:100%; table-layout:auto;">
                    <thead>
                        <tr>
                            <th title="Уникальный ID заявки из базы данных">#</th>
                            <th>Учащийся</th>
                            <th>Телефон</th>
                            <th>Email</th>
                            <th>Транспорт</th>
                            <th>Дата</th>
                            <th>Время</th>
                            <th>Оплата</th>
                            <th>Статус</th>
                            <th>Действия</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                    // Порядковый номер с учётом текущей страницы
                    $rowNum = ($page - 1) * $perPage + 1;
                    foreach ($orders as $order):
                    ?>
                        <tr>
                            <td style="color:var(--slate-light); font-size:0.8rem;" title="ID в БД: <?= $order['id'] ?>"><?= $rowNum++ ?></td>
                            <td style="font-weight:500;"><?= htmlspecialchars($order['full_name']) ?></td>
                            <td style="font-size:0.85rem;"><?= htmlspecialchars($order['phone']) ?></td>
                            <td style="font-size:0.85rem; color:var(--slate-light);"><?= htmlspecialchars($order['address']) ?></td>
                            <td><?= htmlspecialchars($order['service_type']) ?></td>
                            <td><?= date('d.m.Y', strtotime($order['desired_date'])) ?></td>
                            <td><?= substr($order['desired_time'], 0, 5) ?></td>
                            <td style="font-size:0.8rem; color:var(--slate-light);"><?= htmlspecialchars($order['payment_type']) ?></td>
                            <td>
                                <span class="status-badge <?= $statusClass[$order['status']] ?? 'status-new' ?>">
                                    <?= $statusLabel[$order['status']] ?? htmlspecialchars($order['status']) ?>
                                </span>
                            </td>
                            <td>
                                <div style="display:flex; gap:6px; flex-wrap:wrap;">
                                    <?php if ($order['status'] !== 'идет_обучение'): ?>
                                        <a href="update_order.php?id=<?= $order['id'] ?>&status=идет_обучение&_back=<?= urlencode($qsNoPage) ?>"
                                           class="action-link action-progress">▶ Идёт обучение</a>
                                    <?php endif; ?>
                                    <?php if ($order['status'] !== 'обучение_завершено'): ?>
                                        <a href="update_order.php?id=<?= $order['id'] ?>&status=обучение_завершено&_back=<?= urlencode($qsNoPage) ?>"
                                           class="action-link action-done"
                                           onclick="return confirm('Отметить обучение как завершённое?')">✓ Завершено</a>
                                    <?php endif; ?>
                                    <?php if ($order['status'] !== 'новая'): ?>
                                        <a href="update_order.php?id=<?= $order['id'] ?>&status=новая&_back=<?= urlencode($qsNoPage) ?>"
                                           class="action-link action-new">↺ Новая</a>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <?php if ($totalPages > 1): ?>
            <div class="pagination">
                <a href="admin.php<?= buildAdminQS(['page' => max(1, $page - 1)]) ?>"
                   class="page-link <?= $page === 1 ? 'disabled' : '' ?>">‹</a>
                <?php for ($p = 1; $p <= $totalPages; $p++): ?>
                    <a href="admin.php<?= buildAdminQS(['page' => $p]) ?>"
                       class="page-link <?= $p === $page ? 'active' : '' ?>"><?= $p ?></a>
                <?php endfor; ?>
                <a href="admin.php<?= buildAdminQS(['page' => min($totalPages, $page + 1)]) ?>"
                   class="page-link <?= $page === $totalPages ? 'disabled' : '' ?>">›</a>
            </div>
            <?php endif; ?>

        </div>
    <?php endif; ?>
</main>

<script>
(function(){
    var top  = document.getElementById('tbl-scroll-top');
    var bot  = document.getElementById('tbl-scroll');
    if (!top || !bot) return;
    function syncWidth(){
        document.getElementById('tbl-scroll-top-inner').style.width = bot.scrollWidth + 'px';
    }
    syncWidth();
    window.addEventListener('resize', syncWidth);
    top.addEventListener('scroll', function(){ bot.scrollLeft = top.scrollLeft; });
    bot.addEventListener('scroll', function(){ top.scrollLeft = bot.scrollLeft; });
})();
</script>
</body>
</html>
