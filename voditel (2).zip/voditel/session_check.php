<?php
/**
 * Используется главной страницей (index.html) через fetch(),
 * чтобы понять, авторизован ли посетитель, и показать нужные кнопки в хедере
 * («Войти / Регистрация», «Личный кабинет» или «Панель админа»).
 */
session_start();
header('Content-Type: application/json; charset=utf-8');

echo json_encode([
    'admin' => isset($_SESSION['admin']) && $_SESSION['admin'] === true,
    'user'  => isset($_SESSION['user_id']),
]);
