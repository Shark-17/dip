<?php
session_start();
require 'includes/db.php';
require 'includes/csrf.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = (int) $_SESSION['user_id'];

$uStmt = $conn->prepare("SELECT * FROM users WHERE id = :id");
$uStmt->execute([':id' => $user_id]);
$user = $uStmt->fetch();

if (!$user) {
    session_destroy();
    header('Location: login.php');
    exit();
}

// Цены курсов
$servicePrices = [
    'Катер'            => 15000,
    'Яхта'             => 50000,
    'Круизный лайнер'  => 150000,
];

// Заявки пользователя
$sql = "SELECT orders.*,
               reviews.id AS review_id, reviews.rating AS review_rating, reviews.text AS review_text
        FROM orders
        LEFT JOIN reviews ON reviews.order_id = orders.id
        WHERE orders.user_id = :uid
        ORDER BY orders.desired_date DESC, orders.id DESC";

$stmt = $conn->prepare($sql);
$stmt->execute([':uid' => $user_id]);
$orders = $stmt->fetchAll();

$statusClass = [
    'новая'               => 'status-new',
    'идет_обучение'       => 'status-progress',
    'обучение_завершено'  => 'status-done',
];
$statusLabel = [
    'новая'               => 'Новая',
    'идет_обучение'       => 'Идёт обучение',
    'обучение_завершено'  => 'Обучение завершено',
];

// Слайды
$slides = [
    ['emoji' => '', 'title' => 'Курсы вождения катера', 'text' => 'Освойте управление катером за 10 занятий с опытным инструктором.'],
    ['emoji' => '', 'title' => 'Обучение на яхте', 'text' => 'Полный курс судовождения и подготовка к экзамену ГИМС.'],
    ['emoji' => '', 'title' => 'Круизные лайнеры', 'text' => 'Углублённая программа для тех, кто хочет работать в команде судна.'],
    ['emoji' => '', 'title' => 'Сертификат об окончании', 'text' => 'После завершения курса вы получаете официальный сертификат.'],
];
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Личный кабинет — Водить.РФ</title>
    <link rel="stylesheet" href="main.css">
    <style>
        /* ── Шапка ── */
        .dash-header {
            background: linear-gradient(160deg, #0d1f30 0%, #1a3a5c 100%);
            padding: 0;
            position: sticky;
            top: 0;
            z-index: 100;
        }
        .header-inner {
            display: flex;
            align-items: center;
            justify-content: space-between;
            height: 56px;
            padding: 0 32px;
        }
        .logo-text {
            font-family: var(--font-display, 'Rubik', sans-serif);
            font-size: 1.25rem;
            color: #fff;
            letter-spacing: 0.02em;
        }
        .logo-text em { font-style: italic; opacity: 0.75; }
        .header-nav {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        .header-nav a {
            color: rgba(255,255,255,0.75);
            text-decoration: none;
            font-size: 0.875rem;
        }
        .header-nav a:hover { color: #fff; }
        .header-nav .nav-logout {
            color: rgba(255,255,255,0.45);
        }

        /* ── Слайдер ── */
        .slider-wrap {
            position: relative;
            background: linear-gradient(160deg, #0d1f30 0%, #1a3a5c 100%);
            border-radius: 16px;
            overflow: hidden;
            margin-bottom: 28px;
            height: 200px;
        }
        .slider-track {
            display: flex;
            height: 100%;
            transition: transform 0.5s ease;
        }
        .slide {
            flex: 0 0 100%;
            display: flex;
            align-items: center;
            gap: 24px;
            padding: 0 56px;
            color: #fff;
        }
        .slide-emoji { font-size: 2.8rem; flex-shrink: 0; }
        .slide-title {
            font-family: var(--font-display, 'Rubik', sans-serif);
            font-size: 1.5rem;
            margin-bottom: 6px;
            font-weight: 500;
        }
        .slide-text { font-size: 0.875rem; color: rgba(255,255,255,0.65); }
        .slider-btn {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            background: rgba(255,255,255,0.12);
            border: none;
            color: #fff;
            width: 34px;
            height: 34px;
            border-radius: 50%;
            cursor: pointer;
            font-size: 1.1rem;
            font-family: var(--font-body, 'Rubik', sans-serif);
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .slider-btn:hover { background: rgba(255,255,255,0.25); }
        .slider-prev { left: 14px; }
        .slider-next { right: 14px; }
        .slider-dots {
            position: absolute;
            bottom: 14px;
            left: 50%;
            transform: translateX(-50%);
            display: flex;
            gap: 8px;
        }
        .slider-dot {
            width: 7px; height: 7px;
            border-radius: 50%;
            background: rgba(255,255,255,0.35);
            cursor: pointer;
            border: none;
            padding: 0;
            font-family: var(--font-body, 'Rubik', sans-serif);
        }
        .slider-dot.active { background: #fff; }

        /* ── Кнопка новой заявки ── */
        .new-order-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: linear-gradient(135deg, #007BFF, #0056b3);
            color: #fff;
            text-decoration: none;
            padding: 12px 26px;
            border-radius: 100px;
            font-size: 0.9rem;
            font-weight: 500;
            margin-bottom: 28px;
            transition: opacity 0.2s;
        }
        .new-order-btn:hover { opacity: 0.88; }

        /* ── Таблица ── */
        .orders-table {
            width: 100%;
            border-collapse: collapse;
            background: #fff;
            border-radius: 16px;
            overflow: hidden;
            box-shadow: 0 4px 20px rgba(26,42,58,0.06);
        }
        .orders-table thead tr {
            background: #1a2f45;
            color: rgba(255,255,255,0.85);
        }
        .orders-table th {
            padding: 14px 16px;
            text-align: left;
            font-size: 0.72rem;
            font-weight: 500;
            letter-spacing: 0.08em;
            text-transform: uppercase;
            white-space: nowrap;
        }
        .orders-table td {
            padding: 16px 16px;
            border-bottom: 1px solid #f0f4f8;
            font-size: 0.875rem;
            color: #2d3748;
            vertical-align: middle;
        }
        .orders-table tbody tr:last-child td { border-bottom: none; }
        .orders-table tbody tr:hover { background: #f8fafc; }

        .status-badge {
            display: inline-flex;
            align-items: center;
            padding: 4px 12px;
            border-radius: 100px;
            font-size: 0.78rem;
            font-weight: 500;
            white-space: nowrap;
        }
        .status-new      { background: #eff6ff; color: #3b82f6; }
        .status-progress { background: #fff7ed; color: #c2730a; }
        .status-done     { background: #f0fdf4; color: #16a34a; }

        .repeat-link {
            font-size: 0.78rem;
            color: #007BFF;
            text-decoration: none;
            white-space: nowrap;
        }
        .repeat-link:hover { color: #0056b3; }

        /* ── Отзывы ── */
        .review-block { margin-top: 6px; }
        .review-existing { font-size: 0.8rem; color: #2d3748; }
        .review-existing .stars { color: #f59e0b; letter-spacing: 1px; }
        .review-toggle {
            font-size: 0.78rem; color: #007BFF; cursor: pointer;
            background: none; border: none; padding: 0; text-decoration: underline;
            font-family: var(--font-body, 'Rubik', sans-serif);
        }
        .review-form {
            display: none;
            margin-top: 8px;
            background: #f8fafc;
            border-radius: 10px;
            padding: 12px;
        }
        .review-form.open { display: block; }
        .review-stars-input { display: flex; gap: 4px; margin-bottom: 8px; flex-direction: row-reverse; justify-content: flex-end; }
        .review-stars-input label { cursor: pointer; font-size: 1.1rem; color: #d1d5db; }
        .review-stars-input input { display: none; }
        .review-stars-input input:checked ~ label,
        .review-stars-input label:hover,
        .review-stars-input label:hover ~ label { color: #f59e0b; }
        .review-form textarea {
            width: 100%; padding: 8px 10px;
            border: 1.5px solid #e0e8f0; border-radius: 8px;
            font-family: inherit; font-size: 0.82rem;
            resize: vertical; min-height: 56px; outline: none;
            margin-bottom: 8px; box-sizing: border-box;
        }
        .review-form textarea:focus { border-color: #007BFF; }
        .review-form button[type="submit"] {
            padding: 6px 16px; background: #007BFF; color: #fff; border: none;
            border-radius: 100px; font-size: 0.8rem; cursor: pointer; font-weight: 500;
            font-family: var(--font-body, 'Rubik', sans-serif);
        }
        .review-form button[type="submit"]:hover { background: #0056b3; }

        /* ── Основной лэйаут ── */
        body { background: #f2f5f8; margin: 0; font-family: var(--font-body, 'Rubik', sans-serif); }
        .page-wrap { max-width: 1200px; margin: 0 auto; padding: 40px 32px; }

        @media (max-width: 768px) {
            .page-wrap { padding: 24px 16px; }
            .header-inner { padding: 0 16px; }
            .slide { padding: 0 44px; }
        }
    </style>
</head>
<body>

<header class="dash-header">
    <div class="header-inner">
        <a href="index.html" style="text-decoration:none; display:flex; align-items:center; gap:10px;">
            
            <span class="logo-text">Водить<em>.РФ</em></span>
        </a>
        <nav class="header-nav">
            <a href="index.html">На сайт</a>
            <a href="logout.php" class="nav-logout">Выйти</a>
        </nav>
    </div>
</header>

<div class="page-wrap">

    <?php if (isset($_GET['created'])): ?>
        <div style="background:#f0fdf4; border:1px solid #bbf7d0; color:#16a34a;
                    padding:12px 16px; border-radius:12px; margin-bottom:24px; font-size:0.9rem;">
            ✓ Заявка успешно создана и отправлена на согласование администратору
        </div>
    <?php endif; ?>

    <!-- Слайдер -->
    <div class="slider-wrap" id="slider">
        <div class="slider-track" id="sliderTrack">
            <?php foreach ($slides as $s): ?>
                <div class="slide">
                    <span class="slide-emoji"><?= $s['emoji'] ?></span>
                    <div>
                        <div class="slide-title"><?= htmlspecialchars($s['title']) ?></div>
                        <div class="slide-text"><?= htmlspecialchars($s['text']) ?></div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        <button class="slider-btn slider-prev" onclick="slideMove(-1)" aria-label="Назад">‹</button>
        <button class="slider-btn slider-next" onclick="slideMove(1)" aria-label="Вперёд">›</button>
        <div class="slider-dots" id="sliderDots"></div>
    </div>

    <!-- Кнопка новой заявки -->
    <a href="create_order.php" class="new-order-btn">Новая заявка на обучение</a>

    <!-- Таблица заявок -->
    <?php if (empty($orders)): ?>
        <div style="text-align:center; padding:60px 20px; color:#8a9ab0;">
            
            <p style="margin-top:12px;">У вас пока нет заявок на обучение</p>
        </div>
    <?php else: ?>
        <div style="overflow-x:auto;">
            <table class="orders-table">
                <thead>
                    <tr>
                        <th>Email</th>
                        <th>Вид транспорта</th>
                        <th>Дата</th>
                        <th>Время</th>
                        <th>Оплата</th>
                        <th>Статус</th>
                        <th>Комментарий / отзыв</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($orders as $order): ?>
                    <?php
                    $status   = $order['status'] ?? 'новая';
                    $class    = $statusClass[$status] ?? 'status-new';
                    $label    = $statusLabel[$status] ?? htmlspecialchars($status);
                    $dateTs   = strtotime($order['desired_date'] ?? 'now');
                    $dateStr  = $dateTs ? date('d.m.Y', $dateTs) : '—';
                    $canReview = $status !== 'новая';
                    ?>
                    <tr>
                        <td><?= htmlspecialchars($order['address'] ?? '—') ?></td>
                        <td><?= htmlspecialchars($order['service_type'] ?? '—') ?></td>
                        <td style="white-space:nowrap;"><?= $dateStr ?></td>
                        <td><?= htmlspecialchars(substr($order['desired_time'] ?? '00:00', 0, 5)) ?></td>
                        <td style="color:#8a9ab0;"><?= htmlspecialchars($order['payment_type'] ?? '—') ?></td>
                        <td><span class="status-badge <?= $class ?>"><?= $label ?></span></td>
                        <td style="max-width:200px;">
                            <?php if (!empty($order['admin_comment'])): ?>
                                <span style="font-size:0.82rem; color:#2d3748;"><?= htmlspecialchars($order['admin_comment']) ?></span>
                            <?php endif; ?>

                            <?php if ($canReview): ?>
                            <div class="review-block">
                                <?php if (!empty($order['review_id'])): ?>
                                    <div class="review-existing">
                                        <span class="stars"><?= str_repeat('★', (int)$order['review_rating']) . str_repeat('☆', 5 - (int)$order['review_rating']) ?></span><br>
                                        «<?= htmlspecialchars($order['review_text']) ?>»
                                    </div>
                                <?php else: ?>
                                    <button type="button" class="review-toggle" onclick="toggleReview(<?= (int)$order['id'] ?>)">+ Оставить отзыв</button>
                                    <form class="review-form" id="reviewForm<?= (int)$order['id'] ?>" method="POST" action="submit_review.php">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="order_id" value="<?= (int)$order['id'] ?>">
                                        <div class="review-stars-input">
                                            <?php for ($i = 5; $i >= 1; $i--): ?>
                                                <input type="radio" name="rating" id="star<?= $i ?>_<?= (int)$order['id'] ?>" value="<?= $i ?>" <?= $i === 5 ? 'checked' : '' ?>>
                                                <label for="star<?= $i ?>_<?= (int)$order['id'] ?>">★</label>
                                            <?php endfor; ?>
                                        </div>
                                        <textarea name="text" placeholder="Расскажите о вашем обучении…" required></textarea>
                                        <button type="submit">Отправить отзыв</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>

</div>

<script>
(function() {
    const track = document.getElementById('sliderTrack');
    const dotsWrap = document.getElementById('sliderDots');
    const slides = track.children;
    const count = slides.length;
    let index = 0;
    let timer;

    for (let i = 0; i < count; i++) {
        const dot = document.createElement('button');
        dot.className = 'slider-dot' + (i === 0 ? ' active' : '');
        dot.setAttribute('aria-label', 'Слайд ' + (i + 1));
        dot.addEventListener('click', () => goTo(i));
        dotsWrap.appendChild(dot);
    }

    function update() {
        track.style.transform = 'translateX(-' + (index * 100) + '%)';
        Array.from(dotsWrap.children).forEach((d, i) => d.classList.toggle('active', i === index));
    }
    function goTo(i) {
        index = (i + count) % count;
        update();
        restart();
    }
    window.slideMove = function(dir) { goTo(index + dir); };
    function restart() {
        clearInterval(timer);
        timer = setInterval(() => goTo(index + 1), 3000);
    }
    restart();
})();

function toggleReview(orderId) {
    const form = document.getElementById('reviewForm' + orderId);
    if (form) form.classList.toggle('open');
}
</script>

</body>
</html>
