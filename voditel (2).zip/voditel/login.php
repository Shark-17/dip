<?php
session_start();
require 'includes/db.php';
require 'includes/csrf.php';

// Уже авторизован — редирект
if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit();
}
if (isset($_SESSION['admin'])) {
    header('Location: admin.php');
    exit();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    $login    = trim($_POST['login'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($login === '' || $password === '') {
        $error = 'Заполните все поля.';
    } else {
        // ── Проверяем таблицу admins (безопасно, без хардкода) ──
        $aStmt = $conn->prepare("SELECT * FROM admins WHERE login = :login LIMIT 1");
        $aStmt->execute([':login' => $login]);
        $admin = $aStmt->fetch();

        if ($admin && password_verify($password, $admin['password'])) {
            session_regenerate_id(true);
            $_SESSION['admin']      = true;
            $_SESSION['admin_name'] = $admin['full_name'] ?? 'Администратор';
            $_SESSION['admin_id']   = $admin['id'];
            header('Location: admin.php');
            exit();
        }

        // ── Проверяем обычных пользователей ──
        $stmt = $conn->prepare("SELECT * FROM users WHERE login = :login LIMIT 1");
        $stmt->execute([':login' => $login]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            session_regenerate_id(true);
            $_SESSION['user_id']   = $user['id'];
            $_SESSION['user_name'] = $user['full_name'];
            header('Location: dashboard.php');
            exit();
        }

        $error = 'Неверный логин или пароль.';
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Вход — Водить.РФ</title>
    <link rel="stylesheet" href="main.css">
</head>
<body class="auth-page">
    <div class="auth-card">
        <div class="auth-logo">
            <a href="index.html" style="text-decoration:none;">
                
                <div class="logo-text">Водить<em>.РФ</em></div>
            </a>
        </div>

        <h1 class="auth-title">Добро пожаловать</h1>
        <p class="auth-sub">Войдите в личный кабинет</p>

        <?php if (isset($_GET['registered'])): ?>
            <div style="background:#f0fdf4; border:1px solid #bbf7d0; color:#16a34a;
                        padding:12px 16px; border-radius:12px; margin-bottom:16px; font-size:0.875rem;">
                ✓ Регистрация прошла успешно. Теперь войдите в аккаунт.
            </div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="auth-error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="POST" novalidate>
            <?= csrf_field() ?>
            <div class="form-group">
                <label for="login">Логин</label>
                <input type="text" id="login" name="login"
                       placeholder="Ваш логин" required autocomplete="username"
                       value="<?= htmlspecialchars($_POST['login'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label for="password">Пароль</label>
                <input type="password" id="password" name="password"
                       placeholder="••••••••" required autocomplete="current-password">
            </div>
            <button type="submit" class="auth-submit">Войти</button>
        </form>

        <div class="auth-link">
            Еще не зарегистрированы? <a href="register.php">Регистрация</a>
        </div>
    </div>
</body>
</html>
